# Software versions

The group's reference environment on Zhi Li's Mac was used for the back-tests, the formal run on 12 November 2026
and the route 3 recheck. Ci Bao and Shujun Zhou also ran rehearsal checks in their own environments. See
`03_agent_workflow/member_confirmations.md` for their checks.

| Component | Version |
|---|---|
| OS | macOS 26.6.2 (build 25G83), Apple silicon (arm64) |
| Python | 3.11.4 (Anaconda) — always run with `-I` (isolated mode) |
| numpy | 1.24.3 |
| pandas | 1.5.3 |
| python-dateutil | 2.8.2 |
| statsmodels | 0.14.0 (research back-tests only: HAC) |
| scipy | 1.10.1 (installed; research environment) |
| matplotlib | 3.7.1 (figures only) |

Needed for `02_reproduce/`: Python 3.11 + numpy (production), + pandas and python-dateutil (independent check, sample
generator). See `02_reproduce/requirements.txt`. The report .docx was assembled by a Python script (standard library, OOXML) and the PDF exported with Microsoft Word for Mac.
AI tools and their roles: see `03_agent_workflow/ai_use.md`.

Formal run 2026-11-12: Python 3.11.4, numpy 1.24.3 (recorded in `04_formal_run/formal_record/forecast_record.json`), macOS 26.6.2 (25G83). Report PDF exported with Microsoft Word for Mac; body word count measured in Word (2,383 words).
