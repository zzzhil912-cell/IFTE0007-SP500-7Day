# Protocol summary (English)

English summary of the frozen protocols. The originals are in Chinese and stay unchanged in the project's internal
archive; their SHA-256 values are listed in each run's `results/*/FREEZE_RECORD.json`. Where this summary and an original
differ, the original governs.

## First-round 7-day test protocol v3.1 (frozen with the first back-test, decision D27)
| Item | Rule |
|---|---|
| Target of each test | S&P 500 close 7 NYSE trading days after the origin |
| Label | y_s = ln(P_{s+7} / P_s) |
| Origins | every Wednesday from 2003-09-24; a Wednesday holiday moves to the previous trading day |
| Training | expanding window, matured labels only (idx(s) + 7 ≤ idx(t)), at least 260 labels; OLS with intercept |
| Evaluation | 944 origins, 2008-09-24 to 2026-10-21; all rules share origins, base and target closes and training rows |
| Rules | B0 (no change), B1-7 (intercept only), F1-5, F1-21 (x_L = ln(P_t / P_{t−L})), F2 (VRP_{t−1} = VIX_{t−1}²/12 − RV_{t−1}, VIX and RV to the same day), F1-5+F2, F1-21+F2 |
| VIX sample | training and evaluation start after the current VIX methodology was introduced (2003-09-22); earlier values are back-calculated |
| Forecast | F = P_t · exp(ŷ_t); prices normalised to 2 dp (ROUND_HALF_UP); main APE on the 2-dp forecast, full-precision APE kept |
| Losses | APE (pp) and MAE of the 7-day log return (bp) |
| Inference | paired differences d = A − B; Newey–West HAC, lag 1 (a pre-fixed reporting convention); moving-block bootstrap, block 4, B = 2,000, seed 20261111, percentile intervals; two alternating-origin phases of 472 origins each, descriptive |
| Status | 15 pre-registered comparisons, all exploratory (D17): an interval excluding zero is a diagnostic clue only; adoption also weighs error size, stability across periods, performance against B1-7 and running cost |
| Sample note | part of the evaluation sample had already been examined, so the comparisons are exploratory (D13) |

## Extension stage 1 (decision D32) and E1 addendum
- **E1 (F2-clip):** reuse the frozen first-round F2 coefficients (verified to reproduce frozen ŷ within 1e-12 at all 944
  origins, otherwise stop); clip only the origin's VRP_{t−1} to the 1st–99th percentile of its matured training VRP values;
  no refitting.
- **E2d:** influence diagnostics of the F2 regression (leverage, studentised residuals, slope change when one label is dropped).
- **E2 (F2-Huber):** Huber regression of the same model.
- **E3 (R156):** 156-week rolling window for B1-7 and F2.

## Huber-Intercept addendum (decision D34)
Huber location estimate of past 7-day labels (no factor), same origins and labels; added after the first results, so its
comparison with B1-7 is descriptive. Pre-registered same-method comparison: F2-Huber vs Huber-Intercept (H2).

## Adoption record (decision D38, 2026-11-05 23:59:57 UTC, approver Zhi Li)
- **Adopted rule:** F1-21, as defined above, for the formal 7-day forecast.
- **Benchmarks only:** B0, B1-7, Huber-Intercept.
- **Fact the record must state:** over 944 Wednesday origins (2008-09-24 to 2026-10-21), F1-21 mean APE 2.0613 vs
  same-sample B1-7 2.0615, difference −0.0002; HAC and bootstrap intervals include zero; the two phases have opposite signs.
  **F1-21 shows no stable predictive increment over B1-7.** Huber-Intercept mean APE 2.0382 (descriptive).
- **Reasons:** lowest mean APE and MAE among the 8 factor specifications run; time-series momentum mechanism (Moskowitz,
  Ooi and Pedersen, 2012); stable slope sign; the formal run needs prices only.
- **Formal forecast:** requires a separate authorisation.
