# Corrections and failed checks (English summary)

English summary of the internal correction logs (Chinese originals stay unchanged in the project archive; folder names
below are archive locations). "Found by" states who raised the issue; "Claude" = the AI agent (Claude Code). Review points
that Zhi Li raised are attributed to Zhi (decision D18); see the report's AI-use declaration for tools used in review.

## Protocol and evidence corrections (rounds 1–4; consolidated log C1–C13)
| # | What was wrong | Found by | Correction |
|---|---|---|---|
| C1 | F3 reference: the DOI given for Johnson (2017) belongs to Carr & Wu (2017) | Claude (self-check) | retracted; correct DOI verified on the publisher page; F3 not tested (D15) |
| C2 | "Weekly origins give essentially non-overlapping 7-day labels" | Zhi raised the review point; Claude re-checked by script | corrected: adjacent Wednesday labels share 2 trading days (more around holidays) |
| C3 | VIX close time described as unknown although the Cboe methodology states it | Claude | corrected |
| C4 | VIX values before 2003-09-22 are Cboe back-calculations — omitted | Claude | handled by D11: training and evaluation start after 2003-09-22 |
| C5 | 1990–2009 proposed as "confirmatory" | Claude | handled by D13: part of the evaluation sample had already been examined, so the comparisons are exploratory |
| C6 | "Sample can go back to the 1950s" was an unsupported claim about data coverage | Claude | Archived Yahoo snapshot checked on 13 November 2026. Its first daily close is 4 January 1988. |
| C7 | Alternate-origin phases checked for overlap in one phase only; v2 phase 2 had one overlap (2001-09-05 / 2001-09-19) | **Zhi raised the review point; Claude checked with trading-day indices and revised** | v3: both phases 472 origins, no overlap |
| C11 | "Before next open" ambiguous | Zhi | defined as τ = 09:30 New York of the next trading day |
| C12 | Missing-value handling for S&P and VIX mixed together | Zhi | separated in v3 |
| C13 | HAC lag-1 justification overstated; phase standard errors treated as inference | Zhi | v3.1: lag 1 is a pre-fixed reporting convention, block bootstrap as sensitivity, phases descriptive |

Source: archive `04_round4_protocol_v3_1/corrections/correction_check_log_v3_1_consolidated.md`. Identifiers follow that
log; C8–C10 concern material outside this project's evaluation and are omitted here.

## Failed checks in code preparation and runs
| # | Round | What failed | Fix | Evidence |
|---|---|---|---|---|
| X1 | 5 | Pre-check calendar missed the 2007-01-02 market closure (President Ford's national day of mourning); calendar-span check unreliable | rule-based NYSE holidays + listed special closures | archive `05_round5_code_prep/`, `06_round6_code_revision/revision_diff/` |
| X2 | 11 | Synthetic self-test: VRP tolerance 1e-12 too strict; Huber scale-zero case disagreed between scripts | tolerance 1e-10; `HUBER_SCALE_EPS = 1e-10` in both scripts, recorded before the freeze | `11_round11_ext_code_prep/records/selftest_revision_record.md` |
| X3 | 16 | FOMC calendar parser picked up minutes dates as meeting dates | parser v2; pilot rerun; coverage still insufficient → macro count deferred (D37) | `16_round16_macro_schedule_pilot/` |
| X4 | 18 | Production record failed to serialise a numpy bool | cast to Python bool | `18_round18_production_prep/` |
| X5 | 10 | A case-insensitive `rm` on macOS deleted the SKEW white paper by accident | re-downloaded, hash re-recorded | `10_round10_protocol_revision/` logs |
| X6 | 20 | Test T9c described as a formal-mode guard; it is a data check (no 2026-11-11 close in the snapshot) | description corrected before the D41 freeze | `20_round20_prefreeze_closeout/tests/test_results.md` |
| X7 | 9→10 | NVIDIA conference-call time (17:00 ET) recorded as the results release time (≈16:20 ET) | corrected in event calendar r2/r3 | `11_round11_ext_code_prep/records/event_calendar_window_r3.md` |

## Results that were negative (kept, not hidden)
- No factor rule showed a stable improvement over B1-7 (all intervals for F1-21 vs B1-7 span zero).
- VRP rules were worse than B1-7 in the first round; clipping, Huber estimation and a 156-week rolling window did not fix it.
- Macro-announcement count: local feasibility check done; historical publication-time coverage did not meet the back-test
  admission bar. Recorded as "deferred", not as "back-test invalid" (D37).
