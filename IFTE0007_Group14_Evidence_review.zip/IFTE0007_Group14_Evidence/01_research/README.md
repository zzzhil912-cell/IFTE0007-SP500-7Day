# 01_research — 7-day experiments, results, failures, corrections and decisions

All experiments here are **7-trading-day** experiments of this project (2026-11-05 to 2026-11-06). Every evaluation is
labelled **exploratory** (decision D13): part of the evaluation sample had already been examined, so the comparisons
are exploratory. This folder holds the results and English summaries supporting the report. Per-origin files with index levels are not shipped (licence; see
`../02_reproduce/inputs/README_restricted_inputs.md`).

Common design (frozen protocol v3.1, summarised in `protocol_summary.md`):
label y = ln(P_{t+7}/P_t); Wednesday origins from 2003-09-24 (holiday → previous trading day); matured labels only,
idx(s)+7 ≤ idx(t); at least 260 labels; expanding OLS with intercept; F = P_t·exp(ŷ), 2 dp. Evaluation: 944 Wednesday origins
2008-09-24 to 2026-10-21; APE = |F_2dp − P_{t+7}| / P_{t+7} × 100 (percentage points); MAE = |ŷ − y| × 10,000 (basis
points of 7-day log return); paired differences d = A − B (negative = A better); Newey–West HAC (lag 1, Bartlett) and
moving-block bootstrap (block 4, B = 2,000, seed 20261111, percentile) intervals; two alternating-origin phases
(descriptive, because adjacent 7-day labels overlap by 2 trading days).

## Experiment sequence
| Step | Rules | Freeze | Main result (mean APE, pp; 944 origins) | Files |
|---|---|---|---|---|
| 1. First round (D27) | B0 (no change), B1-7 (intercept only), F1-5, F1-21 (past 5/21-day log return), F2 (lag-1 VRP_{t−1} = VIX_{t−1}²/12 − RV_{t−1}), F1-5+F2, F1-21+F2 | 17 files, approved 2026-11-05T20:59:40Z | B0 2.0833; B1-7 2.0615; F1-5 2.0679; **F1-21 2.0613**; F2 2.1224; F1-5+F2 2.1327; F1-21+F2 2.1281 | `results/first_round/` |
| 2. Diagnostics (D28) | — | read-only | F2's excess loss vs B1-7 (+0.061 pp) comes mostly from the GFC window 2008-09..2009-03 (+0.052 pp), when extreme VRP labels entered training | `diagnostics_round8/Q2_case_labels_entering_training.csv`, `diagnostics_round8/Q2_loss_decomposition.csv` |
| 3. VRP extension, stage 1 (D32) | F2-clip (origin VRP clipped), F2-Huber (Huber regression), B1-7-R156 / F2-R156 (156-week rolling) | 18 files, approved 2026-11-05T22:21:13Z | F2-clip 2.0687; F2-Huber 2.0662; B1-7-R156 2.0611; F2-R156 2.1257 — no VRP variant beat B1-7 | `results/extension_stage1/` |
| 4. Robust benchmark (D34) | Huber-Intercept (Huber location of past labels, no factor) | 17 files, approved 2026-11-05T22:37:22Z | **2.0382** (−0.023 vs B1-7; added after first results, so descriptive); F2-Huber vs Huber-Intercept +0.028 (VRP adds nothing) | `results/huber_intercept/` |
| 5. New-factor admission (D35–D37) | SKEW; scheduled macro-announcement count | none (admission checks) | macro count: local feasibility check done, historical publication-time coverage did not meet the back-test admission bar; SKEW deferred | `new_factor_checks/macro_schedule_pilot/pilot_coverage_report.txt` |
| 6. Adoption (D38) | F1-21 | production freeze D41 (9 files) | F1-21 − B1-7 = −0.00023 pp; HAC 90 % [−0.0112, 0.0107], bootstrap 90 % [−0.0106, 0.0095]; phases +0.0052 / −0.0057 → no stable predictive increment | `results/adoption/` |

## Key files
| File | Content |
|---|---|
| `results/first_round/levels.csv` | mean / median / max APE, mean course score, mean MAE per rule |
| `results/first_round/comparisons.csv` | 15 pre-registered paired comparisons (+ others), HAC and bootstrap intervals |
| `results/first_round/phases.csv`, `subperiods.csv`, `stress.csv` | alternating phases, sub-periods and stress windows |
| `results/first_round/adjustments_vs_B1-7.csv` | prediction adjustments, including the median 4.4 bp for F1-21 |
| `results/first_round/coefficient_stability.csv` | sign stability of slopes (F1-21 slope positive at 99.7 % of origins, one sign change) |
| `results/*/FREEZE_RECORD.json`, `main_run_manifest.json`, `analysis_manifest.json`, `independent_check_report.json` | original run records and hashes, including outputs held in the group archive |
| `results/adoption/factor_rule_summary_table.csv` | one row per rule: the table behind the report's Table 2 |
| `source_register.md` | literature and data sources: URL, read scope, retrieval time, publication-time evidence, last observation, location |
| `corrections_and_failures.md` | English log of real errors, failed checks and their corrections |
| `code_frozen/` | byte-identical copies of the frozen back-test code (read-only; rerun needs restricted inputs) |
| `protocol_summary.md` | English summary of the frozen protocols, extension addendum and adoption record (Chinese originals stay in the internal archive) |
