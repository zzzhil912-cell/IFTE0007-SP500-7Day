"""Constants restated for the round-11 independent check (it does not import config.py)."""
RAW_Y = "inputs/yahoo_GSPC_1988_to_now.json"
RAW_V = "inputs/cboe_VIX_round1copy_20261105T185724Z.csv"
FROZEN = "inputs/first_round_frozen/per_origin_forecasts.csv"
FROZEN_SHA256 = "da5b06744f5865c8fe4f9aa4e7b1968542acf63346706f2db369c3ea88c84bdb"
HIST_END, PARTIAL = "2026-11-04", "2026-11-05"
LAUNCH, FIRST_WED = "2003-09-22", "2003-09-24"
H, MINTR, ROLL = 7, 260, 156
EXPECTED_KEYS = 944 * 4
EXT_RULES = ["F2-clip", "F2-Huber", "B1-7-R156", "F2-R156"]
COMPARISONS = [("X1", "F2-clip", "F2"), ("X2", "F2-clip", "B1-7"), ("X3", "F2-Huber", "F2"), ("X4", "F2-Huber", "B1-7"),
               ("X5", "B1-7-R156", "B1-7"), ("X6", "F2-R156", "F2"), ("X7", "F2-R156", "B1-7-R156")]
Q = (1.0, 99.0)
HUBER_T, HUBER_MAXITER, HUBER_TOL = 1.345, 50, 1e-8
HUBER_SCALE_EPS = 1e-10
APPROVER = "Zhi"
REQUIRED = [RAW_Y, RAW_V, FROZEN, "inputs/first_round_frozen/FREEZE_RECORD.json",
            "code/config.py", "code/data_build.py", "code/freeze_guard.py", "code/precheck.py", "code/main_run.py",
            "code/diag_e2d.py", "code/analysis.py", "code/independent_check.py", "code/independent_constants.py",
            "spec/ext_output_fields.md", "spec/ext_tolerances_and_failure_rules.md", "spec/environment.txt",
            "../10_round10_protocol_revision/protocol/expansion_protocol_stage1_v1_review.md"]
TOL = {"repro": 1e-12, "x": 1e-12, "vrp_rel": 1e-10, "yhat_ols": 1e-10, "coef_rel_ols": 1e-8, "yhat_huber": 1e-7, "coef_rel_huber": 1e-6,
       "forecast_full": 1e-6, "ape": 1e-9, "abs_err_bp": 1e-6, "hac_rel": 1e-10, "clip": 1e-12}
