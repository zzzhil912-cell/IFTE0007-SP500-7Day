"""Data construction for the first-round backtest (protocol v3.1). NO model fitting in this module.

Order of operations (Zhi: validate the trading-day index first, then compute 7-day targets):
  1. verify input SHA-256
  2. parse Yahoo; convert 09:30-ET bar timestamps to New York dates; drop the 2026-11-05 intraday row;
     keep dates <= HIST_END; round closes to 2 dp (published precision)
  3. validate the trading-day index (strictly increasing, unique, weekdays only, no null closes)
  4. parse Cboe VIX; keep only dates that are S&P trading days
  5. build features (x5, x21, VRP_{t-1}) and the Wednesday origin schedule
  6. targets: P_{idx(t)+7} using the validated index
"""
import csv, hashlib, json, math
from dataclasses import dataclass, field
from datetime import datetime, date, timedelta, timezone
from zoneinfo import ZoneInfo
import config as C

NY = ZoneInfo("America/New_York")


def norm2(v):
    """Normalise a raw Yahoo close to the published 2-dp precision (ROUND_HALF_UP on the shortest repr)."""
    from decimal import Decimal, ROUND_HALF_UP
    return float(Decimal(repr(v)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
    return h.hexdigest()


@dataclass
class Data:
    dates: list            # validated S&P trading dates (<= HIST_END)
    close: list            # 2-dp closes aligned with dates
    idx: dict              # date -> position
    vix: dict              # date -> VIX close (S&P trading days only)
    log: list = field(default_factory=list)
    yahoo_meta: dict = field(default_factory=dict)
    rounding_max_abs: float = 0.0
    dropped_partial: object = None
    vix_dropped_non_spx: int = 0


def load():
    log = []
    for p in (C.YAHOO_JSON, C.CBOE_CSV):
        got = sha256(p)
        if got != C.EXPECTED_SHA256[p.name]:
            raise SystemExit(f"STOP: SHA-256 mismatch for {p.name}: {got}")
        log.append(f"sha256 ok {p.name} {got}")
    j = json.loads(C.YAHOO_JSON.read_text())
    res = j["chart"]["result"][0]; meta = res["meta"]
    if meta.get("dataGranularity") != "1d":
        raise SystemExit("STOP: Yahoo granularity is not 1d")
    rows = []
    for t, c in zip(res["timestamp"], res["indicators"]["quote"][0]["close"]):
        dt = datetime.fromtimestamp(t, timezone.utc).astimezone(NY)
        rows.append((dt.date(), dt.strftime("%H:%M"), c))
    # drop the intraday row explicitly and verify it is intraday
    rmt = datetime.fromtimestamp(meta["regularMarketTime"], timezone.utc).astimezone(NY)
    partial = [r for r in rows if r[0] == C.PARTIAL_ROW_DATE]
    if len(partial) != 1 or rmt.date() != C.PARTIAL_ROW_DATE or (rmt.hour, rmt.minute) >= (16, 0):
        raise SystemExit("STOP: expected exactly one intraday row dated 2026-11-05")
    rows = [r for r in rows if r[0] != C.PARTIAL_ROW_DATE and r[0] <= C.HIST_END]
    log.append(f"dropped Yahoo intraday row {C.PARTIAL_ROW_DATE} (regularMarketTime {rmt.isoformat()}, raw close {partial[0][2]})")
    dates = [r[0] for r in rows]
    raw = [r[2] for r in rows]
    if any(v is None for v in raw):
        raise SystemExit("STOP: null close in Yahoo data")
    close = [norm2(v) for v in raw]                     # working prices, 2 dp, ROUND_HALF_UP
    near_half = [(str(x), v) for x, v in zip(dates, raw) if abs((abs(v) * 100) % 1 - 0.5) < C.HALF_CENT_GUARD * 100]
    if near_half:
        raise SystemExit(f"STOP: raw closes too close to a half-cent boundary: {near_half[:5]}")
    max_round = max(abs(a - b) for a, b in zip(raw, close))
    if max_round >= C.MAX_YAHOO_ROUNDING:
        raise SystemExit(f"STOP: rounding to 2 dp changed a close by {max_round}")
    d = Data(dates=dates, close=close, idx={x: i for i, x in enumerate(dates)}, vix={}, log=log,
             yahoo_meta={"dataGranularity": meta.get("dataGranularity"), "exchangeTimezoneName": meta.get("exchangeTimezoneName"),
                         "bar_times": sorted(set(r[1] for r in rows))},
             rounding_max_abs=max_round, dropped_partial=partial[0])
    vix_all = {}
    with open(C.CBOE_CSV) as f:
        for row in csv.DictReader(f):
            vix_all[datetime.strptime(row["DATE"], "%m/%d/%Y").date()] = float(row["CLOSE"])
    d.vix = {k: v for k, v in vix_all.items() if k in d.idx}
    d.vix_dropped_non_spx = sum(1 for k in vix_all if k not in d.idx and k <= C.HIST_END)
    return d


def validate_index(d):
    """Return list of (check, passed, detail). Must be run before any target is computed."""
    out = []
    inc = all(a < b for a, b in zip(d.dates, d.dates[1:]))
    out.append(("dates strictly increasing", inc, ""))
    out.append(("dates unique", len(set(d.dates)) == len(d.dates), f"n={len(d.dates)}"))
    out.append(("weekdays only", all(x.weekday() < 5 for x in d.dates), ""))
    out.append(("last date == HIST_END", d.dates[-1] == C.HIST_END, str(d.dates[-1])))
    out.append(("bar timestamps all 09:30 ET", d.yahoo_meta["bar_times"] == ["09:30"], str(d.yahoo_meta["bar_times"])))
    # gaps of more than 4 calendar days between consecutive trading days (long weekends are <= 4)
    long_gaps = [(str(a), str(b), (b - a).days) for a, b in zip(d.dates, d.dates[1:]) if (b - a).days > 4]
    # documented closures: 9/11 (2001-09-11..14); New Year 2007-01-01 + national day of mourning for
    # President Ford 2007-01-02; Hurricane Sandy (2012-10-29..30). Added 2007 after precheck run 1 stopped on it.
    known = {("2001-09-10", "2001-09-17"), ("2006-12-29", "2007-01-03"), ("2012-10-26", "2012-10-31")}
    unexplained = [g for g in long_gaps if (g[0], g[1]) not in known]
    out.append(("calendar gaps > 4 days are only known closures (9/11 2001, Ford mourning 2007, Sandy 2012)", not unexplained,
                f"all long gaps={long_gaps}; unexplained={unexplained}"))
    nyse26 = {date(2026,1,1),date(2026,1,19),date(2026,2,16),date(2026,4,3),date(2026,5,25),date(2026,6,19),date(2026,7,3),date(2026,9,7)}
    miss26 = set()
    x = date(2026, 1, 1)
    while x <= C.HIST_END:
        if x.weekday() < 5 and x not in d.idx: miss26.add(x)
        x += timedelta(days=1)
    out.append(("2026 weekday non-trading days == NYSE holiday list", miss26 == nyse26, str(sorted(str(x) for x in miss26))))
    miss, unexpl, traded = holiday_check(d, date(2003, 8, 1))
    out.append(("2003-08..2026-11: every weekday non-trading day is a rule-based NYSE holiday or documented closure, and no such day has a close",
                not unexpl and not traded, f"{len(miss)} weekday non-trading days; unexplained={unexpl}; closes on expected holidays={traded}"))
    return out


def _easter(y):  # anonymous Gregorian algorithm
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25; g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mo = (h + l - 7 * m + 114) // 31; da = (h + l - 7 * m + 114) % 31 + 1
    return date(y, mo, da)


def _nth_weekday(y, m, wd, n):
    x = date(y, m, 1)
    while x.weekday() != wd: x += timedelta(days=1)
    return x + timedelta(days=7 * (n - 1))


def _last_weekday(y, m, wd):
    x = date(y, m + 1, 1) - timedelta(days=1) if m < 12 else date(y, 12, 31)
    while x.weekday() != wd: x -= timedelta(days=1)
    return x


def _observed(x):
    return x - timedelta(days=1) if x.weekday() == 5 else (x + timedelta(days=1) if x.weekday() == 6 else x)


SPECIAL_CLOSURES = {date(2004, 6, 11): "Reagan national day of mourning", date(2007, 1, 2): "Ford national day of mourning",
                    date(2012, 10, 29): "Hurricane Sandy", date(2012, 10, 30): "Hurricane Sandy",
                    date(2018, 12, 5): "G.H.W. Bush national day of mourning", date(2025, 1, 9): "Carter national day of mourning"}


def nyse_rule_holidays(y):
    """Rule-based NYSE full-day holidays (valid for 2003+). New Year on Saturday is not observed on the Friday."""
    hs = {}
    ny = date(y, 1, 1)
    if ny.weekday() != 5: hs[_observed(ny)] = "New Year"
    hs[_nth_weekday(y, 1, 0, 3)] = "MLK"; hs[_nth_weekday(y, 2, 0, 3)] = "Presidents"
    hs[_easter(y) - timedelta(days=2)] = "Good Friday"; hs[_last_weekday(y, 5, 0)] = "Memorial"
    if y >= 2022: hs[_observed(date(y, 6, 19))] = "Juneteenth"
    hs[_observed(date(y, 7, 4))] = "Independence"; hs[_nth_weekday(y, 9, 0, 1)] = "Labor"
    hs[_nth_weekday(y, 11, 3, 4)] = "Thanksgiving"; hs[_observed(date(y, 12, 25))] = "Christmas"
    return hs


def holiday_check(d, start):
    """Every weekday non-trading day from start..HIST_END must be a rule holiday or documented closure,
    and every rule holiday / closure that is a weekday must be absent from the index."""
    expected = {}
    for y in range(start.year, C.HIST_END.year + 1):
        expected.update(nyse_rule_holidays(y))
    expected.update(SPECIAL_CLOSURES)
    expected = {k: v for k, v in expected.items() if start <= k <= C.HIST_END and k.weekday() < 5}
    missing = []
    x = start
    while x <= C.HIST_END:
        if x.weekday() < 5 and x not in d.idx: missing.append(x)
        x += timedelta(days=1)
    unexplained = [str(m) for m in missing if m not in expected]
    traded_on_holiday = [f"{k} {v}" for k, v in expected.items() if k in d.idx]
    return missing, unexplained, traded_on_holiday


def log_return(d, i):
    return math.log(d.close[i] / d.close[i - 1])


def features_at(d, t):
    """Inputs for origin t. Returns dict or None with reason. Uses only data dated <= t (VIX/RV <= t-1)."""
    i = d.idx[t]
    if i - 1 < 0: return None, "no t-1"
    p = d.dates[i - 1]                     # t-1 = previous S&P trading day
    if p < C.VIX_LAUNCH: return None, "t-1 before VIX launch"
    if p not in d.vix: return None, "VIX_{t-1} missing"
    if i - 1 - C.RV_N < 0 or i - max(C.LOOKBACKS) < 0: return None, "S&P history missing"
    rv = 1e4 * sum(log_return(d, i - 1 - j) ** 2 for j in range(C.RV_N))   # returns t-1 .. t-21
    iv = d.vix[p] ** 2 / 12.0
    return {"x5": math.log(d.close[i] / d.close[i - 5]), "x21": math.log(d.close[i] / d.close[i - 21]),
            "vrp": iv - rv, "vix_date": p, "rv_first_return_date": d.dates[i - C.RV_N], "rv_last_return_date": p}, None


def schedule(d):
    out, w = [], C.SCHEDULE_FIRST_WED
    while w <= d.dates[-1]:
        t = w
        while t not in d.idx and t >= d.dates[0]: t -= timedelta(days=1)   # Wednesday holiday -> previous trading day
        if t in d.idx and (not out or out[-1] != t): out.append(t)
        w += timedelta(days=7)
    return out


def build(d):
    """Eligible origins with features and targets. Targets use the validated index (idx + H)."""
    rows, dropped = [], []
    for t in schedule(d):
        i = d.idx[t]
        if i + C.H >= len(d.dates):
            dropped.append((t, "target after HIST_END")); continue
        f, why = features_at(d, t)
        if f is None:
            if why != "t-1 before VIX launch": dropped.append((t, why))
            continue
        tgt = d.dates[i + C.H]
        f.update(origin=t, i=i, base_close=d.close[i], target_date=tgt, target_close=d.close[i + C.H],
                 y=math.log(d.close[i + C.H] / d.close[i]))
        rows.append(f)
    return rows, dropped


def training_positions(rows, k):
    """Positions (into rows) of training labels for origin rows[k]: idx(s) + H <= idx(t)."""
    it = rows[k]["i"]
    return [j for j in range(len(rows)) if rows[j]["i"] + C.H <= it]


def evaluation_positions(rows):
    first = next(k for k in range(len(rows)) if len(training_positions(rows, k)) >= C.MIN_TRAIN)
    return list(range(first, len(rows)))
