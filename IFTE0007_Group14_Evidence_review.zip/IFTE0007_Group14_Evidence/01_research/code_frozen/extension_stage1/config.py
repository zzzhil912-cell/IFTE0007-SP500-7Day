"""Constants for the STAGE-1 EXTENSION backtest (round 11; protocol expansion_protocol_stage1_v1 + Zhi 2026-11-05 21:55).
First-round constants below are kept verbatim (data_build.py is the frozen first-round module, imported unchanged).
Original first-round docstring follows:
Constants for the first-round 7-day backtest (protocol v3.1). Shared by data_build, precheck, main_run, analysis.
The independent check (independent_check.py) deliberately does NOT import this file; it restates the constants.
"""
from datetime import date
from pathlib import Path

STAGE = Path(__file__).resolve().parent.parent
INPUTS = STAGE / "inputs"
YAHOO_JSON = INPUTS / "yahoo_GSPC_1988_to_now.json"
CBOE_CSV = INPUTS / "cboe_VIX_round1copy_20261105T185724Z.csv"
EXPECTED_SHA256 = {
    YAHOO_JSON.name: "a2d671c5c5595990ae7a6efaa0c22430ec9e34385eaa8e8543bf74434a35931a",
    CBOE_CSV.name: "50731d77d6723344b67789e2fafe65c32bf005710d5918e693da5f1f62e231e8",
}
FREEZE_RECORD = STAGE / "FREEZE_RECORD.json"   # does not exist until Zhi approves the freeze
REQUIRED_APPROVER = "Zhi"                      # Zhi 2026-11-05 20:40: the formal freeze names Zhi as approver
# every file below must be listed (with matching SHA-256) in FREEZE_RECORD.json; paths relative to STAGE
REQUIRED_FREEZE_FILES = [
    "inputs/yahoo_GSPC_1988_to_now.json", "inputs/cboe_VIX_round1copy_20261105T185724Z.csv",
    "inputs/first_round_frozen/per_origin_forecasts.csv", "inputs/first_round_frozen/FREEZE_RECORD.json",
    "code/config.py", "code/data_build.py", "code/freeze_guard.py", "code/precheck.py", "code/main_run.py",
    "code/diag_e2d.py", "code/analysis.py", "code/independent_check.py", "code/independent_constants.py",
    "spec/ext_output_fields.md", "spec/ext_tolerances_and_failure_rules.md", "spec/environment.txt",
    "../10_round10_protocol_revision/protocol/expansion_protocol_stage1_v1_review.md",
]
EXPECTED_RESULT_KEYS = 944 * 4                 # unique (origin, rule) rows in results/ext_per_origin.csv (4 new rules)

# ---------------- stage-1 extension ----------------
FIRST_ROUND_RESULTS = INPUTS / "first_round_frozen" / "per_origin_forecasts.csv"
FIRST_ROUND_RESULTS_SHA256 = "da5b06744f5865c8fe4f9aa4e7b1968542acf63346706f2db369c3ea88c84bdb"
FIRST_ROUND_FREEZE_RECORD = INPUTS / "first_round_frozen" / "FREEZE_RECORD.json"
FIRST_ROUND_FREEZE_RECORD_SHA256 = "d5038586075e1ee3914ce78dae79b0b5620e450984914fa04c237ab80f57bc86"
EXT_RULES = ["F2-clip", "F2-Huber", "B1-7-R156", "F2-R156"]
FROZEN_REF_RULES = ["B0", "B1-7", "F2"]         # taken from the frozen first-round results, never recomputed for scoring
CLIP_Q = (1.0, 99.0)                           # percentiles of training VRP_s (numpy.percentile, default linear)
REPRO_TOL = 1e-12                              # |a + c*VRP - frozen yhat| must not exceed this before clipping
HUBER_T, HUBER_MAXITER, HUBER_TOL, HUBER_CONV = 1.345, 50, 1e-8, "coefs"
HUBER_SCALE_EPS = 1e-10                       # final MAD scale below this (log-return units) -> status scale_zero
ROLL_N = 156                                   # most recent matured weekly training labels
E2D_ORIGINS = ["2008-09-24", "2008-10-01", "2008-10-08", "2008-10-15", "2008-10-22",
               "2008-10-29", "2008-11-05", "2008-11-12", "2008-11-19", "2008-11-26"]
E2D_TOP = 5
EXT_COMPARISONS = [("X1", "F2-clip", "F2"), ("X2", "F2-clip", "B1-7"), ("X3", "F2-Huber", "F2"), ("X4", "F2-Huber", "B1-7"),
                   ("X5", "B1-7-R156", "B1-7"), ("X6", "F2-R156", "F2"), ("X7", "F2-R156", "B1-7-R156")]

H = 7                          # horizon, S&P 500 trading days
LOOKBACKS = (5, 21)            # F1 fixed comparisons
RV_N = 21                      # daily log returns in RV
MIN_TRAIN = 260                # matured training labels before an origin is evaluated
HIST_END = date(2026, 11, 4)   # last S&P close used
PARTIAL_ROW_DATE = date(2026, 11, 5)   # intraday row in the raw Yahoo response, must be dropped
VIX_LAUNCH = date(2003, 9, 22) # new-VIX launch; every VIX value used must be dated on/after this
SCHEDULE_FIRST_WED = date(2003, 9, 24)
EXPECTED = dict(n_eligible=1205, n_eval=944, first_eval=date(2008, 9, 24), first_eval_matured=260,
                last_eval=date(2026, 10, 21), last_label_end=date(2026, 10, 30), phase_n=(472, 472))

# Precision (see spec/precision_and_rounding.md)
PRICE_DP = 2                   # S&P 500 is published to 2 dp; Yahoo JSON carries float32 noise.
                               # Raw JSON kept unchanged; working prices = Decimal(repr(raw)).quantize(0.01, ROUND_HALF_UP)
HALF_CENT_GUARD = 1e-6         # stop if any raw close lies within this distance of a half-cent boundary
MAX_YAHOO_ROUNDING = 0.0051    # |raw - round(raw, 2)| must stay below this (else stop)

RULES = ["B0", "B1-7", "F1-5", "F1-21", "F2", "F1-5+F2", "F1-21+F2"]
RULE_REGRESSORS = {            # columns of the design matrix besides the intercept; None = no regression
    "B0": None, "B1-7": [], "F1-5": ["x5"], "F1-21": ["x21"], "F2": ["vrp"],
    "F1-5+F2": ["x5", "vrp"], "F1-21+F2": ["x21", "vrp"],
}
# 15 pre-registered comparisons (A, B): d = loss_A - loss_B ; negative = A better
COMPARISONS = [
    ("P1", "F1-5", "B0"), ("P1", "F1-5", "B1-7"), ("P1", "F1-21", "B0"), ("P1", "F1-21", "B1-7"),
    ("P1", "F2", "B0"), ("P1", "F2", "B1-7"),
    ("P2", "F1-5+F2", "F1-5"), ("P2", "F1-21+F2", "F1-21"),
    ("P3", "F1-5+F2", "F2"), ("P3", "F1-21+F2", "F2"),
    ("P4", "F1-5+F2", "B0"), ("P4", "F1-5+F2", "B1-7"), ("P4", "F1-21+F2", "B0"), ("P4", "F1-21+F2", "B1-7"),
    ("P5", "B1-7", "B0"),
]
DESCRIPTIVE_COMPARISONS = [("D1", "F1-5", "F1-21")]
Z90, Z95 = 1.6448536269514722, 1.959963984540054   # standard normal critical values
HAC_MAXLAGS = 1
BOOT_BLOCK, BOOT_B, BOOT_SEED = 4, 2000, 20261111
SUBPERIODS = [("2008-09..2009", date(2008, 9, 1), date(2009, 12, 31)), ("2010-2014", date(2010, 1, 1), date(2014, 12, 31)),
              ("2015-2019", date(2015, 1, 1), date(2019, 12, 31)), ("2020-2026", date(2020, 1, 1), date(2026, 12, 31))]
STRESS = [("GFC 2008-09..2009-03", date(2008, 9, 1), date(2009, 3, 31)), ("COVID 2020-02..2020-04", date(2020, 2, 1), date(2020, 4, 30)),
          ("2022", date(2022, 1, 1), date(2022, 12, 31))]
