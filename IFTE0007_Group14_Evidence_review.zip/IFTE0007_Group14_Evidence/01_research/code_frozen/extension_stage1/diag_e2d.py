"""E2d training-influence diagnostic (round 11).  *** Fits OLS on project data — requires Zhi's freeze approval. ***
Diagnostic only: produces NO forecast, NO score, and is NOT used in any comparison.

For each origin in C.E2D_ORIGINS (2008-09-24 .. 2008-11-26, 10 origins) and its first-round F2 training set
(matured labels, VRP_s regressor with intercept, OLS):
  h_jj        leverage, diagonal of X (X'X)^-1 X'
  e_j         OLS residual
  r_j         internally studentised residual  = e_j / (s * sqrt(1 - h_jj)),   s^2 = SSR / (n - 2)
  t_j         externally studentised residual  = e_j / (s_(j) * sqrt(1 - h_jj)), s_(j)^2 = ((n-2) s^2 - e_j^2/(1-h_jj)) / (n - 3)
  dslope_j    change in the VRP slope when label j is removed: c_hat - c_hat_(-j), computed in closed form
              (DFBETA: beta - beta_(-j) = (X'X)^-1 x_j e_j / (1 - h_jj))
RANKING (pre-registered): labels are ranked by |dslope_j| (absolute change of the VRP slope), descending; the top
C.E2D_TOP (=5) per origin are reported. As an internal check, the slope for the top-ranked label is also re-estimated by
an explicit leave-one-out OLS and must equal the closed form within 1e-10.
Also reported per origin: n, c_hat, the frozen first-round c (must match within 1e-10), and the share of
sum(|dslope|) contributed by the top label.
Output: ../results/e2d_influence.csv, ../results/e2d_summary.csv, ../results/e2d_manifest.json
"""
import csv, json, sys
from datetime import date
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG


def main():
    rec, freeze_id = FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)
    d = DB.load(); rows, _ = DB.build(d)
    if DB.sha256(C.FIRST_ROUND_RESULTS) != C.FIRST_ROUND_RESULTS_SHA256:
        print("STOP: frozen results hash", file=sys.stderr); raise SystemExit(3)
    frozen = {(r["origin"], r["rule"]): r for r in csv.DictReader(open(C.FIRST_ROUND_RESULTS))}
    pos = {str(r["origin"]): k for k, r in enumerate(rows)}
    out = C.STAGE / "results"; out.mkdir(exist_ok=True)
    det, summ = [], []
    for o in C.E2D_ORIGINS:
        k = pos[o]; tp = DB.training_positions(rows, k); n = len(tp)
        X = np.column_stack([np.ones(n), [rows[j]["vrp"] for j in tp]]); y = np.array([rows[j]["y"] for j in tp])
        XtXi = np.linalg.inv(X.T @ X); beta = XtXi @ X.T @ y; e = y - X @ beta
        h = np.einsum("ij,jk,ik->i", X, XtXi, X)
        s2 = e @ e / (n - 2); s2j = ((n - 2) * s2 - e ** 2 / (1 - h)) / (n - 3)
        r_int = e / np.sqrt(s2 * (1 - h)); t_ext = e / np.sqrt(s2j * (1 - h))
        dfb = (XtXi @ X.T).T * (e / (1 - h))[:, None]          # beta - beta_(-j), rows j
        dslope = dfb[:, 1]
        fc = float(frozen[(o, "F2")]["coef_vrp"])
        if abs(beta[1] - fc) > 1e-10:
            print(f"STOP: slope at {o} differs from frozen F2", file=sys.stderr); raise SystemExit(3)
        order = np.argsort(-np.abs(dslope))
        j0 = order[0]; keep = np.ones(n, bool); keep[j0] = False
        b_loo = np.linalg.lstsq(X[keep], y[keep], rcond=None)[0]
        if abs((beta[1] - b_loo[1]) - dslope[j0]) > 1e-10:
            print(f"STOP: closed-form DFBETA check failed at {o}", file=sys.stderr); raise SystemExit(3)
        for rank, j in enumerate(order[:C.E2D_TOP], 1):
            s = rows[tp[j]]
            det.append({"origin": o, "rank": rank, "label_origin": s["origin"], "label_end": s["target_date"], "vrp_s": repr(s["vrp"]),
                        "y_s": repr(s["y"]), "leverage_h": repr(h[j]), "resid": repr(e[j]), "studentized_internal": repr(r_int[j]),
                        "studentized_external": repr(t_ext[j]), "dslope_c_minus_c_without_j": repr(dslope[j]),
                        "slope_without_j": repr(beta[1] - dslope[j])})
        summ.append({"origin": o, "n_train": n, "c_hat": repr(beta[1]), "frozen_c": repr(fc), "a_hat": repr(beta[0]),
                     "top_label": rows[tp[j0]]["origin"], "top_dslope": repr(dslope[j0]),
                     "top_share_of_sum_abs_dslope": repr(abs(dslope[j0]) / np.abs(dslope).sum()),
                     "max_leverage": repr(h.max()), "label_with_max_leverage": rows[tp[int(np.argmax(h))]]["origin"]})
    for name, data in (("e2d_influence.csv", det), ("e2d_summary.csv", summ)):
        with open(out / name, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0].keys())); w.writeheader(); w.writerows(data)
    (out / "e2d_manifest.json").write_text(json.dumps({"freeze_id": freeze_id, "diagnostic_only": True,
        "outputs_sha256": {n: DB.sha256(out / n) for n in ("e2d_influence.csv", "e2d_summary.csv")}}, indent=1))
    print("e2d done", len(summ), "origins")


if __name__ == "__main__":
    main()
