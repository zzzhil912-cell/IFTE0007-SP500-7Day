"""Freeze guard shared by main_run.py and analysis.py (independent_check.py has its own copy of the logic).

A run is allowed only if ALL of these hold (round-6 revision, after Zhi's review):
  1. <stage>/FREEZE_RECORD.json exists and is valid JSON
  2. approved_by equals the required approver and approved_utc is a valid ISO-8601 UTC time
  3. the record's "sha256" map is non-empty and contains EVERY file in the required list
     (config.REQUIRED_FREEZE_FILES plus the hard-coded CORE list below)
  4. every listed file exists and its SHA-256 matches
Any failure -> message on stderr and exit code 2 (refusal). Returns (record, freeze_id).
freeze_id = SHA-256 of the canonical JSON of {approved_by, approved_utc, sha256 map}; results carry it so
analysis / independent check can confirm they use outputs of THIS freeze.
"""
import hashlib, json, sys
from datetime import datetime
from pathlib import Path

CORE = ["code/config.py", "code/data_build.py", "code/freeze_guard.py", "code/main_run.py",
        "code/analysis.py", "code/independent_check.py", "code/independent_constants.py"]
REFUSE_EXIT = 2


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
    return h.hexdigest()


def refuse(msg):
    print(f"REFUSED: {msg}", file=sys.stderr)
    raise SystemExit(REFUSE_EXIT)


def freeze_id_of(rec):
    canon = json.dumps({"approved_by": rec["approved_by"], "approved_utc": rec["approved_utc"],
                        "sha256": dict(sorted(rec["sha256"].items()))}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode()).hexdigest()


def verify(stage, required, approver):
    stage = Path(stage)
    fr = stage / "FREEZE_RECORD.json"
    if not fr.exists():
        refuse("no FREEZE_RECORD.json")
    try:
        rec = json.loads(fr.read_text())
    except Exception as e:
        refuse(f"FREEZE_RECORD.json unreadable: {e}")
    if rec.get("approved_by") != approver:
        refuse(f"approver check failed: approved_by is {rec.get('approved_by')!r}, required {approver!r}")
    try:
        t = datetime.fromisoformat(str(rec.get("approved_utc", "")).replace("Z", "+00:00"))
        if t.tzinfo is None: raise ValueError("no timezone")
    except Exception as e:
        refuse(f"approved_utc missing or invalid ({e})")
    files = rec.get("sha256")
    if not isinstance(files, dict) or not files:
        refuse("sha256 file list is empty")
    need = sorted(set(required) | set(CORE))
    missing = [p for p in need if p not in files]
    if missing:
        refuse(f"required files missing from freeze record: {missing}")
    for rel, h in sorted(files.items()):
        p = stage / rel
        if not p.exists():
            refuse(f"listed file does not exist: {rel}")
        got = sha256(p)
        if got != h:
            refuse(f"hash mismatch for {rel}: record {h[:12]}..., file {got[:12]}...")
    return rec, freeze_id_of(rec)
