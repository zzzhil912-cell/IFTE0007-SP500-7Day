"""Stage-1 extension backtest main run (round 11).  *** FITS MODELS (E2, E3) — requires Zhi's freeze approval. ***

Rules (944 evaluation origins, same as the frozen first round; d = A - B later in analysis.py):
  F2-clip    E1: FROZEN first-round F2 coefficients (a_t, c_t) read from inputs/first_round_frozen/per_origin_forecasts.csv.
             Step 1: verify a_t + c_t * VRP_{t-1} reproduces the frozen F2 yhat at EVERY origin (|diff| <= REPRO_TOL), else STOP (exit 3).
             Step 2: clip ONLY the origin input: x_t = min(max(VRP_{t-1}, q01_t), q99_t), q = numpy.percentile of the VRP_s of the
             origin's matured training labels (the same training set as the first round). Training regressors are NOT clipped
             and NO re-estimation is done.  yhat = a_t + c_t * x_t.
  F2-Huber   E2: statsmodels RLM, HuberT(t=1.345), scale_est='mad' (center 0), conv='coefs', tol=1e-8, maxiter=50, same training set
             and unclipped input. Status per origin (pre-registered, written before any result):
               'converged'      max |params_k - params_{k-1}| <= tol at the last iteration
               'not_converged'  stopped at maxiter without meeting tol -> last-iteration params are used, row flagged
               'scale_zero'     final MAD scale < HUBER_SCALE_EPS (1e-10), incl. statsmodels stopping at scale 0 (near-perfect fit)
                                -> params at stop are used, flagged (threshold added after self-test run 2: statsmodels and the
                                independent IRLS disagreed on an exact-zero vs 1.6e-16 scale)
               'error'          estimation raised an exception -> forecast falls back to the frozen F2-OLS yhat, flagged
             Flagged origins are NOT removed from scoring; analysis reports their count and a converged-only description.
  B1-7-R156  E3: mean y over the most recent ROLL_N matured weekly training labels.
  F2-R156    E3: OLS (numpy.linalg.lstsq, intercept) on the same ROLL_N labels, unclipped input.
Guard: freeze_guard.verify (approver Zhi, complete required list incl. the first-round frozen results copy, hashes).
Output: ../results/ext_per_origin.csv (944 x 4 rows; fields in ../spec/ext_output_fields.md) and ../results/main_run_manifest.json.
Exit codes: 0 ok, 2 refused by guard, 3 integrity stop (reproduction / count / input mismatch).
"""
import csv, json, math, sys, warnings
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG


def stop(msg):
    print(f"STOP: {msg}", file=sys.stderr); raise SystemExit(3)


def round2(x):
    return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def huber_fit(y, X):
    """Pre-registered Huber estimation. Returns (params, status, n_iter, n_downweighted)."""
    import statsmodels.api as sm
    from statsmodels.tools.sm_exceptions import ConvergenceWarning
    try:
        with warnings.catch_warnings(record=True) as wlist:
            warnings.simplefilter("always")
            res = sm.RLM(y, X, M=sm.robust.norms.HuberT(t=C.HUBER_T)).fit(
                maxiter=C.HUBER_MAXITER, tol=C.HUBER_TOL, scale_est="mad", conv=C.HUBER_CONV)
        params = np.asarray(res.params, dtype=float)
        hist = res.fit_history["params"]; n_iter = int(res.fit_history["iteration"])
        if not np.all(np.isfinite(params)):
            return None, "error", n_iter, -1
        scale0 = any(issubclass(w.category, ConvergenceWarning) and "scale is 0.0" in str(w.message) for w in wlist)
        if scale0 or float(res.scale) < C.HUBER_SCALE_EPS:
            status = "scale_zero"
        else:
            step = np.max(np.abs(np.asarray(hist[-1]) - np.asarray(hist[-2]))) if len(hist) >= 3 else np.inf
            status = "converged" if step <= C.HUBER_TOL else "not_converged"
        ndw = int(np.sum(np.asarray(res.weights) < 1.0))
        return params, status, n_iter, ndw
    except Exception as e:                                   # pre-registered failure path
        return None, "error", 0, -1


def load_frozen():
    if DB.sha256(C.FIRST_ROUND_RESULTS) != C.FIRST_ROUND_RESULTS_SHA256:
        stop("first-round frozen results copy does not match its recorded SHA-256")
    rows = list(csv.DictReader(open(C.FIRST_ROUND_RESULTS)))
    by = {(r["origin"], r["rule"]): r for r in rows}
    if len(by) != 944 * 7 or len(rows) != 944 * 7:
        stop("first-round frozen results do not have 6,608 unique rows")
    return by


def main():
    rec, freeze_id = FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    d = DB.load()
    if not all(ok for _, ok, _ in DB.validate_index(d)): stop("trading-day index validation failed")
    rows, _ = DB.build(d)
    ev = DB.evaluation_positions(rows)
    if len(ev) != C.EXPECTED["n_eval"] or rows[ev[0]]["origin"] != C.EXPECTED["first_eval"]: stop("evaluation origins differ from protocol")
    frozen = load_frozen()
    # ---- E1 step 1: reproduction of frozen F2 yhat with frozen coefficients, at every origin, before any clipping ----
    repro = []
    for k in ev:
        r = rows[k]; f = frozen[(str(r["origin"]), "F2")]
        if f["vix_date"] != str(r["vix_date"]) or abs(float(f["vrp"]) - r["vrp"]) > 1e-10:
            stop(f"VRP input mismatch with frozen file at {r['origin']}")
        a, c = float(f["coef_intercept"]), float(f["coef_vrp"])
        repro.append(abs(a + c * r["vrp"] - float(f["yhat"])))
    if max(repro) > C.REPRO_TOL: stop(f"unclipped reproduction failed: max |diff| = {max(repro):.3e}")
    out = C.STAGE / "results"; out.mkdir(exist_ok=True)
    fields = ["origin", "rule", "base_close", "target_date", "target_close", "y_actual", "vix_date", "vrp",
              "vrp_input_used", "clip_lo", "clip_hi", "clipped", "repro_abs_diff_unclipped",
              "n_train", "first_train_origin", "last_train_origin", "last_train_label_end",
              "coef_intercept", "coef_vrp", "huber_status", "huber_iterations", "huber_n_downweighted",
              "yhat", "forecast_full", "forecast_2dp", "ape_2dp", "ape_full", "abs_err_logret_bp"]
    path = out / "ext_per_origin.csv"; n_rows = 0; status_count = {}
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader()
        for k, rp in zip(ev, repro):
            r = rows[k]; tp = DB.training_positions(rows, k)
            if max(rows[j]["target_date"] for j in tp) > r["origin"]: stop("training label after origin")
            f = frozen[(str(r["origin"]), "F2")]
            vrp_tr = np.array([rows[j]["vrp"] for j in tp]); y_tr = np.array([rows[j]["y"] for j in tp])
            out_rows = []
            # E1
            lo, hi = np.percentile(vrp_tr, C.CLIP_Q[0]), np.percentile(vrp_tr, C.CLIP_Q[1])
            x = min(max(r["vrp"], lo), hi); a, c = float(f["coef_intercept"]), float(f["coef_vrp"])
            out_rows.append(dict(rule="F2-clip", tp=tp, a=a, c=c, yhat=a + c * x, vin=x, lo=lo, hi=hi, clipped=int(x != r["vrp"]), rp=rp))
            # E2
            X = np.column_stack([np.ones(len(tp)), vrp_tr])
            params, status, nit, ndw = huber_fit(y_tr, X)
            status_count[status] = status_count.get(status, 0) + 1
            if status == "error":
                yh = float(f["yhat"]); a2 = c2 = None
            else:
                a2, c2 = float(params[0]), float(params[1]); yh = a2 + c2 * r["vrp"]
            out_rows.append(dict(rule="F2-Huber", tp=tp, a=a2, c=c2, yhat=yh, vin=r["vrp"], hs=status, hi_=nit, ndw=ndw))
            # E3
            tr = tp[-C.ROLL_N:]
            if len(tr) != C.ROLL_N: stop(f"fewer than {C.ROLL_N} matured labels at {r['origin']}")
            yr = np.array([rows[j]["y"] for j in tr])
            out_rows.append(dict(rule="B1-7-R156", tp=tr, a=float(yr.mean()), c=None, yhat=float(yr.mean()), vin=None))
            Xr = np.column_stack([np.ones(len(tr)), [rows[j]["vrp"] for j in tr]])
            beta, *_ = np.linalg.lstsq(Xr, yr, rcond=None)
            out_rows.append(dict(rule="F2-R156", tp=tr, a=float(beta[0]), c=float(beta[1]), yhat=float(beta[0] + beta[1] * r["vrp"]), vin=r["vrp"]))
            for o in out_rows:
                F = r["base_close"] * math.exp(o["yhat"]); F2 = round2(F); A = r["target_close"]; t_ = o["tp"]
                w.writerow({"origin": r["origin"], "rule": o["rule"], "base_close": f"{r['base_close']:.2f}", "target_date": r["target_date"],
                            "target_close": f"{A:.2f}", "y_actual": repr(r["y"]), "vix_date": r["vix_date"], "vrp": repr(r["vrp"]),
                            "vrp_input_used": "" if o["vin"] is None else repr(o["vin"]),
                            "clip_lo": repr(o["lo"]) if "lo" in o else "", "clip_hi": repr(o["hi"]) if "hi" in o else "",
                            "clipped": o.get("clipped", ""), "repro_abs_diff_unclipped": repr(o["rp"]) if "rp" in o else "",
                            "n_train": len(t_), "first_train_origin": rows[t_[0]]["origin"], "last_train_origin": rows[t_[-1]]["origin"],
                            "last_train_label_end": max(rows[j]["target_date"] for j in t_),
                            "coef_intercept": "" if o["a"] is None else repr(o["a"]), "coef_vrp": "" if o["c"] is None else repr(o["c"]),
                            "huber_status": o.get("hs", ""), "huber_iterations": o.get("hi_", ""), "huber_n_downweighted": o.get("ndw", ""),
                            "yhat": repr(o["yhat"]), "forecast_full": repr(F), "forecast_2dp": f"{F2:.2f}",
                            "ape_2dp": repr(100 * abs(F2 - A) / A), "ape_full": repr(100 * abs(F - A) / A),
                            "abs_err_logret_bp": repr(1e4 * abs(o["yhat"] - r["y"]))})
                n_rows += 1
    if n_rows != C.EXPECTED_RESULT_KEYS: stop(f"{n_rows} rows, expected {C.EXPECTED_RESULT_KEYS}")
    man = {"freeze_id": freeze_id, "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "n_rows": n_rows, "max_repro_abs_diff_unclipped": max(repro), "huber_status_counts": status_count,
           "first_round_results_sha256": C.FIRST_ROUND_RESULTS_SHA256, "python": sys.version, "numpy": np.__version__,
           "output_sha256": {path.name: DB.sha256(path)}}
    (out / "main_run_manifest.json").write_text(json.dumps(man, indent=1, default=str))
    print("done", json.dumps({"rows": n_rows, "max_repro": max(repro), "huber": status_count}))


if __name__ == "__main__":
    main()
