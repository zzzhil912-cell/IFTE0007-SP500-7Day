"""Stage-1 extension precheck (round 11). NO model fitting on project data, no new forecasts, no new errors.

Allowed arithmetic only: data construction (frozen data_build), percentiles of input data, and a + c*VRP with the
FROZEN first-round F2 coefficients (to verify the unclipped reproduction required before E1 clipping).
Run: python -I precheck.py   -> ../precheck/precheck_output.txt, precheck_results.json ; exit 1 on any failure.
"""
import csv, hashlib, json, subprocess, sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB

OUT = C.STAGE / "precheck"; OUT.mkdir(exist_ok=True)
res, lines = [], []
def say(s): print(s); lines.append(s)
def check(name, ok, detail=""):
    res.append({"check": name, "passed": bool(ok), "detail": detail}); say(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))

say(f"extension precheck at {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
# 1. frozen first-round material
say("\n== 1. first-round frozen material")
check("first-round results copy SHA-256 == frozen", DB.sha256(C.FIRST_ROUND_RESULTS) == C.FIRST_ROUND_RESULTS_SHA256, C.FIRST_ROUND_RESULTS_SHA256[:16])
check("first-round FREEZE_RECORD copy SHA-256 == frozen", DB.sha256(C.FIRST_ROUND_FREEZE_RECORD) == C.FIRST_ROUND_FREEZE_RECORD_SHA256)
orig06 = C.STAGE.parent / "06_round6_code_revision"
if orig06.exists():
    bad = []
    for l in (orig06 / "SHA256_to_freeze.txt").read_text().splitlines():
        if l.startswith("#") or not l.strip(): continue
        h, rel = l.split("  ", 1)
        if DB.sha256(orig06 / rel) != h: bad.append(rel)
    check("all 17 first-round frozen files unchanged in 06_round6_code_revision", not bad, str(bad))
    check("first-round results in 06 unchanged", DB.sha256(orig06 / "results" / "per_origin_forecasts.csv") == C.FIRST_ROUND_RESULTS_SHA256)
    check("data_build.py and freeze_guard.py are byte-identical to the frozen first-round modules",
          DB.sha256(C.STAGE / "code" / "data_build.py") == DB.sha256(orig06 / "code" / "data_build.py") and
          DB.sha256(C.STAGE / "code" / "freeze_guard.py") == DB.sha256(orig06 / "code" / "freeze_guard.py"))
else:
    say("  (06_round6_code_revision not present: synthetic stage; first-round comparison skipped)")
fr = list(csv.DictReader(open(C.FIRST_ROUND_RESULTS)))
fk = [(r["origin"], r["rule"]) for r in fr]
check("frozen results: 6,608 unique keys", len(fk) == 6608 and len(set(fk)) == 6608)
# 2. data and origins
say("\n== 2. data, index and origins")
d = DB.load()
for name, ok, det in DB.validate_index(d): check(name, ok, det)
rows, _ = DB.build(d); ev = DB.evaluation_positions(rows)
E = [rows[k] for k in ev]; S = [str(r["origin"]) for r in E]
check("944 common evaluation origins, first 2008-09-24, last 2026-10-21",
      len(E) == 944 and S[0] == "2008-09-24" and S[-1] == "2026-10-21")
check("first origin has exactly 260 matured labels", len(DB.training_positions(rows, ev[0])) == 260)
fs = sorted({o for o, r in fk if r == "F2"})
check("origin set == first-round frozen origin set (all 944)", S == fs)
F2 = {r["origin"]: r for r in fr if r["rule"] == "F2"}
check("target dates, VIX dates and VRP equal the frozen file at every origin",
      all(F2[s]["target_date"] == str(r["target_date"]) and F2[s]["vix_date"] == str(r["vix_date"]) and abs(float(F2[s]["vrp"]) - r["vrp"]) <= 1e-10
          for s, r in zip(S, E)))
# 3. E1 prerequisites (no fitting)
say("\n== 3. E1: unclipped reproduction with FROZEN coefficients; thresholds")
rep = [abs(float(F2[s]["coef_intercept"]) + float(F2[s]["coef_vrp"]) * r["vrp"] - float(F2[s]["yhat"])) for s, r in zip(S, E)]
check(f"a + c*VRP reproduces frozen F2 yhat at all 944 origins (|diff| <= {C.REPRO_TOL})", max(rep) <= C.REPRO_TOL, f"max |diff| = {max(rep):.3e}")
n_clip = 0
for k, r in zip(ev, E):
    tp = DB.training_positions(rows, k); v = np.array([rows[j]["vrp"] for j in tp])
    lo, hi = np.percentile(v, C.CLIP_Q[0]), np.percentile(v, C.CLIP_Q[1]); n_clip += int(r["vrp"] < lo or r["vrp"] > hi)
check("clip thresholds computable from matured training VRP at every origin", True, f"origins whose input lies outside [q01, q99]: {n_clip} (count only)")
# 4. E3 and E2d prerequisites
say("\n== 4. E3 / E2d prerequisites")
check(f"every origin has >= {C.ROLL_N} matured weekly labels", all(len(DB.training_positions(rows, k)) >= C.ROLL_N for k in ev))
check("rolling windows end at the latest matured label (idx(s)+7 <= idx(t))",
      all(rows[DB.training_positions(rows, k)[-1]]["target_date"] <= rows[k]["origin"] for k in ev))
check("10 E2d origins are evaluation origins", set(C.E2D_ORIGINS) <= set(S), str(C.E2D_ORIGINS))
# 5. comparisons
say("\n== 5. comparisons")
proto = [("X1", "F2-clip", "F2"), ("X2", "F2-clip", "B1-7"), ("X3", "F2-Huber", "F2"), ("X4", "F2-Huber", "B1-7"),
         ("X5", "B1-7-R156", "B1-7"), ("X6", "F2-R156", "F2"), ("X7", "F2-R156", "B1-7-R156")]
check("7 comparisons == protocol X1-X7", list(C.EXT_COMPARISONS) == proto)
check("every compared rule is a new rule or a frozen reference rule",
      all(a in C.EXT_RULES + C.FROZEN_REF_RULES and b in C.EXT_RULES + C.FROZEN_REF_RULES for _, a, b in C.EXT_COMPARISONS))
check("frozen reference rules present for all 944 origins", all((s, r) in set(fk) for s in S for r in C.FROZEN_REF_RULES))
check("expected new result keys == 944 x 4 == 3776", len(E) * len(C.EXT_RULES) == C.EXPECTED_RESULT_KEYS == 3776)
# 6. freeze prerequisites
say("\n== 6. freeze prerequisites")
miss = [rel for rel in C.REQUIRED_FREEZE_FILES if not (C.STAGE / rel).exists()]
check("every required freeze file exists", not miss, f"{len(C.REQUIRED_FREEZE_FILES)} files; missing {miss}")
check("no FREEZE_RECORD.json in this stage", not C.FREEZE_RECORD.exists())
for s in ("main_run.py", "diag_e2d.py", "analysis.py", "independent_check.py"):
    pr = subprocess.run([sys.executable, "-I", str(Path(__file__).resolve().parent / s)], capture_output=True, text=True)
    check(f"{s} refuses without a freeze record (exit 2)", pr.returncode == 2 and "no FREEZE_RECORD" in pr.stderr, f"exit {pr.returncode}")
check("no results directory created", not (C.STAGE / "results").exists())
nf = sum(1 for r in res if not r["passed"]); say(f"\nSUMMARY: {len(res)} checks, {nf} failed")
(OUT / "precheck_output.txt").write_text("\n".join(lines) + "\n"); (OUT / "precheck_results.json").write_text(json.dumps(res, indent=1))
sys.exit(1 if nf else 0)
