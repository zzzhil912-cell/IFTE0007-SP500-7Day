"""Independent recomputation for the stage-1 extension (round 11).  *** Requires freeze approval. ***

Does NOT import config.py, data_build.py, freeze_guard.py, main_run.py, diag_e2d.py or analysis.py.
Different computation paths: pandas rebuild of data and schedule; E1 thresholds from pandas-built training arrays and the
frozen coefficients read separately; E2 Huber by an OWN IRLS loop (weights min(1, t/|z|), MAD scale with centre 0 and
constant 0.6744897501960817, convergence when max |params change| <= tol, maxiter 50, stop when scale is 0) instead of
statsmodels RLM; E3 rolling OLS from window differences of cumulative X'X / X'y with numpy.linalg.solve; HAC by hand.
Checks: own freeze check (exit 2); results tied to this freeze and to the frozen first-round file (exit 2);
exactly 3,776 unique (origin, rule) keys equal to the rebuilt set; every committed field (tolerances in
independent_constants.TOL and spec/ext_tolerances_and_failure_rules.md); Huber status equal; hand HAC for X1-X7.
Failures -> results/independent_check_report.json with passed=false and exit 1.
"""
import hashlib, json, math, sys
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import independent_constants as K

STAGE = Path(__file__).resolve().parent.parent
RES = STAGE / "results"
MADC = 0.6744897501960817


def _sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _refuse(msg): print(f"REFUSED: {msg}", file=sys.stderr); raise SystemExit(2)


def own_freeze_check():
    fr = STAGE / "FREEZE_RECORD.json"
    if not fr.exists(): _refuse("no FREEZE_RECORD.json")
    try: rec = json.loads(fr.read_text())
    except Exception as e: _refuse(f"unreadable freeze record: {e}")
    if rec.get("approved_by") != K.APPROVER: _refuse(f"approver {rec.get('approved_by')!r} != {K.APPROVER!r}")
    try:
        if datetime.fromisoformat(str(rec.get("approved_utc", "")).replace("Z", "+00:00")).tzinfo is None: raise ValueError
    except Exception: _refuse("approved_utc missing or invalid")
    files = rec.get("sha256")
    if not isinstance(files, dict) or not files: _refuse("empty sha256 list")
    miss = [p for p in K.REQUIRED if p not in files]
    if miss: _refuse(f"required files missing from record: {miss}")
    for rel, h in files.items():
        p = STAGE / rel
        if not p.exists() or _sha(p) != h: _refuse(f"hash mismatch or missing file: {rel}")
    canon = json.dumps({"approved_by": rec["approved_by"], "approved_utc": rec["approved_utc"], "sha256": dict(sorted(files.items()))},
                       sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode()).hexdigest()


def tie(fid):
    for p in (RES / "main_run_manifest.json", RES / "ext_per_origin.csv", RES / "analysis" / "analysis_manifest.json", RES / "analysis" / "comparisons.csv"):
        if not p.exists(): _refuse(f"missing {p.relative_to(STAGE)}")
    mm = json.loads((RES / "main_run_manifest.json").read_text()); am = json.loads((RES / "analysis" / "analysis_manifest.json").read_text())
    if mm.get("freeze_id") != fid or am.get("freeze_id") != fid: _refuse("results not produced under this freeze")
    h = _sha(RES / "ext_per_origin.csv")
    if h != mm["output_sha256"]["ext_per_origin.csv"] or am.get("results_sha256") != h: _refuse("ext results hash != manifests")
    if _sha(RES / "analysis" / "comparisons.csv") != am["outputs_sha256"]["comparisons.csv"]: _refuse("comparisons.csv hash != analysis manifest")
    if _sha(STAGE / K.FROZEN) != K.FROZEN_SHA256: _refuse("first-round frozen results hash mismatch")


def rebuild():
    j = json.loads((STAGE / K.RAW_Y).read_text())["chart"]["result"][0]
    s = pd.Series(j["indicators"]["quote"][0]["close"],
                  index=pd.to_datetime(j["timestamp"], unit="s", utc=True).tz_convert("America/New_York").normalize().tz_localize(None))
    s = s[(s.index != pd.Timestamp(K.PARTIAL)) & (s.index <= pd.Timestamp(K.HIST_END))].astype(float).round(2)
    v = pd.read_csv(STAGE / K.RAW_V)
    v = pd.Series(v["CLOSE"].astype(float).to_numpy(), index=pd.to_datetime(v["DATE"], format="%m/%d/%Y"))
    df = pd.DataFrame({"P": s}); df["vix"] = v.reindex(df.index); r = np.log(df["P"]).diff()
    df["x5"] = np.log(df["P"] / df["P"].shift(5)); df["x21"] = np.log(df["P"] / df["P"].shift(21))
    df["vix_date"] = pd.Series(df.index, index=df.index).shift(1)
    df["vrp"] = df["vix"].shift(1) ** 2 / 12 - 1e4 * (r ** 2).rolling(21).sum().shift(1)
    df["target_date"] = pd.Series(df.index, index=df.index).shift(-K.H); df["PT"] = df["P"].shift(-K.H)
    df["y"] = np.log(df["PT"] / df["P"]); df["pos"] = np.arange(len(df))
    weds = pd.date_range(pd.Timestamp(K.FIRST_WED), pd.Timestamp(K.HIST_END), freq="7D")
    o = df.loc[pd.Index(df.index[df.index.searchsorted(weds, side="right") - 1]).unique()]
    return o[(o["vix_date"] >= pd.Timestamp(K.LAUNCH)) & o[["x5", "x21", "vrp", "y"]].notna().all(axis=1)].copy()


def irls_huber(y, X):
    """Own Huber IRLS. Returns (params, status, iterations)."""
    try:
        p = np.linalg.lstsq(X, y, rcond=None)[0]; res = y - X @ p
        scale = np.median(np.abs(res)) / MADC
        hist = [np.full(X.shape[1], np.inf), p]; it = 1
        while True:
            if scale == 0.0: return p, "scale_zero", it
            z = np.abs(res / scale); w = np.where(z <= K.HUBER_T, 1.0, K.HUBER_T / np.where(z == 0, 1, z))
            sw = np.sqrt(w); p = np.linalg.lstsq(X * sw[:, None], y * sw, rcond=None)[0]; res = y - X @ p
            scale = np.median(np.abs(res)) / MADC; hist.append(p); it += 1
            step = np.max(np.abs(hist[-1] - hist[-2]))
            if not (step > K.HUBER_TOL and it < K.HUBER_MAXITER): break
        if not np.all(np.isfinite(p)): return None, "error", it
        if scale < K.HUBER_SCALE_EPS: return p, "scale_zero", it
        return p, ("converged" if step <= K.HUBER_TOL else "not_converged"), it
    except Exception:
        return None, "error", 0


def r2(x): return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def main():
    fid = own_freeze_check(); tie(fid)
    o = rebuild(); pos = o["pos"].to_numpy(); n = len(o); y = o["y"].to_numpy(); vrp = o["vrp"].to_numpy()
    mat = np.searchsorted(pos + K.H, pos, side="right"); first = int(np.argmax(mat >= K.MINTR))
    fr = pd.read_csv(STAGE / K.FROZEN, dtype=str, keep_default_na=False)
    f2 = fr[fr.rule == "F2"].set_index("origin")
    X = np.column_stack([np.ones(n), vrp])
    XX = np.concatenate([np.zeros((1, 2, 2)), np.cumsum(X[:, :, None] * X[:, None, :], axis=0)])
    Xy = np.concatenate([np.zeros((1, 2)), np.cumsum(X * y[:, None], axis=0)]); cy = np.concatenate([[0.0], np.cumsum(y)])
    exp = {}
    for t in range(first, n):
        m = mat[t]; ot = str(o.index[t].date()); fz = f2.loc[ot]
        a, c = float(fz["coef_intercept"]), float(fz["coef_vrp"])
        lo, hi = np.percentile(vrp[:m], K.Q[0]), np.percentile(vrp[:m], K.Q[1]); x = min(max(vrp[t], lo), hi)
        common = dict(P=o["P"].iloc[t], PT=o["PT"].iloc[t], y=y[t], tdate=str(o["target_date"].iloc[t].date()), vdate=str(o["vix_date"].iloc[t].date()), vrp=vrp[t])
        exp[(ot, "F2-clip")] = dict(common, yhat=a + c * x, a=a, c=c, m=m, f=0, l=m - 1, lo=lo, hi=hi, cl=int(x != vrp[t]), vin=x,
                                    repro=abs(a + c * vrp[t] - float(fz["yhat"])), kind="ols")
        p, st, it = irls_huber(y[:m], X[:m])
        yh = float(fz["yhat"]) if st == "error" else float(p[0] + p[1] * vrp[t])
        exp[(ot, "F2-Huber")] = dict(common, yhat=yh, a=None if p is None else p[0], c=None if p is None else p[1], m=m, f=0, l=m - 1, hs=st, it=it, vin=vrp[t], kind="huber")
        s0 = m - K.ROLL
        exp[(ot, "B1-7-R156")] = dict(common, yhat=(cy[m] - cy[s0]) / K.ROLL, a=(cy[m] - cy[s0]) / K.ROLL, c=None, m=K.ROLL, f=s0, l=m - 1, kind="ols")
        b = np.linalg.solve(XX[m] - XX[s0], Xy[m] - Xy[s0])
        exp[(ot, "F2-R156")] = dict(common, yhat=b[0] + b[1] * vrp[t], a=b[0], c=b[1], m=K.ROLL, f=s0, l=m - 1, vin=vrp[t], kind="ols")
    raw = pd.read_csv(RES / "ext_per_origin.csv", dtype=str, keep_default_na=False)
    fails, boundary = [], []; fail = fails.append
    keys = list(zip(raw["origin"], raw["rule"])); cnt = pd.Series(keys).value_counts()
    if len(keys) != K.EXPECTED_KEYS: fail(f"KEYS: {len(keys)} rows, expected {K.EXPECTED_KEYS}")
    if len(exp) != K.EXPECTED_KEYS: fail(f"KEYS: independent rebuild has {len(exp)} keys")
    dup = sorted(k for k, c in cnt.items() if c > 1)
    if dup: fail(f"KEYS: duplicated (origin, rule): {dup[:10]}")
    miss = sorted(set(exp) - set(keys)); extra = sorted(set(keys) - set(exp))
    if miss: fail(f"KEYS: missing {len(miss)}: {miss[:10]}")
    if extra: fail(f"KEYS: unexpected {len(extra)}: {extra[:10]}")
    oi = o.index
    for _, r in raw.drop_duplicates(["origin", "rule"]).iterrows():
        k = (r["origin"], r["rule"])
        if k not in exp: continue
        e = exp[k]; tag = f"{k[0]} {k[1]}"
        def eq(name, ok, _r=r, _t=tag):
            if not ok: fail(f"FIELD {_t} {name}: file={_r.get(name, '?')}")
        eq("base_close", float(r["base_close"]) == e["P"]); eq("target_close", float(r["target_close"]) == e["PT"])
        eq("target_date", r["target_date"] == e["tdate"]); eq("vix_date", r["vix_date"] == e["vdate"])
        eq("y_actual", abs(float(r["y_actual"]) - e["y"]) <= K.TOL["x"]); eq("vrp", abs(float(r["vrp"]) - e["vrp"]) <= K.TOL["vrp_rel"] * max(1, abs(e["vrp"])))
        eq("n_train", r["n_train"].isdigit() and int(r["n_train"]) == e["m"])
        eq("first_train_origin", r["first_train_origin"] == str(oi[e["f"]].date())); eq("last_train_origin", r["last_train_origin"] == str(oi[e["l"]].date()))
        eq("last_train_label_end", r["last_train_label_end"] == str(o["target_date"].iloc[e["l"]].date()))
        eq("last_train_label_end<=origin", r["last_train_label_end"] != "" and r["last_train_label_end"] <= r["origin"])
        ty, tc = (K.TOL["yhat_huber"], K.TOL["coef_rel_huber"]) if e["kind"] == "huber" else (K.TOL["yhat_ols"], K.TOL["coef_rel_ols"])
        if e["a"] is None: eq("coef_intercept", r["coef_intercept"] == "")
        else: eq("coef_intercept", r["coef_intercept"] != "" and abs(float(r["coef_intercept"]) - e["a"]) <= tc * max(1, abs(e["a"])))
        if e["c"] is None: eq("coef_vrp", r["coef_vrp"] == "")
        else: eq("coef_vrp", r["coef_vrp"] != "" and abs(float(r["coef_vrp"]) - e["c"]) <= tc * max(1e-3, abs(e["c"])))
        if "lo" in e:
            eq("clip_lo", abs(float(r["clip_lo"]) - e["lo"]) <= K.TOL["clip"] * max(1, abs(e["lo"])))
            eq("clip_hi", abs(float(r["clip_hi"]) - e["hi"]) <= K.TOL["clip"] * max(1, abs(e["hi"])))
            eq("clipped", r["clipped"] == str(e["cl"])); eq("repro_abs_diff_unclipped", float(r["repro_abs_diff_unclipped"]) <= K.TOL["repro"] and e["repro"] <= K.TOL["repro"])
        if "vin" in e: eq("vrp_input_used", abs(float(r["vrp_input_used"]) - e["vin"]) <= K.TOL["vrp_rel"] * max(1, abs(e["vin"])))
        if "hs" in e: eq("huber_status", r["huber_status"] == e["hs"])
        eq("yhat", abs(float(r["yhat"]) - e["yhat"]) <= ty)
        F = e["P"] * math.exp(e["yhat"]); A = e["PT"]
        eq("forecast_full", abs(float(r["forecast_full"]) - F) <= max(K.TOL["forecast_full"], e["P"] * ty * 1.01))
        F2 = r2(F)
        if abs(float(r["forecast_2dp"]) - F2) > 1e-9:
            if abs((F * 100) % 1 - 0.5) <= max(1e-4, e["P"] * 100 * ty): boundary.append(tag)
            else: eq("forecast_2dp", False)
        else:
            eq("ape_2dp", abs(float(r["ape_2dp"]) - 100 * abs(F2 - A) / A) <= K.TOL["ape"])
        eq("abs_err_logret_bp", abs(float(r["abs_err_logret_bp"]) - 1e4 * abs(e["yhat"] - e["y"])) <= max(K.TOL["abs_err_bp"], 1e4 * ty * 1.01))
    if not any(f.startswith("KEYS") for f in fails):
        comp = pd.read_csv(RES / "analysis" / "comparisons.csv"); comp = comp[comp["id"].isin([c[0] for c in K.COMPARISONS])]
        fz = fr.set_index(["origin", "rule"]); ex = raw.set_index(["origin", "rule"])
        org = sorted(raw["origin"].unique())
        def loss(rule, col):
            src = ex if rule in K.EXT_RULES else fz
            return np.array([float(src.loc[(oo, rule), col]) for oo in org])
        for _, c in comp.iterrows():
            col = "ape_2dp" if c["metric"] == "APE_pp" else "abs_err_logret_bp"
            d = loss(c["A"], col) - loss(c["B"], col); nn = len(d); u = d - d.mean()
            se = math.sqrt((u @ u / nn + 2 * 0.5 * (u[1:] @ u[:-1] / nn)) / nn * nn / (nn - 1))
            if abs(se - float(c["hac_se"])) > K.TOL["hac_rel"] * max(se, 1e-300): fail(f"HAC {c['id']} {c['A']}-{c['B']} {c['metric']}")
    rep = {"freeze_id": fid, "rows_in_file": len(keys), "unique_keys": int(len(cnt)), "expected_keys": K.EXPECTED_KEYS,
           "n_failures": len(fails), "failures": fails[:500], "rounding_boundary_cases": boundary, "passed": not fails}
    (RES / "independent_check_report.json").write_text(json.dumps(rep, indent=1))
    print(json.dumps({k: rep[k] for k in ("rows_in_file", "unique_keys", "n_failures", "passed")}))
    if fails: print("first failures:", fails[:5], file=sys.stderr)
    raise SystemExit(0 if not fails else 1)


if __name__ == "__main__":
    main()
