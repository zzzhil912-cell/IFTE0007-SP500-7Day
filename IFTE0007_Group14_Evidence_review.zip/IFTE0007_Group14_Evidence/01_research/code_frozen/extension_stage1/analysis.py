"""Stage-1 extension analysis (round 11; protocol expansion_protocol_stage1_v1, X1-X7).  *** Requires freeze approval. ***

Guard: freeze_guard.verify; main-run manifest must carry the same freeze_id; ext_per_origin.csv must match the manifest hash
and contain exactly 944 x 4 unique (origin, rule) keys; the first-round frozen results copy must match its SHA-256.
Reference rules F2, B1-7, B0 are read from the FROZEN first-round results (not recomputed).
Conventions (fixed before results): d = loss_A - loss_B, negative = A better; APE_pp on the 2-dp forecast (primary), MAE_bp
(auxiliary); HAC: OLS on a constant, maxlags=1, use_correction=True, z90=1.6448536269514722, z95=1.959963984540054;
moving-block bootstrap: block 4, non-circular, starts uniform on 0..n-4, ceil(n/4) blocks truncated to n, B=2000,
numpy.random.default_rng(20261111), same positions for every comparison, percentile intervals 5/95 and 2.5/97.5,
bootstrap SE = std(ddof=1); phases 1/2 = alternate origins, any SE descriptive. All results exploratory.
Extra (pre-registered): E1 clip counts by window; Huber status counts and a converged-only DESCRIPTIVE line for X3/X4
(flagged origins stay in the main comparison); coefficient stability for F2-Huber and F2-R156; adjustments in bp.
Outputs: ../results/analysis/*.csv + analysis_manifest.json
"""
import csv, hashlib, json, math, sys
from datetime import date
from pathlib import Path
import numpy as np
import statsmodels.api as sm
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG

RES = C.STAGE / "results"; OUT = RES / "analysis"
WINDOWS = [("GFC 2008-09..2009-03", date(2008, 9, 1), date(2009, 3, 31)), ("COVID 2020-02..2020-04", date(2020, 2, 1), date(2020, 4, 30)),
           ("2022", date(2022, 1, 1), date(2022, 12, 31))]


def load(freeze_id):
    mp, p = RES / "main_run_manifest.json", RES / "ext_per_origin.csv"
    if not mp.exists() or not p.exists(): FG.refuse("main-run results or manifest missing")
    man = json.loads(mp.read_text())
    if man.get("freeze_id") != freeze_id: FG.refuse("results were produced under a different freeze (freeze_id mismatch)")
    if DB.sha256(p) != man["output_sha256"][p.name]: FG.refuse("ext_per_origin.csv does not match its manifest")
    if DB.sha256(C.FIRST_ROUND_RESULTS) != C.FIRST_ROUND_RESULTS_SHA256: FG.refuse("first-round frozen results hash mismatch")
    ext = list(csv.DictReader(open(p)))
    keys = [(r["origin"], r["rule"]) for r in ext]
    if len(keys) != C.EXPECTED_RESULT_KEYS or len(set(keys)) != len(keys):
        FG.refuse(f"result rows {len(keys)}, unique {len(set(keys))}, expected {C.EXPECTED_RESULT_KEYS}")
    fr = {(r["origin"], r["rule"]): r for r in csv.DictReader(open(C.FIRST_ROUND_RESULTS))}
    origins = sorted({r["origin"] for r in ext})
    if origins != sorted({o for o, rule in fr if rule == "F2"}): FG.refuse("origin set differs from first-round frozen results")
    by = {k: r for k, r in zip(keys, ext)}
    for o in origins:
        for rule in C.FROZEN_REF_RULES: by[(o, rule)] = fr[(o, rule)]
    return [date.fromisoformat(o) for o in origins], by


def hac(d):
    res = sm.OLS(d, np.ones((len(d), 1))).fit(cov_type="HAC", cov_kwds={"maxlags": C.HAC_MAXLAGS, "use_correction": True})
    return float(res.params[0]), float(res.bse[0])


def positions(n):
    rng = np.random.default_rng(C.BOOT_SEED); nb = math.ceil(n / C.BOOT_BLOCK)
    st = rng.integers(0, n - C.BOOT_BLOCK + 1, size=(C.BOOT_B, nb))
    return (st[:, :, None] + np.arange(C.BOOT_BLOCK)).reshape(C.BOOT_B, -1)[:, :n]


def summ(d, pos):
    m, se = hac(d); bm = d[pos].mean(axis=1)
    return {"n": len(d), "mean": float(d.mean()), "median": float(np.median(d)), "share_A_better": float((d < 0).mean()),
            "hac_se": se, "hac_90_lo": m - C.Z90 * se, "hac_90_hi": m + C.Z90 * se, "hac_95_lo": m - C.Z95 * se, "hac_95_hi": m + C.Z95 * se,
            "boot_se": float(bm.std(ddof=1)), "boot_90_lo": float(np.percentile(bm, 5)), "boot_90_hi": float(np.percentile(bm, 95)),
            "boot_95_lo": float(np.percentile(bm, 2.5)), "boot_95_hi": float(np.percentile(bm, 97.5))}


def write(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader()
        for r in rows: w.writerow({k: (repr(v) if isinstance(v, float) else v) for k, v in r.items()})


def main():
    rec, freeze_id = FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)
    origins, by = load(freeze_id); OUT.mkdir(parents=True, exist_ok=True)
    n = len(origins); pos = positions(n); S = [str(o) for o in origins]
    (OUT / "bootstrap_positions_sha256.txt").write_text(hashlib.sha256(pos.astype(np.int64).tobytes()).hexdigest() + "\n")
    rules = C.EXT_RULES + C.FROZEN_REF_RULES
    L = {m: {r: np.array([float(by[(o, r)][c]) for o in S]) for r in rules} for m, c in (("APE_pp", "ape_2dp"), ("MAE_bp", "abs_err_logret_bp"))}
    hs = np.array([by[(o, "F2-Huber")]["huber_status"] for o in S]); conv = hs == "converged"
    comp, ph, win = [], [], []
    for cid, A, B in C.EXT_COMPARISONS:
        for m in L:
            d = L[m][A] - L[m][B]
            comp.append({"id": cid, "A": A, "B": B, "metric": m, "direction": "d = A - B; negative = A better", **summ(d, pos)})
            for p, ix in ((1, np.arange(0, n, 2)), (2, np.arange(1, n, 2))):
                s = d[ix]; ph.append({"id": cid, "A": A, "B": B, "metric": m, "phase": p, "first_origin": S[ix[0]], "n": len(s),
                                      "mean": float(s.mean()), "median": float(np.median(s)), "share_A_better": float((s < 0).mean()),
                                      "descriptive_se": float(s.std(ddof=1) / math.sqrt(len(s))), "label": "descriptive"})
            covered = np.zeros(n, bool)
            for name, lo, hi in C.SUBPERIODS + WINDOWS:
                ix = np.array([lo <= o <= hi for o in origins])
                if name in [w[0] for w in WINDOWS]: covered |= ix
                win.append({"id": cid, "A": A, "B": B, "metric": m, "window": name, "n": int(ix.sum()), "mean_d": float(d[ix].mean()),
                            "contribution_to_full_mean": float(d[ix].sum() / n)})
            win.append({"id": cid, "A": A, "B": B, "metric": m, "window": "all other dates (outside the 3 stress windows)", "n": int((~covered).sum()),
                        "mean_d": float(d[~covered].mean()), "contribution_to_full_mean": float(d[~covered].sum() / n)})
            if A == "F2-Huber":
                comp.append({"id": cid + "-converged-only (descriptive)", "A": A, "B": B, "metric": m, "direction": "descriptive; flagged origins excluded",
                             "n": int(conv.sum()), "mean": float(d[conv].mean()) if conv.any() else float("nan"),
                             "median": float(np.median(d[conv])) if conv.any() else float("nan"),
                             "share_A_better": float((d[conv] < 0).mean()) if conv.any() else float("nan")})
    write(OUT / "comparisons.csv", comp); write(OUT / "phases.csv", ph); write(OUT / "windows_and_subperiods.csv", win)
    lev = [{"rule": r, "n": n, "mean_ape_pp": float(L["APE_pp"][r].mean()), "median_ape_pp": float(np.median(L["APE_pp"][r])),
            "max_ape_pp": float(L["APE_pp"][r].max()), "mean_course_score": float(np.mean([round(50 - min(50, 5 * e), 2) for e in L["APE_pp"][r]])),
            "mean_mae_bp": float(L["MAE_bp"][r].mean())} for r in rules]
    write(OUT / "levels.csv", lev)
    # E1 clipping, Huber status
    cl = np.array([int(by[(o, "F2-clip")]["clipped"]) for o in S])
    e1 = [{"window": "full", "n": n, "n_clipped": int(cl.sum())}] + [
        {"window": name, "n": int(sum(lo <= o <= hi for o in origins)), "n_clipped": int(sum(c for o, c in zip(origins, cl) if lo <= o <= hi))}
        for name, lo, hi in WINDOWS + C.SUBPERIODS]
    write(OUT / "e1_clip_counts.csv", e1)
    st = {}
    for s in hs: st[s] = st.get(s, 0) + 1
    write(OUT / "e2_huber_status.csv", [{"status": k, "n": v} for k, v in sorted(st.items())])
    # extremes, adjustments, coefficients
    ext, adj, cof = [], [], []
    yB = np.array([float(by[(o, "B1-7")]["yhat"]) for o in S]); yB156 = np.array([float(by[(o, "B1-7-R156")]["yhat"]) for o in S])
    ya = np.array([float(by[(o, "B1-7")]["y_actual"]) for o in S])
    for r in C.EXT_RULES:
        for k in np.argsort(-L["APE_pp"][r])[:10]:
            ext.append({"rule": r, "origin": S[k], "ape_pp": float(L["APE_pp"][r][k]), "ape_F2": float(L["APE_pp"]["F2"][k]), "ape_B1-7": float(L["APE_pp"]["B1-7"][k])})
        yr = np.array([float(by[(o, r)]["yhat"]) for o in S])
        for base, yb in (("B1-7", yB), ("B1-7-R156", yB156)):
            a = 1e4 * (yr - yb); s_ = 1e4 * (ya - yb)
            adj.append({"rule": r, "relative_to": base, "mean_bp": float(a.mean()), "sd_bp": float(a.std(ddof=1)), "median_abs_bp": float(np.median(np.abs(a))),
                        "max_abs_bp": float(np.abs(a).max()), "share_same_sign_as_y_minus_base": float(np.mean(np.sign(a) == np.sign(s_)))})
        cv = [by[(o, r)]["coef_vrp"] for o in S]
        if r in ("F2-Huber", "F2-R156"):
            v = np.array([float(x) for x in cv if x != ""])
            cof.append({"rule": r, "n": len(v), "first": float(v[0]), "last": float(v[-1]), "min": float(v.min()), "max": float(v.max()),
                        "share_positive": float((v > 0).mean()), "sign_flips": int(np.sum(np.sign(v[1:]) != np.sign(v[:-1])))})
    write(OUT / "extremes_top10.csv", ext); write(OUT / "adjustments.csv", adj); write(OUT / "coefficient_stability.csv", cof)
    man = {"freeze_id": freeze_id, "results_sha256": DB.sha256(RES / "ext_per_origin.csv"), "first_round_results_sha256": C.FIRST_ROUND_RESULTS_SHA256,
           "outputs_sha256": {f.name: DB.sha256(f) for f in sorted(OUT.iterdir()) if f.is_file() and f.name != "analysis_manifest.json"}}
    (OUT / "analysis_manifest.json").write_text(json.dumps(man, indent=1))
    print("analysis done")


if __name__ == "__main__":
    main()
