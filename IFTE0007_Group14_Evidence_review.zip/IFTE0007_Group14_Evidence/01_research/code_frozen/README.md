# Frozen research code (read-only copies)

Byte-identical copies of the code frozen for the three historical back-tests (hashes in each run's
`../results/*/FREEZE_RECORD.json`):
- `first_round/` — first 7-day back-test (freeze D27, 2026-11-05T20:59:40Z): B0, B1-7, F1-5, F1-21, F2, F1-5+F2, F1-21+F2.
- `extension_stage1/` — VRP extension stage 1 (freeze D32): F2-clip, F2-Huber, B1-7-R156, F2-R156, E2d influence diagnostics.
- `huber_intercept/` — Huber-Intercept benchmark (freeze D34).

They are included so the method can be read and audited. Rerunning them is **not** part of the v1 reproduction route:
they need the restricted Yahoo and Cboe snapshots and the archive's folder layout (their `config.py` and freeze guard
refer to archive paths such as `../04_round4_protocol_v3_1/protocol/` and `../inputs/`). The reproducible route for this
package is `../../02_reproduce/`. Requirements for these scripts additionally include statsmodels 0.14.0 (HAC) and
scipy (see `../../SOFTWARE_VERSIONS.md`).
