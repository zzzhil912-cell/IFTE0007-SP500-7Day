"""Huber-Intercept benchmark main run (round 13).  *** FITS A MODEL — requires Zhi's freeze approval. ***

Rule Huber-Intercept: at each of the 944 evaluation origins, Huber regression of the matured training 7-day log
returns on a constant only (expanding window, same training set as F2-Huber / B1-7): statsmodels RLM, HuberT(t=1.345),
scale_est='mad' (centre 0), conv='coefs', tol=1e-8, maxiter=50, scale threshold 1e-10.
Status (fixed before results): converged | not_converged (last iteration used, flagged) | scale_zero (estimate at stop used,
flagged) | error (FALLBACK to the origin's frozen first-round B1-7 yhat, flagged, counted as an actual fallback).
Flagged origins stay in the scoring. Reference rules (B1-7, F2-Huber) are read from frozen files, never recomputed.
Guard: freeze_guard.verify. Output: ../results/hi_per_origin.csv (944 rows) + main_run_manifest.json.
Exit: 0 ok, 2 refused, 3 integrity stop.
"""
import csv, json, math, sys, warnings
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG


def stop(msg): print(f"STOP: {msg}", file=sys.stderr); raise SystemExit(3)
def round2(x): return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def huber_intercept(y):
    """Returns (mu, status, n_iter, n_downweighted). mu is None when status == 'error'."""
    import statsmodels.api as sm
    from statsmodels.tools.sm_exceptions import ConvergenceWarning
    try:
        X = np.ones((len(y), 1))
        with warnings.catch_warnings(record=True) as wl:
            warnings.simplefilter("always")
            res = sm.RLM(np.asarray(y, float), X, M=sm.robust.norms.HuberT(t=C.HUBER_T)).fit(
                maxiter=C.HUBER_MAXITER, tol=C.HUBER_TOL, scale_est="mad", conv=C.HUBER_CONV)
        mu = float(np.asarray(res.params)[0]); hist = res.fit_history["params"]; it = int(res.fit_history["iteration"])
        if not np.isfinite(mu): return None, "error", it, -1
        s0 = any(issubclass(w.category, ConvergenceWarning) and "scale is 0.0" in str(w.message) for w in wl)
        if s0 or float(res.scale) < C.HUBER_SCALE_EPS: st = "scale_zero"
        else:
            step = np.max(np.abs(np.asarray(hist[-1]) - np.asarray(hist[-2]))) if len(hist) >= 3 else np.inf
            st = "converged" if step <= C.HUBER_TOL else "not_converged"
        return mu, st, it, int(np.sum(np.asarray(res.weights) < 1.0))
    except Exception:
        return None, "error", 0, -1


def predict(y_train, fallback_yhat):
    """Pre-registered prediction with failure handling. Returns (yhat, status, n_iter, n_dw, used_fallback)."""
    mu, st, it, ndw = huber_intercept(y_train)
    if st == "error": return float(fallback_yhat), st, it, ndw, 1
    return mu, st, it, ndw, 0


def main():
    rec, freeze_id = FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for p, h in ((C.FIRST_ROUND_RESULTS, C.FIRST_ROUND_RESULTS_SHA256), (C.EXT_RESULTS, C.EXT_RESULTS_SHA256)):
        if DB.sha256(p) != h: stop(f"{p.name} does not match its frozen SHA-256")
    d = DB.load()
    if not all(ok for _, ok, _ in DB.validate_index(d)): stop("trading-day index validation failed")
    rows, _ = DB.build(d); ev = DB.evaluation_positions(rows)
    if len(ev) != 944 or str(rows[ev[0]]["origin"]) != "2008-09-24": stop("evaluation origins differ")
    b1 = {r["origin"]: r for r in csv.DictReader(open(C.FIRST_ROUND_RESULTS)) if r["rule"] == "B1-7"}
    out = C.STAGE / "results"; out.mkdir(exist_ok=True); path = out / "hi_per_origin.csv"
    fields = ["origin", "rule", "base_close", "target_date", "target_close", "y_actual", "n_train", "first_train_origin",
              "last_train_origin", "last_train_label_end", "huber_status", "huber_iterations", "huber_n_downweighted", "used_fallback",
              "coef_intercept", "yhat", "forecast_full", "forecast_2dp", "ape_2dp", "ape_full", "abs_err_logret_bp"]
    counts, nfb, n = {}, 0, 0
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader()
        for k in ev:
            r = rows[k]; tp = DB.training_positions(rows, k); o = str(r["origin"])
            if max(rows[j]["target_date"] for j in tp) > r["origin"]: stop("training label after origin")
            if int(b1[o]["n_train"]) != len(tp): stop(f"training size differs from frozen B1-7 at {o}")
            yhat, st, it, ndw, fb = predict([rows[j]["y"] for j in tp], float(b1[o]["yhat"]))
            counts[st] = counts.get(st, 0) + 1; nfb += fb
            F = r["base_close"] * math.exp(yhat); F2 = round2(F); A = r["target_close"]
            w.writerow({"origin": o, "rule": C.HI_RULE, "base_close": f"{r['base_close']:.2f}", "target_date": r["target_date"],
                        "target_close": f"{A:.2f}", "y_actual": repr(r["y"]), "n_train": len(tp), "first_train_origin": rows[tp[0]]["origin"],
                        "last_train_origin": rows[tp[-1]]["origin"], "last_train_label_end": max(rows[j]["target_date"] for j in tp),
                        "huber_status": st, "huber_iterations": it, "huber_n_downweighted": ndw, "used_fallback": fb,
                        "coef_intercept": "" if fb else repr(yhat), "yhat": repr(yhat), "forecast_full": repr(F), "forecast_2dp": f"{F2:.2f}",
                        "ape_2dp": repr(100 * abs(F2 - A) / A), "ape_full": repr(100 * abs(F - A) / A), "abs_err_logret_bp": repr(1e4 * abs(yhat - r["y"]))})
            n += 1
    if n != C.EXPECTED_RESULT_KEYS: stop(f"{n} rows")
    man = {"freeze_id": freeze_id, "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "n_rows": n, "huber_status_counts": counts, "actual_fallbacks": nfb, "python": sys.version, "numpy": np.__version__,
           "output_sha256": {path.name: DB.sha256(path)}}
    (out / "main_run_manifest.json").write_text(json.dumps(man, indent=1, default=str))
    print("done", json.dumps({"rows": n, "status": counts, "fallbacks": nfb}))


if __name__ == "__main__":
    main()
