"""Constants restated for the round-13 independent check (does not import config.py)."""
RAW_Y = "inputs/yahoo_GSPC_1988_to_now.json"
RAW_V = "inputs/cboe_VIX_round1copy_20261105T185724Z.csv"
FIRST = "inputs/first_round_frozen/per_origin_forecasts.csv"
FIRST_SHA256 = "da5b06744f5865c8fe4f9aa4e7b1968542acf63346706f2db369c3ea88c84bdb"
EXT = "inputs/ext_frozen/ext_per_origin.csv"
EXT_SHA256 = "ea7db900eb99808764109939f29906fda73a5c5a5a212e1be575f688434dc496"
HIST_END, PARTIAL = "2026-11-04", "2026-11-05"
LAUNCH, FIRST_WED = "2003-09-22", "2003-09-24"
H, MINTR = 7, 260
EXPECTED_KEYS = 944
RULE = "Huber-Intercept"
COMPARISONS = [("H1", "Huber-Intercept", "B1-7"), ("H2", "F2-Huber", "Huber-Intercept")]
HUBER_T, HUBER_MAXITER, HUBER_TOL = 1.345, 50, 1e-8
HUBER_SCALE_EPS = 1e-10
APPROVER = "Zhi"
REQUIRED = [RAW_Y, RAW_V, FIRST, "inputs/first_round_frozen/FREEZE_RECORD.json", EXT, "inputs/ext_frozen/FREEZE_RECORD.json",
            "code/config.py", "code/data_build.py", "code/freeze_guard.py", "code/precheck.py", "code/main_run.py",
            "code/analysis.py", "code/independent_check.py", "code/independent_constants.py",
            "spec/hi_output_fields_and_rules.md", "spec/environment.txt", "protocol/huber_intercept_addendum_v1.md"]
TOL = {"y": 1e-12, "yhat": 1e-9, "forecast_full": 1e-6, "ape": 1e-9, "abs_err_bp": 1e-5, "hac_rel": 1e-10}
