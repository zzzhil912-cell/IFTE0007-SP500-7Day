"""Huber-Intercept addendum analysis (round 13; H1, H2).  *** Requires freeze approval. ***
Guard + results tied to this freeze (freeze_id, manifest hash, exactly 944 unique keys); reference rules read from the
frozen first-round (B1-7) and extension (F2-Huber) files after hash checks.
Conventions as in the frozen analyses: d = A - B (negative = A better); APE_pp on the 2-dp forecast (primary), MAE_bp;
HAC maxlags 1 + use_correction, z90/z95; moving-block bootstrap block 4, B 2000, seed 20261111, percentile; phases
descriptive; windows = pre-defined subperiods + stress windows + all other dates (contribution = n_w/N * mean_w).
Median APE per rule is reported to describe typical origins; the primary metric remains mean APE. All exploratory.
"""
import csv, hashlib, json, math, sys
from datetime import date
from pathlib import Path
import numpy as np
import statsmodels.api as sm
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG

RES = C.STAGE / "results"; OUT = RES / "analysis"
WINDOWS = [("GFC 2008-09..2009-03", date(2008, 9, 1), date(2009, 3, 31)), ("COVID 2020-02..2020-04", date(2020, 2, 1), date(2020, 4, 30)),
           ("2022", date(2022, 1, 1), date(2022, 12, 31))]


def load(fid):
    mp, p = RES / "main_run_manifest.json", RES / "hi_per_origin.csv"
    if not mp.exists() or not p.exists(): FG.refuse("main-run results or manifest missing")
    man = json.loads(mp.read_text())
    if man.get("freeze_id") != fid: FG.refuse("results were produced under a different freeze (freeze_id mismatch)")
    if DB.sha256(p) != man["output_sha256"][p.name]: FG.refuse("hi_per_origin.csv does not match its manifest")
    for f, h in ((C.FIRST_ROUND_RESULTS, C.FIRST_ROUND_RESULTS_SHA256), (C.EXT_RESULTS, C.EXT_RESULTS_SHA256)):
        if DB.sha256(f) != h: FG.refuse(f"{f.name} hash mismatch")
    hi = list(csv.DictReader(open(p))); keys = [(r["origin"], r["rule"]) for r in hi]
    if len(keys) != C.EXPECTED_RESULT_KEYS or len(set(keys)) != len(keys): FG.refuse(f"result rows {len(keys)}, unique {len(set(keys))}")
    by = {k: r for k, r in zip(keys, hi)}
    for r in csv.DictReader(open(C.FIRST_ROUND_RESULTS)):
        if r["rule"] == "B1-7": by[(r["origin"], "B1-7")] = r
    for r in csv.DictReader(open(C.EXT_RESULTS)):
        if r["rule"] == "F2-Huber": by[(r["origin"], "F2-Huber")] = r
    origins = sorted(r["origin"] for r in hi)
    if any((o, x) not in by for o in origins for x in ("B1-7", "F2-Huber")): FG.refuse("reference rows missing for some origins")
    return origins, by, man


def hac(d):
    r = sm.OLS(d, np.ones((len(d), 1))).fit(cov_type="HAC", cov_kwds={"maxlags": C.HAC_MAXLAGS, "use_correction": True})
    return float(r.params[0]), float(r.bse[0])


def positions(n):
    rng = np.random.default_rng(C.BOOT_SEED); nb = math.ceil(n / C.BOOT_BLOCK)
    st = rng.integers(0, n - C.BOOT_BLOCK + 1, size=(C.BOOT_B, nb))
    return (st[:, :, None] + np.arange(C.BOOT_BLOCK)).reshape(C.BOOT_B, -1)[:, :n]


def write(path, rows):
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: (repr(v) if isinstance(v, float) else v) for k, v in r.items()})


def main():
    rec, fid = FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)
    S, by, man = load(fid); OUT.mkdir(parents=True, exist_ok=True)
    od = [date.fromisoformat(o) for o in S]; n = len(S); pos = positions(n)
    (OUT / "bootstrap_positions_sha256.txt").write_text(hashlib.sha256(pos.astype(np.int64).tobytes()).hexdigest() + "\n")
    rules = [C.HI_RULE, "B1-7", "F2-Huber"]
    L = {m: {r: np.array([float(by[(o, r)][c]) for o in S]) for r in rules} for m, c in (("APE_pp", "ape_2dp"), ("MAE_bp", "abs_err_logret_bp"))}
    conv = np.array([by[(o, C.HI_RULE)]["huber_status"] == "converged" for o in S])
    comp, ph, win = [], [], []
    for cid, A, B in C.HI_COMPARISONS:
        for m in L:
            d = L[m][A] - L[m][B]; mu, se = hac(d); bm = d[pos].mean(axis=1)
            comp.append({"id": cid, "A": A, "B": B, "metric": m, "direction": "d = A - B; negative = A better", "n": n,
                         "mean": float(d.mean()), "median": float(np.median(d)), "share_A_better": float((d < 0).mean()),
                         "hac_se": se, "hac_90_lo": mu - C.Z90 * se, "hac_90_hi": mu + C.Z90 * se, "hac_95_lo": mu - C.Z95 * se, "hac_95_hi": mu + C.Z95 * se,
                         "boot_se": float(bm.std(ddof=1)), "boot_90_lo": float(np.percentile(bm, 5)), "boot_90_hi": float(np.percentile(bm, 95)),
                         "boot_95_lo": float(np.percentile(bm, 2.5)), "boot_95_hi": float(np.percentile(bm, 97.5))})
            comp.append({"id": cid + "-converged-only (descriptive)", "A": A, "B": B, "metric": m, "direction": "descriptive; flagged Huber-Intercept origins excluded",
                         "n": int(conv.sum()), "mean": float(d[conv].mean()) if conv.any() else float("nan"),
                         "median": float(np.median(d[conv])) if conv.any() else float("nan"), "share_A_better": float((d[conv] < 0).mean()) if conv.any() else float("nan")})
            for p, ix in ((1, np.arange(0, n, 2)), (2, np.arange(1, n, 2))):
                s = d[ix]; ph.append({"id": cid, "A": A, "B": B, "metric": m, "phase": p, "first_origin": S[ix[0]], "n": len(s), "mean": float(s.mean()),
                                      "median": float(np.median(s)), "share_A_better": float((s < 0).mean()),
                                      "descriptive_se": float(s.std(ddof=1) / math.sqrt(len(s))), "label": "descriptive"})
            cov = np.zeros(n, bool)
            for name, lo, hi in C.SUBPERIODS + WINDOWS:
                ix = np.array([lo <= o <= hi for o in od])
                if name in [x[0] for x in WINDOWS]: cov |= ix
                win.append({"id": cid, "A": A, "B": B, "metric": m, "window": name, "n": int(ix.sum()), "mean_d": float(d[ix].mean()), "contribution_to_full_mean": float(d[ix].sum() / n)})
            win.append({"id": cid, "A": A, "B": B, "metric": m, "window": "all other dates (outside the 3 stress windows)", "n": int((~cov).sum()),
                        "mean_d": float(d[~cov].mean()), "contribution_to_full_mean": float(d[~cov].sum() / n)})
    write(OUT / "comparisons.csv", comp); write(OUT / "phases.csv", ph); write(OUT / "windows_and_subperiods.csv", win)
    write(OUT / "levels.csv", [{"rule": r, "n": n, "mean_ape_pp": float(L["APE_pp"][r].mean()), "median_ape_pp": float(np.median(L["APE_pp"][r])),
                                "max_ape_pp": float(L["APE_pp"][r].max()), "mean_mae_bp": float(L["MAE_bp"][r].mean()),
                                "median_mae_bp": float(np.median(L["MAE_bp"][r]))} for r in rules])
    st = {}
    for o in S: s = by[(o, C.HI_RULE)]["huber_status"]; st[s] = st.get(s, 0) + 1
    write(OUT / "huber_intercept_status.csv", [{"status": k, "n": v} for k, v in sorted(st.items())] +
          [{"status": "actual_fallbacks_to_B1-7", "n": int(sum(int(by[(o, C.HI_RULE)]["used_fallback"]) for o in S))}])
    yh = {r: np.array([float(by[(o, r)]["yhat"]) for o in S]) for r in rules}; ya = np.array([float(by[(o, "B1-7")]["y_actual"]) for o in S])
    adj = []
    for a, b in ((C.HI_RULE, "B1-7"), ("F2-Huber", C.HI_RULE)):
        x = 1e4 * (yh[a] - yh[b]); s_ = 1e4 * (ya - yh[b])
        adj.append({"rule": a, "relative_to": b, "mean_bp": float(x.mean()), "sd_bp": float(x.std(ddof=1)), "median_abs_bp": float(np.median(np.abs(x))),
                    "max_abs_bp": float(np.abs(x).max()), "share_same_sign_as_y_minus_base": float(np.mean(np.sign(x) == np.sign(s_)))})
    write(OUT / "adjustments.csv", adj)
    am = {"freeze_id": fid, "results_sha256": DB.sha256(RES / "hi_per_origin.csv"),
          "reference_sha256": {"first_round": C.FIRST_ROUND_RESULTS_SHA256, "ext": C.EXT_RESULTS_SHA256},
          "outputs_sha256": {f.name: DB.sha256(f) for f in sorted(OUT.iterdir()) if f.is_file() and f.name != "analysis_manifest.json"}}
    (OUT / "analysis_manifest.json").write_text(json.dumps(am, indent=1)); print("analysis done")


if __name__ == "__main__":
    main()
