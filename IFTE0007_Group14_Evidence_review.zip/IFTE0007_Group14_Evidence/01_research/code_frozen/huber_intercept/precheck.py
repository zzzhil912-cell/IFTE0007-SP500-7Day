"""Huber-Intercept addendum precheck (round 13). NO model fitting on project data.
Run: python -I precheck.py -> ../precheck/precheck_output.txt, precheck_results.json ; exit 1 on any failure."""
import csv, json, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB

OUT = C.STAGE / "precheck"; OUT.mkdir(exist_ok=True); res, lines = [], []
def say(s): print(s); lines.append(s)
def check(n, ok, det=""): res.append({"check": n, "passed": bool(ok), "detail": det}); say(f"[{'PASS' if ok else 'FAIL'}] {n}" + (f" | {det}" if det else ""))
say(f"Huber-Intercept precheck at {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
say("\n== 1. frozen material")
for p, h in ((C.FIRST_ROUND_RESULTS, C.FIRST_ROUND_RESULTS_SHA256), (C.FIRST_ROUND_FREEZE_RECORD, C.FIRST_ROUND_FREEZE_RECORD_SHA256),
             (C.EXT_RESULTS, C.EXT_RESULTS_SHA256), (C.EXT_FREEZE_RECORD, C.EXT_FREEZE_RECORD_SHA256)):
    check(f"copy {p.parent.name}/{p.name} SHA-256 == frozen", DB.sha256(p) == h, h[:16])
root = C.STAGE.parent
for stage, lst, n_exp in (("06_round6_code_revision", "SHA256_to_freeze.txt", 17), ("11_round11_ext_code_prep", "SHA256_to_freeze_ext_18.txt", 18)):
    if (root / stage).exists():
        bad, n = [], 0
        for l in (root / stage / lst).read_text().splitlines():
            if l.startswith("#") or not l.strip(): continue
            h, rel = l.split("  ", 1); n += 1
            if DB.sha256(root / stage / rel) != h: bad.append(rel)
        check(f"{stage}: all {n_exp} frozen files unchanged", n == n_exp and not bad, str(bad))
    else:
        say(f"  ({stage} not present: synthetic stage; skipped)")
if (root / "06_round6_code_revision").exists():
    check("first-round results in 06 unchanged", DB.sha256(root / "06_round6_code_revision/results/per_origin_forecasts.csv") == C.FIRST_ROUND_RESULTS_SHA256)
    check("extension results in 11 unchanged", DB.sha256(root / "11_round11_ext_code_prep/results/ext_per_origin.csv") == C.EXT_RESULTS_SHA256)
    check("data_build.py and freeze_guard.py identical to frozen modules",
          all(DB.sha256(C.STAGE / "code" / f) == DB.sha256(root / "06_round6_code_revision/code" / f) for f in ("data_build.py", "freeze_guard.py")))
say("\n== 2. origins and training sets (no fitting)")
d = DB.load()
for name, ok, det in DB.validate_index(d): check(name, ok, det)
rows, _ = DB.build(d); ev = DB.evaluation_positions(rows); S = [str(rows[k]["origin"]) for k in ev]
check("944 evaluation origins 2008-09-24 .. 2026-10-21", len(S) == 944 and S[0] == "2008-09-24" and S[-1] == "2026-10-21")
b1 = {r["origin"]: r for r in csv.DictReader(open(C.FIRST_ROUND_RESULTS)) if r["rule"] == "B1-7"}
fh = {r["origin"]: r for r in csv.DictReader(open(C.EXT_RESULTS)) if r["rule"] == "F2-Huber"}
check("frozen B1-7 and F2-Huber rows exist for all 944 origins", set(S) == set(b1) == set(fh))
check("training size per origin == frozen B1-7 n_train == frozen F2-Huber n_train (common matured sample)",
      all(len(DB.training_positions(rows, k)) == int(b1[s]["n_train"]) == int(fh[s]["n_train"]) for k, s in zip(ev, S)))
check("training labels end on or before origin (expanding)", all(rows[DB.training_positions(rows, k)[-1]]["target_date"] <= rows[k]["origin"] for k in ev))
check("frozen F2-Huber status is recorded at every origin", all(fh[s]["huber_status"] in ("converged", "not_converged", "scale_zero", "error") for s in S),
      str({x: sum(1 for s in S if fh[s]['huber_status'] == x) for x in set(fh[s]['huber_status'] for s in S)}))
say("\n== 3. rule and comparisons")
check("Huber settings identical to F2-Huber (t, maxiter, tol, conv, scale threshold)",
      (C.HUBER_T, C.HUBER_MAXITER, C.HUBER_TOL, C.HUBER_CONV, C.HUBER_SCALE_EPS) == (1.345, 50, 1e-8, "coefs", 1e-10))
check("2 comparisons == protocol H1, H2", C.HI_COMPARISONS == [("H1", "Huber-Intercept", "B1-7"), ("H2", "F2-Huber", "Huber-Intercept")])
check("expected new result keys == 944", C.EXPECTED_RESULT_KEYS == 944)
say("\n== 4. freeze prerequisites")
miss = [r for r in C.REQUIRED_FREEZE_FILES if not (C.STAGE / r).exists()]
check("every required freeze file exists", not miss, f"{len(C.REQUIRED_FREEZE_FILES)} files; missing {miss}")
check("no FREEZE_RECORD.json in this stage", not C.FREEZE_RECORD.exists())
for s in ("main_run.py", "analysis.py", "independent_check.py"):
    pr = subprocess.run([sys.executable, "-I", str(Path(__file__).resolve().parent / s)], capture_output=True, text=True)
    check(f"{s} refuses without a freeze record (exit 2)", pr.returncode == 2 and "no FREEZE_RECORD" in pr.stderr, f"exit {pr.returncode}")
check("no results directory created", not (C.STAGE / "results").exists())
nf = sum(1 for r in res if not r["passed"]); say(f"\nSUMMARY: {len(res)} checks, {nf} failed")
(OUT / "precheck_output.txt").write_text("\n".join(lines) + "\n"); (OUT / "precheck_results.json").write_text(json.dumps(res, indent=1)); sys.exit(1 if nf else 0)
