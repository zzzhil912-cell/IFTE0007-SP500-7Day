"""Independent recomputation for the Huber-Intercept addendum (round 13).  *** Requires freeze approval. ***
Does not import config.py, data_build.py, freeze_guard.py, main_run.py or analysis.py. Rebuilds data and the schedule with
pandas, estimates the Huber location with an OWN IRLS (weights min(1, t/|z|), MAD scale centre 0 / 0.6744897501960817,
convergence on max |change| <= tol, maxiter 50, scale threshold 1e-10; error -> fallback to the frozen B1-7 yhat),
checks exactly 944 unique keys equal to the rebuilt set, every committed field, status and fallback flags, and the
hand HAC for H1/H2. Exit 2 refused, 1 mismatch (report saved), 0 pass.
"""
import hashlib, json, math, sys
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import independent_constants as K

STAGE = Path(__file__).resolve().parent.parent; RES = STAGE / "results"; MADC = 0.6744897501960817
def _sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _refuse(m): print(f"REFUSED: {m}", file=sys.stderr); raise SystemExit(2)


def own_freeze_check():
    fr = STAGE / "FREEZE_RECORD.json"
    if not fr.exists(): _refuse("no FREEZE_RECORD.json")
    try: rec = json.loads(fr.read_text())
    except Exception as e: _refuse(f"unreadable freeze record: {e}")
    if rec.get("approved_by") != K.APPROVER: _refuse(f"approver {rec.get('approved_by')!r} != {K.APPROVER!r}")
    try:
        if datetime.fromisoformat(str(rec.get("approved_utc", "")).replace("Z", "+00:00")).tzinfo is None: raise ValueError
    except Exception: _refuse("approved_utc missing or invalid")
    files = rec.get("sha256")
    if not isinstance(files, dict) or not files: _refuse("empty sha256 list")
    miss = [p for p in K.REQUIRED if p not in files]
    if miss: _refuse(f"required files missing from record: {miss}")
    for rel, h in files.items():
        if not (STAGE / rel).exists() or _sha(STAGE / rel) != h: _refuse(f"hash mismatch or missing file: {rel}")
    canon = json.dumps({"approved_by": rec["approved_by"], "approved_utc": rec["approved_utc"], "sha256": dict(sorted(files.items()))}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode()).hexdigest()


def tie(fid):
    for p in (RES / "main_run_manifest.json", RES / "hi_per_origin.csv", RES / "analysis/analysis_manifest.json", RES / "analysis/comparisons.csv"):
        if not p.exists(): _refuse(f"missing {p.relative_to(STAGE)}")
    mm = json.loads((RES / "main_run_manifest.json").read_text()); am = json.loads((RES / "analysis/analysis_manifest.json").read_text())
    if mm.get("freeze_id") != fid or am.get("freeze_id") != fid: _refuse("results not produced under this freeze")
    h = _sha(RES / "hi_per_origin.csv")
    if h != mm["output_sha256"]["hi_per_origin.csv"] or am.get("results_sha256") != h: _refuse("results hash != manifests")
    if _sha(RES / "analysis/comparisons.csv") != am["outputs_sha256"]["comparisons.csv"]: _refuse("comparisons.csv hash != analysis manifest")
    if _sha(STAGE / K.FIRST) != K.FIRST_SHA256 or _sha(STAGE / K.EXT) != K.EXT_SHA256: _refuse("frozen reference hash mismatch")


def rebuild():
    j = json.loads((STAGE / K.RAW_Y).read_text())["chart"]["result"][0]
    s = pd.Series(j["indicators"]["quote"][0]["close"], index=pd.to_datetime(j["timestamp"], unit="s", utc=True).tz_convert("America/New_York").normalize().tz_localize(None))
    s = s[(s.index != pd.Timestamp(K.PARTIAL)) & (s.index <= pd.Timestamp(K.HIST_END))].astype(float).round(2)
    v = pd.read_csv(STAGE / K.RAW_V); v = pd.Series(v["CLOSE"].astype(float).to_numpy(), index=pd.to_datetime(v["DATE"], format="%m/%d/%Y"))
    df = pd.DataFrame({"P": s}); df["vix"] = v.reindex(df.index); r = np.log(df["P"]).diff()
    df["x21"] = np.log(df["P"] / df["P"].shift(21)); df["vix_date"] = pd.Series(df.index, index=df.index).shift(1)
    df["vrp"] = df["vix"].shift(1) ** 2 / 12 - 1e4 * (r ** 2).rolling(21).sum().shift(1)
    df["target_date"] = pd.Series(df.index, index=df.index).shift(-K.H); df["PT"] = df["P"].shift(-K.H)
    df["y"] = np.log(df["PT"] / df["P"]); df["pos"] = np.arange(len(df))
    o = df.loc[pd.Index(df.index[df.index.searchsorted(pd.date_range(pd.Timestamp(K.FIRST_WED), pd.Timestamp(K.HIST_END), freq="7D"), side="right") - 1]).unique()]
    return o[(o["vix_date"] >= pd.Timestamp(K.LAUNCH)) & o[["x21", "vrp", "y"]].notna().all(axis=1)].copy()


def irls_location(y):
    try:
        y = np.asarray(y, float); mu = float(np.mean(y)); res = y - mu; scale = np.median(np.abs(res)) / MADC
        prev, it = np.inf, 1; hist = [np.inf, mu]
        while True:
            if scale == 0.0: break
            z = np.abs(res / scale); w = np.where(z <= K.HUBER_T, 1.0, K.HUBER_T / np.where(z == 0, 1, z))
            mu = float(np.sum(w * y) / np.sum(w)); res = y - mu; scale = np.median(np.abs(res)) / MADC
            hist.append(mu); it += 1
            if not (abs(hist[-1] - hist[-2]) > K.HUBER_TOL and it < K.HUBER_MAXITER): break
        if not np.isfinite(mu): return None, "error"
        if scale < K.HUBER_SCALE_EPS: return mu, "scale_zero"
        return mu, ("converged" if len(hist) >= 3 and abs(hist[-1] - hist[-2]) <= K.HUBER_TOL else "not_converged")
    except Exception:
        return None, "error"


def r2(x): return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def main():
    fid = own_freeze_check(); tie(fid)
    o = rebuild(); pos = o["pos"].to_numpy(); y = o["y"].to_numpy()
    mat = np.searchsorted(pos + K.H, pos, side="right"); first = int(np.argmax(mat >= K.MINTR))
    fr = pd.read_csv(STAGE / K.FIRST, dtype=str, keep_default_na=False); b1 = fr[fr.rule == "B1-7"].set_index("origin")
    exp = {}
    for t in range(first, len(o)):
        m = mat[t]; ot = str(o.index[t].date()); mu, st = irls_location(y[:m]); fb = int(st == "error")
        yh = float(b1.loc[ot, "yhat"]) if fb else mu
        exp[(ot, K.RULE)] = dict(P=o["P"].iloc[t], PT=o["PT"].iloc[t], y=y[t], tdate=str(o["target_date"].iloc[t].date()), m=m,
                                 f=str(o.index[0].date()), l=str(o.index[m - 1].date()), le=str(o["target_date"].iloc[m - 1].date()), st=st, fb=fb, yhat=yh)
    raw = pd.read_csv(RES / "hi_per_origin.csv", dtype=str, keep_default_na=False)
    fails, boundary = [], []; fail = fails.append
    keys = list(zip(raw["origin"], raw["rule"])); cnt = pd.Series(keys).value_counts()
    if len(keys) != K.EXPECTED_KEYS: fail(f"KEYS: {len(keys)} rows, expected {K.EXPECTED_KEYS}")
    if len(exp) != K.EXPECTED_KEYS: fail(f"KEYS: rebuild has {len(exp)} keys")
    dup = sorted(k for k, c in cnt.items() if c > 1)
    if dup: fail(f"KEYS: duplicated (origin, rule): {dup[:10]}")
    miss, extra = sorted(set(exp) - set(keys)), sorted(set(keys) - set(exp))
    if miss: fail(f"KEYS: missing {len(miss)}: {miss[:10]}")
    if extra: fail(f"KEYS: unexpected {len(extra)}: {extra[:10]}")
    for _, r in raw.drop_duplicates(["origin", "rule"]).iterrows():
        k = (r["origin"], r["rule"])
        if k not in exp: continue
        e = exp[k]; tag = f"{k[0]} {k[1]}"
        def eq(name, ok, _r=r, _t=tag):
            if not ok: fail(f"FIELD {_t} {name}: file={_r.get(name, '?')}")
        eq("base_close", float(r["base_close"]) == e["P"]); eq("target_close", float(r["target_close"]) == e["PT"]); eq("target_date", r["target_date"] == e["tdate"])
        eq("y_actual", abs(float(r["y_actual"]) - e["y"]) <= K.TOL["y"]); eq("n_train", r["n_train"].isdigit() and int(r["n_train"]) == e["m"])
        eq("first_train_origin", r["first_train_origin"] == e["f"]); eq("last_train_origin", r["last_train_origin"] == e["l"])
        eq("last_train_label_end", r["last_train_label_end"] == e["le"] and e["le"] <= r["origin"])
        eq("huber_status", r["huber_status"] == e["st"]); eq("used_fallback", r["used_fallback"] == str(e["fb"]))
        eq("coef_intercept", (r["coef_intercept"] == "") if e["fb"] else (r["coef_intercept"] != "" and abs(float(r["coef_intercept"]) - e["yhat"]) <= K.TOL["yhat"]))
        eq("yhat", abs(float(r["yhat"]) - e["yhat"]) <= K.TOL["yhat"])
        F = e["P"] * math.exp(e["yhat"]); A = e["PT"]
        eq("forecast_full", abs(float(r["forecast_full"]) - F) <= max(K.TOL["forecast_full"], e["P"] * K.TOL["yhat"] * 1.01))
        F2 = r2(F)
        if abs(float(r["forecast_2dp"]) - F2) > 1e-9:
            if abs((F * 100) % 1 - 0.5) <= max(1e-4, e["P"] * 100 * K.TOL["yhat"]): boundary.append(tag)
            else: eq("forecast_2dp", False)
        else: eq("ape_2dp", abs(float(r["ape_2dp"]) - 100 * abs(F2 - A) / A) <= K.TOL["ape"])
        eq("abs_err_logret_bp", abs(float(r["abs_err_logret_bp"]) - 1e4 * abs(e["yhat"] - e["y"])) <= K.TOL["abs_err_bp"])
    if not any(f.startswith("KEYS") for f in fails):
        comp = pd.read_csv(RES / "analysis/comparisons.csv"); comp = comp[comp["id"].isin([c[0] for c in K.COMPARISONS])]
        ex = pd.read_csv(STAGE / K.EXT, dtype=str, keep_default_na=False); fh = ex[ex.rule == "F2-Huber"].set_index("origin")
        hi = raw.set_index("origin"); org = sorted(raw["origin"])
        src = {K.RULE: hi, "B1-7": b1, "F2-Huber": fh}
        for _, c in comp.iterrows():
            col = "ape_2dp" if c["metric"] == "APE_pp" else "abs_err_logret_bp"
            d = np.array([float(src[c["A"]].loc[x, col]) - float(src[c["B"]].loc[x, col]) for x in org]); nn = len(d); u = d - d.mean()
            se = math.sqrt((u @ u / nn + 2 * 0.5 * (u[1:] @ u[:-1] / nn)) / nn * nn / (nn - 1))
            if abs(se - float(c["hac_se"])) > K.TOL["hac_rel"] * max(se, 1e-300): fail(f"HAC {c['id']} {c['metric']}")
    rep = {"freeze_id": fid, "rows_in_file": len(keys), "unique_keys": int(len(cnt)), "expected_keys": K.EXPECTED_KEYS, "n_failures": len(fails),
           "failures": fails[:500], "rounding_boundary_cases": boundary, "passed": not fails}
    (RES / "independent_check_report.json").write_text(json.dumps(rep, indent=1))
    print(json.dumps({k: rep[k] for k in ("rows_in_file", "unique_keys", "n_failures", "passed")}))
    if fails: print("first failures:", fails[:5], file=sys.stderr)
    raise SystemExit(0 if not fails else 1)


if __name__ == "__main__":
    main()
