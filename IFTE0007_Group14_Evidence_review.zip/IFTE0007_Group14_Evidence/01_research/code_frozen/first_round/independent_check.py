"""Independent recomputation for the first-round backtest (protocol v3.1).  *** Requires freeze approval. ***
Round 6 revision (after Zhi's review).

Does NOT import config.py, data_build.py, freeze_guard.py, main_run.py or analysis.py. Own constants in
independent_constants.py. Different computation path from the main implementation:
  pandas parsing / tz index / searchsorted schedule; pandas shift/rolling features;
  expanding OLS via cumulative X'X, X'y + numpy.linalg.solve (main: lstsq per origin); HAC by hand.

Order:
  1. own freeze check (record exists; approver + approval time; required list complete; all hashes match)   -> exit 2
  2. main manifest freeze_id == this freeze; results hash == manifest; analysis manifest freeze_id and
     comparisons.csv hash match                                                                                -> exit 2
  3. key check: results have exactly EXPECTED_KEYS rows, all (origin, rule) keys unique, and the key set equals
     the independently rebuilt set
  4. field check for every row (all fields promised in spec/output_fields.md)
  5. hand HAC vs analysis comparisons.csv
Any failure in 3-5: report saved to results/independent_check_report.json and exit 1. Pass: exit 0.
"""
import hashlib, json, math, sys
from collections import Counter
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import independent_constants as K

STAGE = Path(__file__).resolve().parent.parent
RES = STAGE / "results"


def _sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def _refuse(msg):
    print(f"REFUSED: {msg}", file=sys.stderr); raise SystemExit(2)


def own_freeze_check():
    fr = STAGE / "FREEZE_RECORD.json"
    if not fr.exists(): _refuse("no FREEZE_RECORD.json")
    try: rec = json.loads(fr.read_text())
    except Exception as e: _refuse(f"unreadable freeze record: {e}")
    if rec.get("approved_by") != K.APPROVER: _refuse(f"approver {rec.get('approved_by')!r} != {K.APPROVER!r}")
    try:
        if datetime.fromisoformat(str(rec.get("approved_utc", "")).replace("Z", "+00:00")).tzinfo is None: raise ValueError
    except Exception: _refuse("approved_utc missing or invalid")
    files = rec.get("sha256")
    if not isinstance(files, dict) or not files: _refuse("empty sha256 list")
    miss = [p for p in K.REQUIRED if p not in files]
    if miss: _refuse(f"required files missing from record: {miss}")
    for rel, h in files.items():
        p = STAGE / rel
        if not p.exists() or _sha(p) != h: _refuse(f"hash mismatch or missing file: {rel}")
    canon = json.dumps({"approved_by": rec["approved_by"], "approved_utc": rec["approved_utc"],
                        "sha256": dict(sorted(files.items()))}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode()).hexdigest()


def tie_results(fid):
    for p in (RES / "main_run_manifest.json", RES / "per_origin_forecasts.csv",
              RES / "analysis" / "analysis_manifest.json", RES / "analysis" / "comparisons.csv"):
        if not p.exists(): _refuse(f"missing {p.relative_to(STAGE)}")
    mm = json.loads((RES / "main_run_manifest.json").read_text())
    am = json.loads((RES / "analysis" / "analysis_manifest.json").read_text())
    if mm.get("freeze_id") != fid or am.get("freeze_id") != fid: _refuse("results not produced under this freeze")
    if _sha(RES / "per_origin_forecasts.csv") != mm["output_sha256"]["per_origin_forecasts.csv"]: _refuse("results hash != main manifest")
    if am.get("results_sha256") != mm["output_sha256"]["per_origin_forecasts.csv"]: _refuse("analysis used different results")
    if _sha(RES / "analysis" / "comparisons.csv") != am["outputs_sha256"]["comparisons.csv"]: _refuse("comparisons.csv hash != analysis manifest")


def rebuild():
    j = json.loads((STAGE / K.RAW_Y).read_text())["chart"]["result"][0]
    s = pd.Series(j["indicators"]["quote"][0]["close"],
                  index=pd.to_datetime(j["timestamp"], unit="s", utc=True).tz_convert("America/New_York").normalize().tz_localize(None))
    s = s[(s.index != pd.Timestamp(K.PARTIAL)) & (s.index <= pd.Timestamp(K.HIST_END))].astype(float).round(2)
    v = pd.read_csv(STAGE / K.RAW_V)
    v = pd.Series(v["CLOSE"].astype(float).to_numpy(), index=pd.to_datetime(v["DATE"], format="%m/%d/%Y"))
    df = pd.DataFrame({"P": s}); df["vix"] = v.reindex(df.index)
    r = np.log(df["P"]).diff()
    df["x5"] = np.log(df["P"] / df["P"].shift(5)); df["x21"] = np.log(df["P"] / df["P"].shift(21))
    df["vix_date"] = pd.Series(df.index, index=df.index).shift(1)
    df["vrp"] = df["vix"].shift(1) ** 2 / 12 - 1e4 * (r ** 2).rolling(21).sum().shift(1)
    df["target_date"] = pd.Series(df.index, index=df.index).shift(-K.H); df["PT"] = df["P"].shift(-K.H)
    df["y"] = np.log(df["PT"] / df["P"]); df["pos"] = np.arange(len(df))
    weds = pd.date_range(pd.Timestamp(K.FIRST_WED), pd.Timestamp(K.HIST_END), freq="7D")
    org = pd.Index(df.index[df.index.searchsorted(weds, side="right") - 1]).unique()
    o = df.loc[org]
    return o[(o["vix_date"] >= pd.Timestamp(K.LAUNCH)) & o[["x5", "x21", "vrp", "y"]].notna().all(axis=1)].copy()


def recompute(o):
    pos = o["pos"].to_numpy(); n = len(o); y = o["y"].to_numpy()
    mat = np.searchsorted(pos + K.H, pos, side="right")       # matured labels: pos_s + H <= pos_t
    first = int(np.argmax(mat >= K.MINTR)); fits = {}
    for rule, cols in K.SPEC.items():
        X = np.column_stack([np.ones(n)] + [o[c].to_numpy() for c in cols])
        XtX = np.cumsum(X[:, :, None] * X[:, None, :], axis=0); Xty = np.cumsum(X * y[:, None], axis=0)
        for t in range(first, n):
            m = mat[t]; beta = np.linalg.solve(XtX[m - 1], Xty[m - 1])
            fits[(o.index[t], rule)] = (float(X[t] @ beta), beta, m)
    return o.iloc[first:], o, fits


def r2(x):
    return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def main():
    fid = own_freeze_check(); tie_results(fid)
    ev, o_all, fits = recompute(rebuild())
    raw = pd.read_csv(RES / "per_origin_forecasts.csv", dtype=str, keep_default_na=False)
    fails, boundary = [], []
    fail = fails.append
    # --- 3. keys ---
    keys = list(zip(raw["origin"], raw["rule"])); cnt = Counter(keys)
    exp_keys = {(str(t.date()), rule) for t in ev.index for rule in K.RULES}
    if len(keys) != K.EXPECTED_KEYS: fail(f"KEYS: {len(keys)} rows, expected {K.EXPECTED_KEYS}")
    if len(exp_keys) != K.EXPECTED_KEYS: fail(f"KEYS: independent rebuild has {len(exp_keys)} keys, expected {K.EXPECTED_KEYS}")
    dup = sorted(k for k, c in cnt.items() if c > 1)
    if dup: fail(f"KEYS: duplicated (origin, rule): {dup[:10]}")
    missing = sorted(exp_keys - set(keys)); extra = sorted(set(keys) - exp_keys)
    if missing: fail(f"KEYS: missing {len(missing)}: {missing[:10]}")
    if extra: fail(f"KEYS: unexpected {len(extra)}: {extra[:10]}")
    # --- 4. fields ---
    for _, r in raw.drop_duplicates(["origin", "rule"]).iterrows():
        if (r["origin"], r["rule"]) not in exp_keys: continue
        t = pd.Timestamp(r["origin"]); rule = r["rule"]; e = ev.loc[t]; tag = f"{r['origin']} {rule}"
        def eq(name, ok, _r=r, _tag=tag):
            if not ok: fail(f"FIELD {_tag} {name}: file={_r.get(name, '?')}")
        eq("base_date", r["base_date"] == r["origin"])
        eq("base_close", float(r["base_close"]) == e["P"]); eq("target_close", float(r["target_close"]) == e["PT"])
        eq("target_date", r["target_date"] == str(e["target_date"].date())); eq("vix_date", r["vix_date"] == str(e["vix_date"].date()))
        eq("y_actual", abs(float(r["y_actual"]) - e["y"]) <= K.TOL["y"])
        eq("x5", abs(float(r["x5"]) - e["x5"]) <= K.TOL["x"]); eq("x21", abs(float(r["x21"]) - e["x21"]) <= K.TOL["x"])
        eq("vrp", abs(float(r["vrp"]) - e["vrp"]) <= K.TOL["vrp_rel"] * max(1.0, abs(e["vrp"])))
        if rule == "B0":
            yhat = 0.0
            for f in ("first_train_origin", "last_train_origin", "last_train_label_end", "coef_intercept", "coef_x5", "coef_x21", "coef_vrp"):
                eq(f, r[f] == "")
            eq("n_train", r["n_train"] == "0")
        else:
            yhat, beta, m = fits[(t, rule)]
            eq("n_train", r["n_train"].isdigit() and int(r["n_train"]) == m)
            eq("first_train_origin", r["first_train_origin"] == str(o_all.index[0].date()))
            eq("last_train_origin", r["last_train_origin"] == str(o_all.index[m - 1].date()))
            eq("last_train_label_end", r["last_train_label_end"] == str(o_all["target_date"].iloc[:m].max().date()))
            eq("last_train_label_end<=origin", r["last_train_label_end"] != "" and pd.Timestamp(r["last_train_label_end"]) <= t)
            eq("coef_intercept", r["coef_intercept"] != "" and abs(float(r["coef_intercept"]) - beta[0]) <= K.TOL["coef_rel"] * max(1, abs(beta[0])))
            for c in ("x5", "x21", "vrp"):
                if c in K.SPEC[rule]:
                    b = beta[1 + K.SPEC[rule].index(c)]
                    eq(f"coef_{c}", r[f"coef_{c}"] != "" and abs(float(r[f"coef_{c}"]) - b) <= K.TOL["coef_rel"] * max(1, abs(b)))
                else:
                    eq(f"coef_{c}", r[f"coef_{c}"] == "")
        eq("yhat", abs(float(r["yhat"]) - yhat) <= K.TOL["yhat"])
        F = e["P"] * math.exp(yhat); A = e["PT"]
        eq("forecast_full", abs(float(r["forecast_full"]) - F) <= K.TOL["forecast_full"])
        eq("ape_full", abs(float(r["ape_full"]) - 100 * abs(F - A) / A) <= K.TOL["ape"])
        F2 = r2(F)
        if abs(float(r["forecast_2dp"]) - F2) > 1e-9:
            if abs((F * 100) % 1 - 0.5) <= 1e-4: boundary.append(tag)
            else: eq("forecast_2dp", False)
        else:
            eq("ape_2dp", abs(float(r["ape_2dp"]) - 100 * abs(F2 - A) / A) <= K.TOL["ape"])
        eq("abs_err_logret_bp", abs(float(r["abs_err_logret_bp"]) - 1e4 * abs(yhat - e["y"])) <= K.TOL["abs_err_bp"])
    # --- 5. hand HAC (only when the key set is intact) ---
    if not any(f.startswith("KEYS") for f in fails):
        comp = pd.read_csv(RES / "analysis" / "comparisons.csv")
        nd = raw.copy()
        for c in ("ape_2dp", "abs_err_logret_bp"): nd[c] = nd[c].astype(float)
        piv = {m: nd.pivot(index="origin", columns="rule", values=col).sort_index()
               for m, col in (("APE_pp", "ape_2dp"), ("MAE_bp", "abs_err_logret_bp"))}
        for _, c in comp[comp["group"] == "pre-registered"].iterrows():
            d = (piv[c["metric"]][c["A"]] - piv[c["metric"]][c["B"]]).to_numpy(); n = len(d); u = d - d.mean()
            se = math.sqrt((u @ u / n + 2 * 0.5 * (u[1:] @ u[:-1] / n)) / n * n / (n - 1))
            if abs(se - float(c["hac_se"])) > K.TOL["hac_rel"] * max(se, 1e-300): fail(f"HAC {c['id']} {c['A']}-{c['B']} {c['metric']}")
    rep = {"freeze_id": fid, "rows_in_file": len(keys), "unique_keys": len(cnt), "expected_keys": K.EXPECTED_KEYS,
           "n_failures": len(fails), "failures": fails[:500], "rounding_boundary_cases": boundary, "passed": not fails}
    (RES / "independent_check_report.json").write_text(json.dumps(rep, indent=1))
    print(json.dumps({k: rep[k] for k in ("rows_in_file", "unique_keys", "n_failures", "passed")}))
    if fails: print("first failures:", fails[:5], file=sys.stderr)
    raise SystemExit(0 if not fails else 1)


if __name__ == "__main__":
    main()
