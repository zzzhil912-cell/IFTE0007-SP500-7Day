"""Pre-run checks for the first-round backtest (protocol v3.1). NO fitting: no regression, no forecast, no error.

Run (from anywhere):  python -I precheck.py
Writes ../precheck/precheck_output.txt and ../precheck/precheck_results.json. Exit code 1 if any check fails.
"""
import csv, json, sys
from collections import Counter
from datetime import date, datetime, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB

OUT = C.STAGE / "precheck"; OUT.mkdir(exist_ok=True)
results, lines = [], []
def say(s): print(s); lines.append(s)
def check(name, ok, detail=""):
    results.append({"check": name, "passed": bool(ok), "detail": detail})
    say(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" | {detail}" if detail else ""))

say(f"precheck run at {datetime.now(timezone.utc).isoformat(timespec='seconds')}")
d = DB.load()
for l in d.log: say("  " + l)

# 1. trading-day index first
say("\n== 1. trading-day index (validated before any target is computed)")
for name, ok, det in DB.validate_index(d): check(name, ok, det)
check("Yahoo closes rounded to 2 dp; max |raw - rounded| < 0.0051", d.rounding_max_abs < C.MAX_YAHOO_ROUNDING, f"max={d.rounding_max_abs:.3e}")
check("intraday 2026-11-05 row dropped", d.dropped_partial[0] == C.PARTIAL_ROW_DATE and C.PARTIAL_ROW_DATE not in d.idx, str(d.dropped_partial))
say(f"  S&P closes used: {len(d.dates)} ({d.dates[0]} .. {d.dates[-1]}); VIX rows kept on S&P days: {len(d.vix)}; VIX rows on non-S&P days dropped: {d.vix_dropped_non_spx}")
if not all(r["passed"] for r in results):
    say("STOP: index validation failed; targets not computed"); (OUT / "precheck_output.txt").write_text("\n".join(lines)); sys.exit(1)

# 2. eligible origins and targets
say("\n== 2. origins, targets, features (no fitting)")
rows, dropped = DB.build(d)
check("eligible origins == 1205", len(rows) == C.EXPECTED["n_eligible"], f"n={len(rows)}, first {rows[0]['origin']}, last {rows[-1]['origin']}")
check("no origin dropped for missing inputs after VIX launch", all(w == "target after HIST_END" for _, w in dropped), str([(str(t), w) for t, w in dropped]))
check("every target is exactly 7 index steps after its origin",
      all(d.idx[r["target_date"]] - r["i"] == C.H for r in rows))
spans = Counter((r["target_date"] - r["origin"]).days for r in rows)
say(f"  info: calendar-day span of 7-trading-day labels {dict(sorted(spans.items()))} (missing rows are tested by the holiday check in section 1)")
check("VIX date used == previous S&P trading day and >= 2003-09-22",
      all(r["vix_date"] == d.dates[r["i"] - 1] and r["vix_date"] >= C.VIX_LAUNCH for r in rows),
      f"earliest VIX date used {min(r['vix_date'] for r in rows)}")
check("RV window = 21 returns ending t-1", all(d.idx[r["rv_last_return_date"]] == r["i"] - 1 and
      d.idx[r["rv_first_return_date"]] == r["i"] - C.RV_N for r in rows))

# 3. training sets and evaluation origins
say("\n== 3. training sets (positions only, no estimation)")
ev = DB.evaluation_positions(rows)
first = rows[ev[0]]
n_first = len(DB.training_positions(rows, ev[0]))
check("evaluation origins == 944", len(ev) == C.EXPECTED["n_eval"], f"{rows[ev[0]]['origin']} .. {rows[ev[-1]]['origin']}")
check("first evaluation origin 2008-09-24 with exactly 260 matured labels",
      first["origin"] == C.EXPECTED["first_eval"] and n_first == C.EXPECTED["first_eval_matured"], f"{first['origin']}, {n_first}")
check("origin before first evaluation has < 260 matured labels", len(DB.training_positions(rows, ev[0] - 1)) < C.MIN_TRAIN)
check("last evaluation origin 2026-10-21, label ends 2026-10-30",
      rows[ev[-1]]["origin"] == C.EXPECTED["last_eval"] and rows[ev[-1]]["target_date"] == C.EXPECTED["last_label_end"])
bad_end, n_train, last_end = [], [], []
for k in ev:
    tp = DB.training_positions(rows, k)
    n_train.append(len(tp)); le = max(rows[j]["target_date"] for j in tp); last_end.append(le)
    if le > rows[k]["origin"]: bad_end.append(str(rows[k]["origin"]))
    if tp != list(range(len(tp))): bad_end.append(f"non-prefix training set at {rows[k]['origin']}")
check("every training label ends on or before its forecast origin (idx(s)+7 <= idx(t))", not bad_end, str(bad_end[:5]))
check("training sets are expanding (non-decreasing size)", all(a <= b for a, b in zip(n_train, n_train[1:])), f"{n_train[0]} .. {n_train[-1]}")
# common training set across rules: rebuild each rule's own eligibility from its required inputs
need = {"B1-7": ["base_close"], "F1-5": ["x5"], "F1-21": ["x21"], "F2": ["vrp"], "F1-5+F2": ["x5", "vrp"], "F1-21+F2": ["x21", "vrp"]}
per_rule = {}
for rule, cols in need.items():
    ok_rows = [k for k, r in enumerate(rows) if all(r.get(c) is not None for c in cols)]
    per_rule[rule] = tuple(ok_rows)
check("all six estimated rules share one training/evaluation row set", len(set(per_rule.values())) == 1,
      f"sizes {[len(v) for v in per_rule.values()]}")
check("rows used by every rule == common eligible set", all(len(v) == len(rows) for v in per_rule.values()))

# 4. overlap and phases
say("\n== 4. label overlap")
E = [rows[k] for k in ev]
gaps = [b["i"] - a["i"] for a, b in zip(E, E[1:])]
check("all adjacent evaluation labels overlap", all(g < C.H for g in gaps), f"gaps {dict(sorted(Counter(gaps).items()))}")
check("no overlap between origins two apart", all(c["i"] - a["i"] >= C.H for a, c in zip(E, E[2:])), f"min gap {min(c['i']-a['i'] for a, c in zip(E, E[2:]))}")
for ph in (0, 1):
    sub = E[ph::2]
    ov = [(str(a["origin"]), str(b["origin"])) for a, b in zip(sub, sub[1:]) if b["i"] - a["i"] < C.H]
    check(f"phase {ph+1}: n == 472 and no label overlap", len(sub) == C.EXPECTED["phase_n"][ph] and not ov,
          f"n={len(sub)}, starts {sub[0]['origin']}, min gap {min(b['i']-a['i'] for a, b in zip(sub, sub[1:]))}, overlaps {ov}")

# 5. cross-check with round-3 independent listing
ref = [r for r in csv.DictReader(open(C.INPUTS / "round3_v3_evaluation_origins_reference.csv"))]
same = [str(r["origin"]) for r in E] == [x["origin"] for x in ref] and \
       [str(r["target_date"]) for r in E] == [x["label_end"] for x in ref] and \
       [str(r["vix_date"]) for r in E] == [x["vix_rv_date_t_minus_1"] for x in ref] and \
       n_train == [int(x["matured_training_labels"]) for x in ref]
check("origins, target dates, VIX dates, training counts == round-3 script output", same)

# 6. formal-task calendar sanity (no data after HIST_END used)
check("no input dated after HIST_END", max(r["target_date"] for r in rows) <= C.HIST_END)

# save per-origin structure (no forecasts)
with open(OUT / "precheck_origin_table.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["origin", "target_date", "vix_date", "n_train", "last_train_label_end", "base_close", "target_close"])
    for r, n, le in zip(E, n_train, last_end):
        w.writerow([r["origin"], r["target_date"], r["vix_date"], n, le, f"{r['base_close']:.2f}", f"{r['target_close']:.2f}"])
# 7. round-6 additions: freeze prerequisites (no freeze is created here)
say("\n== 7. freeze prerequisites (round 6)")
check("raw Yahoo closes: none within 1e-6 of a half-cent boundary (load would have stopped)", True, "checked in data_build.load")
check("expected result keys == evaluation origins x rules == 6608", len(ev) * len(C.RULES) == C.EXPECTED_RESULT_KEYS == 6608)
miss_req = [rel for rel in C.REQUIRED_FREEZE_FILES if not (C.STAGE / rel).exists()]
check("every required freeze file exists", not miss_req, f"{len(C.REQUIRED_FREEZE_FILES)} files; missing {miss_req}")
check("no FREEZE_RECORD.json in the project stage (not frozen)", not C.FREEZE_RECORD.exists())
import subprocess
for s in ("main_run.py", "analysis.py", "independent_check.py"):
    pr = subprocess.run([sys.executable, "-I", str(Path(__file__).resolve().parent / s)], capture_output=True, text=True)
    check(f"{s} refuses without a freeze record (exit 2, no fitting)", pr.returncode == 2 and "no FREEZE_RECORD" in pr.stderr,
          f"exit {pr.returncode}: {pr.stderr.strip()[:80]}")
check("no results directory was created in the project stage", not (C.STAGE / "results").exists())

n_fail = sum(1 for r in results if not r["passed"])
say(f"\nSUMMARY: {len(results)} checks, {n_fail} failed")
(OUT / "precheck_output.txt").write_text("\n".join(lines) + "\n")
(OUT / "precheck_results.json").write_text(json.dumps(results, indent=1, ensure_ascii=False))
sys.exit(1 if n_fail else 0)
