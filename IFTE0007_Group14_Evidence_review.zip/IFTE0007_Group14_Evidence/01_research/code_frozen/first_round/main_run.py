"""Main run of the first-round 7-day backtest (protocol v3.1).  *** FITS MODELS — requires Zhi's freeze approval. ***

Guard (round 6): freeze_guard.verify — FREEZE_RECORD.json must exist, name the required approver with a valid
UTC approval time, list EVERY required file, and every hash must match. Refusal exits with code 2.
The manifest records the freeze_id so analysis / independent check can tie results to this freeze.

Run (after approval):  python -I main_run.py
Output: ../results/per_origin_forecasts.csv (long format, one row per origin x rule; fields in
        ../spec/output_fields.md), ../results/main_run_manifest.json
Computation precision: float64 throughout, no intermediate rounding. Display/scoring precision: the point
forecast is also rounded to 2 dp (ROUND_HALF_UP) because the course scores a 2-dp forecast; primary APE uses
the 2-dp forecast, full-precision APE is stored alongside (see ../spec/precision_and_rounding.md).
"""
import csv, json, math, sys
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG


def guard():
    """Round 6: full freeze check (required file list, approver, approval time, hashes). Exit 2 on refusal."""
    return FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)


def round2(x):
    return float(Decimal(repr(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def fit_predict(rule, rows, tp, r):
    """Return (yhat, coef dict). B0: no estimation. B1-7: mean. Others: OLS with intercept via lstsq."""
    if rule == "B0":
        return 0.0, {}
    y = np.array([rows[j]["y"] for j in tp], dtype=np.float64)
    if rule == "B1-7":
        a = float(y.mean()); return a, {"intercept": a}
    cols = C.RULE_REGRESSORS[rule]
    X = np.column_stack([np.ones(len(tp))] + [np.array([rows[j][c] for j in tp], dtype=np.float64) for c in cols])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    x0 = np.array([1.0] + [r[c] for c in cols])
    coef = {"intercept": float(beta[0])}
    for c, b in zip(cols, beta[1:]): coef[c] = float(b)
    return float(x0 @ beta), coef


def main():
    rec, freeze_id = guard()
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    d = DB.load()
    if not all(ok for _, ok, _ in DB.validate_index(d)):
        raise SystemExit("STOP: trading-day index validation failed")
    rows, _ = DB.build(d)
    ev = DB.evaluation_positions(rows)
    assert len(ev) == C.EXPECTED["n_eval"] and rows[ev[0]]["origin"] == C.EXPECTED["first_eval"]
    out_dir = C.STAGE / "results"; out_dir.mkdir(exist_ok=True)
    fields = ["origin", "rule", "base_date", "base_close", "target_date", "target_close", "y_actual",
              "vix_date", "x5", "x21", "vrp", "n_train", "first_train_origin", "last_train_origin", "last_train_label_end",
              "coef_intercept", "coef_x5", "coef_x21", "coef_vrp", "yhat", "forecast_full", "forecast_2dp",
              "ape_2dp", "ape_full", "abs_err_logret_bp"]
    path = out_dir / "per_origin_forecasts.csv"
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for k in ev:
            r = rows[k]; tp = DB.training_positions(rows, k)
            assert max(rows[j]["target_date"] for j in tp) <= r["origin"]
            for rule in C.RULES:
                yhat, coef = fit_predict(rule, rows, tp, r)
                F = r["base_close"] * math.exp(yhat); F2 = round2(F); A = r["target_close"]
                w.writerow({"origin": r["origin"], "rule": rule, "base_date": r["origin"], "base_close": f"{r['base_close']:.2f}",
                            "target_date": r["target_date"], "target_close": f"{A:.2f}", "y_actual": repr(r["y"]),
                            "vix_date": r["vix_date"], "x5": repr(r["x5"]), "x21": repr(r["x21"]), "vrp": repr(r["vrp"]),
                            "n_train": len(tp) if rule != "B0" else 0,
                            "first_train_origin": rows[tp[0]]["origin"] if rule != "B0" else "",
                            "last_train_origin": rows[tp[-1]]["origin"] if rule != "B0" else "",
                            "last_train_label_end": max(rows[j]["target_date"] for j in tp) if rule != "B0" else "",
                            "coef_intercept": repr(coef.get("intercept", "")) if coef else "",
                            "coef_x5": repr(coef["x5"]) if "x5" in coef else "", "coef_x21": repr(coef["x21"]) if "x21" in coef else "",
                            "coef_vrp": repr(coef["vrp"]) if "vrp" in coef else "",
                            "yhat": repr(yhat), "forecast_full": repr(F), "forecast_2dp": f"{F2:.2f}",
                            "ape_2dp": repr(100 * abs(F2 - A) / A), "ape_full": repr(100 * abs(F - A) / A),
                            "abs_err_logret_bp": repr(1e4 * abs(yhat - r["y"]))})
    n_keys = len(ev) * len(C.RULES)
    if n_keys != C.EXPECTED_RESULT_KEYS:
        raise SystemExit(f"STOP: {n_keys} result rows, expected {C.EXPECTED_RESULT_KEYS}")
    man = {"freeze_id": freeze_id, "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "freeze_record": rec, "python": sys.version, "numpy": np.__version__,
           "output_sha256": {path.name: DB.sha256(path)}, "n_rows": n_keys}
    (out_dir / "main_run_manifest.json").write_text(json.dumps(man, indent=1, default=str))
    print("done", man["output_sha256"])


if __name__ == "__main__":
    main()
