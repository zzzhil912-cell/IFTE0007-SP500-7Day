"""Pre-registered analysis of the first-round backtest (protocol v3.1 §7). *** Uses backtest results — requires freeze approval. ***

Guard (round 6): freeze_guard.verify (complete required list, approver, time, hashes); then the main-run
manifest must carry the SAME freeze_id and per_origin_forecasts.csv must match the manifest hash and contain
exactly EXPECTED_RESULT_KEYS unique (origin, rule) rows. Writes analysis_manifest.json with freeze_id and output hashes.

Run (after main_run.py):  python -I analysis.py
Conventions (fixed before any result exists):
  d_t = loss_A,t - loss_B,t for comparison (A, B); NEGATIVE = A better.
  Losses: APE in percentage points (primary; computed on the 2-dp forecast); log-return absolute error in bp (auxiliary).
  HAC: statsmodels OLS of d on a constant, cov_type="HAC", maxlags=1, use_correction=True (Bartlett).
       Intervals: mean +/- z * SE with z90 = 1.6448536269514722, z95 = 1.959963984540054 (standard normal).
  Bootstrap: moving blocks of 4 consecutive origins, non-circular, starts drawn uniformly from 0..n-4,
       ceil(n/4) blocks concatenated and truncated to n, B = 2000, numpy.random.default_rng(20261111);
       the same position matrix for every comparison; statistic = mean of d; percentile intervals
       (5/95 and 2.5/97.5, numpy.percentile default linear); bootstrap SE = std of the B means (ddof=1).
  Phases: phase 1 = evaluation origins 1,3,5,... ; phase 2 = 2,4,6,... ; mean/median/share; any SE is DESCRIPTIVE.
  D1 (F1-5 vs F1-21) is descriptive only.
Outputs in ../results/analysis/ (fields in ../spec/output_fields.md).
"""
import csv, hashlib, json, math, sys
from collections import defaultdict
from datetime import date
from pathlib import Path
import numpy as np
import statsmodels.api as sm
sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
import data_build as DB
import freeze_guard as FG

RES = C.STAGE / "results"; OUT = RES / "analysis"


def load_results(freeze_id):
    mp = RES / "main_run_manifest.json"; p = RES / "per_origin_forecasts.csv"
    if not mp.exists() or not p.exists():
        FG.refuse("main-run results or manifest missing")
    man = json.loads(mp.read_text())
    if man.get("freeze_id") != freeze_id:
        FG.refuse("results were produced under a different freeze (freeze_id mismatch)")
    if DB.sha256(p) != man["output_sha256"][p.name]:
        FG.refuse("per_origin_forecasts.csv does not match its manifest")
    rows = list(csv.DictReader(open(p)))
    keys = [(r["origin"], r["rule"]) for r in rows]
    if len(keys) != C.EXPECTED_RESULT_KEYS or len(set(keys)) != len(keys):
        FG.refuse(f"result rows {len(keys)}, unique {len(set(keys))}, expected {C.EXPECTED_RESULT_KEYS}")
    origins = sorted({date.fromisoformat(r["origin"]) for r in rows})
    by = {(date.fromisoformat(r["origin"]), r["rule"]): r for r in rows}
    return origins, by


def hac(d):
    res = sm.OLS(d, np.ones((len(d), 1))).fit(cov_type="HAC", cov_kwds={"maxlags": C.HAC_MAXLAGS, "use_correction": True})
    return float(res.params[0]), float(res.bse[0])


def boot_positions(n):
    rng = np.random.default_rng(C.BOOT_SEED)
    nb = math.ceil(n / C.BOOT_BLOCK)
    starts = rng.integers(0, n - C.BOOT_BLOCK + 1, size=(C.BOOT_B, nb))
    pos = (starts[:, :, None] + np.arange(C.BOOT_BLOCK)).reshape(C.BOOT_B, -1)[:, :n]
    return pos


def summarize(d, pos, inferential=True):
    out = {"n": len(d), "mean": float(d.mean()), "median": float(np.median(d)),
           "share_A_better": float((d < 0).mean()), "share_tie": float((d == 0).mean())}
    if inferential:
        m, se = hac(d)
        out.update(hac_se=se, hac_90_lo=m - C.Z90 * se, hac_90_hi=m + C.Z90 * se, hac_95_lo=m - C.Z95 * se, hac_95_hi=m + C.Z95 * se)
        bm = d[pos].mean(axis=1)
        out.update(boot_se=float(bm.std(ddof=1)), boot_90_lo=float(np.percentile(bm, 5)), boot_90_hi=float(np.percentile(bm, 95)),
                   boot_95_lo=float(np.percentile(bm, 2.5)), boot_95_hi=float(np.percentile(bm, 97.5)))
    return out


def main():
    rec, freeze_id = FG.verify(C.STAGE, C.REQUIRED_FREEZE_FILES, C.REQUIRED_APPROVER)
    origins, by = load_results(freeze_id); OUT.mkdir(parents=True, exist_ok=True)
    n = len(origins); pos = boot_positions(n)
    (OUT / "bootstrap_positions_sha256.txt").write_text(hashlib.sha256(pos.astype(np.int64).tobytes()).hexdigest() + "\n")
    loss = {m: {rule: np.array([float(by[(o, rule)][col]) for o in origins]) for rule in C.RULES}
            for m, col in (("APE_pp", "ape_2dp"), ("MAE_bp", "abs_err_logret_bp"))}
    ph = {1: np.arange(0, n, 2), 2: np.arange(1, n, 2)}
    comp_rows, phase_rows = [], []
    for group, comps, infer in (("pre-registered", C.COMPARISONS, True), ("descriptive", C.DESCRIPTIVE_COMPARISONS, False)):
        for cid, A, B in comps:
            for m in loss:
                dd = loss[m][A] - loss[m][B]
                s = summarize(dd, pos, inferential=infer)
                comp_rows.append({"group": group, "id": cid, "A": A, "B": B, "metric": m, "direction": "d = A - B; negative = A better", **s})
                for p, ix in ph.items():
                    sub = dd[ix]
                    phase_rows.append({"id": cid, "A": A, "B": B, "metric": m, "phase": p, "first_origin": origins[ix[0]], "n": len(sub),
                                       "mean": float(sub.mean()), "median": float(np.median(sub)), "share_A_better": float((sub < 0).mean()),
                                       "descriptive_se": float(sub.std(ddof=1) / math.sqrt(len(sub))), "label": "descriptive"})
    write(OUT / "comparisons.csv", comp_rows); write(OUT / "phases.csv", phase_rows)
    # levels
    lev = []
    for rule in C.RULES:
        a = loss["APE_pp"][rule]
        lev.append({"rule": rule, "n": n, "mean_ape_pp": float(a.mean()), "median_ape_pp": float(np.median(a)), "max_ape_pp": float(a.max()),
                    "mean_course_score": float(np.mean([round(50 - min(50, 5 * e), 2) for e in a])),
                    "mean_mae_bp": float(loss["MAE_bp"][rule].mean())})
    write(OUT / "levels.csv", lev)
    # subperiods, stress, yearly
    def window_rows(windows):
        out = []
        for name, lo, hi in windows:
            ix = np.array([k for k, o in enumerate(origins) if lo <= o <= hi])
            if len(ix) == 0: continue
            for rule in C.RULES:
                out.append({"window": name, "rule": rule, "n": len(ix), "mean_ape_pp": float(loss["APE_pp"][rule][ix].mean()),
                            "mean_mae_bp": float(loss["MAE_bp"][rule][ix].mean())})
            for cid, A, B in C.COMPARISONS + C.DESCRIPTIVE_COMPARISONS:
                dd = loss["APE_pp"][A][ix] - loss["APE_pp"][B][ix]
                out.append({"window": name, "rule": f"d[{A} - {B}]", "n": len(ix), "mean_ape_pp": float(dd.mean()),
                            "mean_mae_bp": float((loss["MAE_bp"][A][ix] - loss["MAE_bp"][B][ix]).mean())})
        return out
    write(OUT / "subperiods.csv", window_rows(C.SUBPERIODS)); write(OUT / "stress.csv", window_rows(C.STRESS))
    years = sorted({o.year for o in origins})
    write(OUT / "yearly.csv", window_rows([(str(y), date(y, 1, 1), date(y, 12, 31)) for y in years]))
    # extremes
    ext, ext_b1 = [], []
    for rule in C.RULES:
        for k in np.argsort(-loss["APE_pp"][rule])[:10]:
            r = by[(origins[k], rule)]
            ext.append({"rule": rule, "origin": origins[k], "base_close": r["base_close"], "forecast_2dp": r["forecast_2dp"],
                        "target_date": r["target_date"], "target_close": r["target_close"], "ape_pp": loss["APE_pp"][rule][k]})
        if rule not in ("B0", "B1-7"):
            dd = loss["APE_pp"][rule] - loss["APE_pp"]["B1-7"]
            for k in np.argsort(-dd)[:10]:
                ext_b1.append({"rule": rule, "origin": origins[k], "d_ape_vs_B1-7_pp": float(dd[k]),
                               "ape_rule": loss["APE_pp"][rule][k], "ape_B1-7": loss["APE_pp"]["B1-7"][k]})
    write(OUT / "extremes_ape_top10.csv", ext); write(OUT / "extremes_vs_B1-7_top10.csv", ext_b1)
    # adjustments relative to B1-7 and coefficient stability
    adj, coefs = [], []
    yb = np.array([float(by[(o, "B1-7")]["yhat"]) for o in origins]); ya = np.array([float(by[(o, "B1-7")]["y_actual"]) for o in origins])
    for rule in C.RULES[2:]:
        yr = np.array([float(by[(o, rule)]["yhat"]) for o in origins]); a = 1e4 * (yr - yb); s = 1e4 * (ya - yb)
        adj.append({"rule": rule, "mean_bp": float(a.mean()), "sd_bp": float(a.std(ddof=1)), "median_abs_bp": float(np.median(np.abs(a))),
                    "max_abs_bp": float(np.abs(a).max()), "share_same_sign_as_y_minus_B1": float(np.mean(np.sign(a) == np.sign(s)))})
        for c in ("x5", "x21", "vrp"):
            v = [by[(o, rule)][f"coef_{c}"] for o in origins]
            if v[0] == "": continue
            v = np.array([float(x) for x in v])
            coefs.append({"rule": rule, "coef": c, "first": float(v[0]), "last": float(v[-1]), "min": float(v.min()), "max": float(v.max()),
                          "share_positive": float((v > 0).mean()), "sign_flips": int(np.sum(np.sign(v[1:]) != np.sign(v[:-1])))})
    write(OUT / "adjustments_vs_B1-7.csv", adj); write(OUT / "coefficient_stability.csv", coefs)
    (OUT / "data_cost.txt").write_text("F1-5, F1-21: S&P 500 closes only. F2 and two-factor rules: plus Cboe VIX_History.csv (free; redistribution terms not verified).\n")
    man = {"freeze_id": freeze_id, "results_sha256": DB.sha256(RES / "per_origin_forecasts.csv"),
           "outputs_sha256": {f.name: DB.sha256(f) for f in sorted(OUT.iterdir()) if f.is_file() and f.name != "analysis_manifest.json"}}
    (OUT / "analysis_manifest.json").write_text(json.dumps(man, indent=1))
    print("analysis done")


def write(path, rows):
    if not rows: path.write_text(""); return
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader()
        for r in rows: w.writerow({k: (repr(v) if isinstance(v, float) else v) for k, v in r.items()})


if __name__ == "__main__":
    main()
