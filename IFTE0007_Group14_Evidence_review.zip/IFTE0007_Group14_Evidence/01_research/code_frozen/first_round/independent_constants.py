"""Constants restated for independent_check.py (it does not import config.py). Round 6."""
RAW_Y = "inputs/yahoo_GSPC_1988_to_now.json"
RAW_V = "inputs/cboe_VIX_round1copy_20261105T185724Z.csv"
HIST_END, PARTIAL = "2026-11-04", "2026-11-05"
LAUNCH, FIRST_WED = "2003-09-22", "2003-09-24"
H, MINTR = 7, 260
EXPECTED_KEYS = 6608            # 944 origins x 7 rules
RULES = ["B0", "B1-7", "F1-5", "F1-21", "F2", "F1-5+F2", "F1-21+F2"]
SPEC = {"B1-7": [], "F1-5": ["x5"], "F1-21": ["x21"], "F2": ["vrp"], "F1-5+F2": ["x5", "vrp"], "F1-21+F2": ["x21", "vrp"]}
APPROVER = "Zhi"
REQUIRED = [RAW_Y, RAW_V, "inputs/round3_v3_evaluation_origins_reference.csv",
            "code/config.py", "code/data_build.py", "code/freeze_guard.py", "code/precheck.py", "code/main_run.py",
            "code/analysis.py", "code/independent_check.py", "code/independent_constants.py",
            "spec/precision_and_rounding.md", "spec/output_fields.md", "spec/independent_check_tolerances.md", "spec/environment.txt",
            "../04_round4_protocol_v3_1/protocol/first_round_7day_test_protocol_v3_1_prefreeze.md",
            "../04_round4_protocol_v3_1/protocol/run_rules_table_v3_1.csv"]
# tolerances (spec/independent_check_tolerances.md)
TOL = {"y": 1e-12, "x": 1e-12, "vrp_rel": 1e-10, "yhat": 1e-10, "coef_rel": 1e-8, "forecast_full": 1e-6,
       "ape": 1e-9, "abs_err_bp": 1e-6, "hac_rel": 1e-10, "price": 0.0}
