# 04_formal_run — the formal forecast (run 2026-11-12)

| Item | Value | File |
|---|---|---|
| Point forecast | **7,632.87** index points (full 7632.872005745523) | `formal_record/forecast_record.json` (`forecast_2dp`, `forecast_full`) |
| Target | S&P DJI official S&P 500 price-index close, 2026-11-20 16:00 New York | same (`target`) |
| Base date / base close used | 2026-11-11 / 7,619.38 (data value 7,619.38; no override) | same (`base_close_used`, `base_close_in_data`) |
| Model | n_train 1,206 (2003-09-24 … 2026-10-28, last label 2026-11-06); x21 −0.024127 (lookback 2026-10-13, 7,805.45); intercept 0.0019593; slope 0.0078798; ŷ +0.17692% | same |
| Mode / clock / route | FORMAL / system / main | same |
| Run start / finish | 2026-11-12T18:39:57Z / 18:39:58Z (cutoff 2026-11-13 12:00 London) | same; `formal_record/run_log_20261112T183957Z.txt` |
| Historical comparison with the D41 snapshot | 9,784 dates, 0 differences | same (`log`) |
| Independent recomputation | passed = true, 17/17 checks | `formal_record/independent_check.json` |
| Output hashes | forecast_record, independent_check, training_set, closes_used | `formal_record/SHA256_formal_outputs.txt` |
| Authorisation | Q33, Zhi Li, 2026-11-12 18:39:45 UTC (thread message) | archive `decision_log.md` (D-Q33) |
| Freeze of the formal record (P11) | approved and frozen by Zhi Li on 2026-11-12 19:35:38 UTC | `formal_record/FREEZE_RECORD_formal_EN_excerpt.json` (English excerpt; original in the archive, SHA-256 48d94926…6f5b) |

Software: macOS 26.6.2 (25G83), Python 3.11.4 (`-I`), numpy 1.24.3; frozen D41 scripts, SHA-256 checked before the run
(all 9 frozen files OK). The record's `data_file` is the absolute path on Zhi Li's Mac; route 3 rewrites it to a local path
on a copy.

## Data retrieval — `data_retrieval/fetch_log.txt`
Main route of data plan v3: two full downloads of Yahoo ^GSPC daily (period1 = 1988-01-01), 31 min 16 s apart.
| # | Retrieved (UTC) | File | SHA-256 | 11-11 close |
|---|---|---|---|---|
| 1 | 2026-11-12T17:25:48Z | `yahoo_GSPC_1988_to_now_20261112T172548Z.json` | 8b4ac826e85ddc24c4db92bf2654cdb085799c91c45b6b34b46ed153af76a34f | 7619.3798828125 → 7,619.38 |
| 2 (used) | 2026-11-12T17:57:04Z | `yahoo_GSPC_1988_to_now_20261112T175704Z.json` | 5dc23f3a0ff0d641ea3c6d90b8209d4f3e1ee57cc5fd5eb3c0f536f55d9da979 | 7619.3798828125 → 7,619.38 |
The dates and close values for all 9,789 rows through 11 November match across the downloads. The 12 November
intraday bar and live quote metadata account for the file differences. The script excludes the intraday bar. The files themselves are not shipped (restricted; see `../02_reproduce/inputs/`).

## Official close and FRED
`official_close/SPDJI_SP500_overview_2026-11-11close_CiBao_screenshot_2026-11-12_17.16.23.png` (SHA-256 4e9d0327…9b20): S&P DJI
S&P 500 overview page, https://www.spglobal.com/spdji/en/indices/equity/sp-500/#overview, "As of Nov 11, 2026", 7,619.38,
USD, Price Return; screenshot by Ci Bao, page viewed 2026-11-12 17:14 London (= UTC). Ci Bao reported the FRED SP500 value
agrees. FRED was unreachable from Zhi Li's Mac during the original check on 12 November. The FRED table was checked
on 13 November and gives the same value, 7,619.38. See the [dated follow-up](../01_research/source_register.md#c-follow-up-source-checks-on-13-november-2026).

## Member verification — relayed by Zhi Li
| Verifier | Checked | Result | Confirmation |
|---|---|---|---|
| 1 Ci Bao | official screenshot and source | 2026-11-11 S&P 500 Price Return close 7,619.38 | relayed by Zhi Li, 2026-11-12 18:53:22 UTC; member's own time not provided |
| 2 Shujun Zhou | Compared `base_close_used` with the screenshot and reported reviewing the result | The base close agrees at 7,619.38. The base-close comparison is the only specified check in the confirmation. | as above |
| 3 Loli Kalaitzi | First page of the review PDF against the formal record | single point 7,632.87, target date and time agree | as above |
| Approver Zhi Li | freeze of the formal record | approved and frozen by Zhi Li on 2026-11-12 19:35:38 UTC | Zhi Li's own message |
Full sheet, sections A–D (English translation of the Chinese original in the archive): `official_close/manual_verification_checklist_completed_2026-11-12_EN_translation.md`.
Claude Code ran the separate recomputation script, which passed 17/17 checks (`formal_record/independent_check.json`).
The forecast and target time Loli checked on the review PDF also appear on the final cover. Section C of the
completed checklist gives the reviewed PDF's SHA-256. The formal run used the Yahoo main route under the archived v3
data plan. The commands and outputs are in `formal_record/run_log_20261112T183957Z.txt`.
