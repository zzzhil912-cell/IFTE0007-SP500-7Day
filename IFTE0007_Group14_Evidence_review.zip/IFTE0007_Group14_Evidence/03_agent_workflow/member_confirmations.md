# Member checks, formal verification and approval

Zhi Li approved and froze the formal record on 12 November 2026 at 19:35:38 UTC. The archive references below identify
the source of each check. The formal member confirmations were relayed by Zhi Li.

| Stage | Date | What it covers |
|---|---|---|
| A, B. Historical checks | 7–8 November 2026 | October rehearsal, source checks and a check of the summary results across 944 historical forecast origins |
| C. Formal verification | 12 November 2026 | Official close, base close used and forecast and target on the review PDF cover |
| D. Approval and freeze (P11) | 12 November 2026, 19:35:38 UTC | Zhi Li's approval of the formal forecast 7,632.87 |

## A. Checks by Zhi Li (7 November 2026)
Recorded from Zhi Li's own statement in the project thread (message of 2026-11-07 00:27 UTC).

| # | Member | What was checked | Evidence used | Conclusion |
|---|---|---|---|---|
| M1 | Zhi Li | Calculator check of the 2026-10-21 rehearsal F1-21 input: took the 2026-10-21 and 2026-09-22 closes (21-trading-day lookback), recomputed ln(7757.17 / 7764.64) and compared it with x21 in the record | archive `20_round20_prefreeze_closeout/tests/outputs/T1_main/closes_used.csv` and `forecast_record.json` (x21 = −0.0009625166880290193) | agrees |
| M2 | Zhi Li | Checked the 944-origin comparison of F1-21 vs B1-7: mean APE of both rules and both intervals (HAC and block bootstrap) | `../01_research/results/adoption/factor_rule_summary_table.csv` (round 17) and `../01_research/results/first_round/comparisons.csv` (round 6 frozen results) | supports "no stable predictive increment" |
| M3 | Zhi Li | Read the abstract of Moskowitz, Ooi & Pedersen (2012) and confirmed its market (futures/forwards) and horizon (monthly, 1–12 months), so it is used as motivation only | publisher/author PDF (archive `01_round1_scope_and_factors/sources/pdf/`) | motivation only |

## B. Member reviews (8 November 2026)
| Who | Check | Result | Evidence |
|---|---|---|---|
| Ci Bao | exact historical-rehearsal reproduction with the frozen inputs in own environment | 1,203 labels, 7,772.91, matches the frozen reference; independent 18/18 | archive `21_member_reproduction_Ci_Bao_2026-11-08/` |
| Shujun Zhou (AI-assisted execution) | v1.3 ZIP: synthetic route and exact rehearsal route (macOS 13.3.1; Python 3.14.6 / 3.11.4) | both PASS: sample 4953.99 (15/15); exact 7,772.91 (12/12, independent 18/18) | archive `22_member_verification_Shujun_Zhou_2026-11-08/` |
| Shujun Zhou | manual x21 spot check ln(7757.17/7764.64) | Shujun reported a match. The archive contains her statement. Codex separately recomputed the value from the saved closes. | same archive |
| Loli Kalaitzi (with Zhi Li in person) | reproduction check from the ZIP; English, figures, citations and format review | completed, confirmed by Zhi Li 2026-11-08 15:36 UTC | archive decision log M-Loli-Kalaitzi-1 |
| Ci Bao, Shujun Zhou | source, data-definition, unit and publication-time check; Ci Bao: review of the factor choice | completed, confirmed by Zhi Li 2026-11-08 | archive decision log M-Ci-Bao-2, M-Ci-Bao-3 |

## C. Formal verification (12 November 2026)
Member confirmations **relayed by Zhi Li** in the project thread at 2026-11-12 18:53:22 UTC; the members' own confirmation
times were not provided.

| Verifier | What was checked | Result |
|---|---|---|
| 1 Ci Bao | S&P DJI official page screenshot and source | 2026-11-11 S&P 500 Price Return close 7,619.38 (screenshot captured by Ci Bao, page viewed 17:14 UTC) |
| 2 Shujun Zhou | `base_close_used` in the formal record against the official screenshot; review of the formal result | The base close agrees at 7,619.38. Shujun also reported reviewing the formal result, with the base-close comparison the only specified check. |
| 3 Loli Kalaitzi | first page of the review copy of the report PDF against `forecast_record.json` | single point 7,632.87, target date and time agree on the review copy checked on 12 November |

Separately from Shujun Zhou's review, the frozen independent script recomputed the formal record and passed 17 of 17 checks
(`../04_formal_run/formal_record/independent_check.json`), including that the record used the system clock and finished
before the cutoff. Details: `../04_formal_run/README_formal_run.md` and the completed checklist (English translation)
`../04_formal_run/official_close/manual_verification_checklist_completed_2026-11-12_EN_translation.md`.

## D. Approval and freeze (P11)
Zhi Li approved and froze the formal forecast of 7,632.87 index points at **2026-11-12 19:35:38 UTC** in Zhi Li's own thread
message (English excerpt: `../04_formal_run/formal_record/FREEZE_RECORD_formal_EN_excerpt.json`; original record in the
group archive, SHA-256 48d94926…6f5b).
