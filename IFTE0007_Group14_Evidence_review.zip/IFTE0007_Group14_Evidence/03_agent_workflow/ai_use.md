# AI use

This record supplements the AI-use declaration in the report.

| Tool | Used for | How the output was checked |
|---|---|---|
| Claude Code (Anthropic), model ID claude-opus-5-5, as recorded in the local session metadata | Source search and reading; data snapshots with URL, time and hash; protocol drafts; all Python code (back-tests, diagnostics, production and independent scripts, tests, figures); drafts of the evidence documents and the report; the formal run on 2026-11-12 after Zhi Li's authorisation | hash-guarded freezes before each run; synthetic self-tests; independent recomputation scripts with no shared code; 25 pre-freeze tests; clean-directory reproduction from the ZIP; Zhi Li's personal checks M1–M3; member checks of the official close, recorded base close and review PDF cover, as detailed in `member_confirmations.md`. Zhi Li approved the protocols, freezes, model choice and formal record |

Codex (OpenAI) assisted with protocol review and rehearsal checks. Its review points on protocol drafts (rounds 2–4)
reached Claude through Zhi Li and were rechecked by script before any change (e.g. the label-overlap correction C2/C7); in
the rehearsal checks it assisted Shujun Zhou's reruns and helped review Ci Bao's saved outputs. See `member_confirmations.md`. The model
version was not recorded.

No AI output is cited as evidence; every number comes from the saved data and scripts. Significant instructions are
excerpted in `tool_call_excerpts.md`; corrections are listed in `../01_research/corrections_and_failures.md`.
