# 03_agent_workflow — how the AI agent was used, corrected and reviewed

| File | Content |
|---|---|
| `figures/fig3_research_workflow.png` | Report Figure 2: research workflow from question and boundary through sources, experiments, model choice and checks to the formal forecast (script `make_workflow_fig_final.py`) |
| `figures/fig2_f121_vs_b17_intervals.png` | Report Figure 1: F1-21 minus B1-7 paired APE difference with intervals and the two phases |
| `figures/make_figures.py` | Script that draws Report Figure 1 (`fig2_f121_vs_b17_intervals.png`) from `../01_research/results/` |
| `human_review_and_decisions.md` | **Human Review and Decisions**: D5, D13, D16, D17, D27, D37, D38, D41 with propose / execute / review / verify / approve |
| `member_confirmations.md` | Member confirmations: M1–M3 (Zhi Li), member reviews of 2026-11-08 and the formal-record verification of 2026-11-12 |
| `tool_call_excerpts.md` | Translated instruction excerpts, tool-call excerpts from logs, two corrections as short transcripts, and Claude trial runs vs member acceptance |
| `ai_use.md` | Which AI tools were used, for what, and how their output was checked |

Original records (decision log, session logs, correction logs, run logs) are in Chinese and stay unchanged in the group's
internal project archive; the files here are English translations or excerpts, each naming its archive source.
