"""Figure 2 for the report: research workflow (question -> evidence -> experiments -> choice), with responsibilities."""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT = sys.argv[1]
INK, INK2 = "#1b1b1b", "#4a4a4a"
ZHI, AI, MEM, FIND = "#E1EFF1", "#F2F2F2", "#E4E9F2", "#FFF4E0"
plt.rcParams.update({"font.family": "Arial"})
fig, ax = plt.subplots(figsize=(6.8, 4.9), dpi=220)
ax.set_xlim(0, 100); ax.set_ylim(0, 74); ax.axis("off")


def box(x, y, w, h, title, body, who, fc):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.35,rounding_size=1.2", fc=fc, ec=INK2, lw=0.7))
    ax.text(x + 1, y + h - 1.4, title, fontsize=7.4, fontweight="bold", va="top", color=INK)
    ax.text(x + 1, y + h - 4.6, body, fontsize=6.2, va="top", color=INK, linespacing=1.25)
    ax.text(x + w - 0.8, y + 0.8, who, fontsize=5.8, ha="right", va="bottom", color=INK2, style="italic")


def arr(x1, y1, x2, y2, txt=None, dx=0, dy=1.2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.9))
    if txt:
        ax.text((x1 + x2) / 2 + dx, (y1 + y2) / 2 + dy, txt, fontsize=5.6, color=INK2, ha="center", style="italic")


W, H = 30, 16
# row 1
box(1, 52, W, H, "1  Question and boundary", "Can trend or VRP improve a 7-trading-\nday S&P 500 forecast? Base 11 Nov,\ntarget 20 Nov; inputs dated <= base", "Zhi Li sets; agent encodes rules", ZHI)
box(35, 52, W, H, "2  Sources and data", "Original papers, official calendars;\nYahoo and Cboe files frozen with\nURL, retrieval time and hash", "agent (tools: web, files)", AI)
box(69, 52, W, H, "3  Candidate screening", "Nine directions on mechanism, sign,\nhorizon, point-in-time data, cost;\nmomentum and VRP admitted", "agent proposes; Zhi Li decides", AI)
# row 2 (right to left)
box(69, 29, W, H, "4  First back-test", "7 rules, 944 weekly origins,\nHAC + block bootstrap + phases.\nFinding: no stable gain over drift", "agent runs code", FIND)
box(35, 29, W, H, "5  Diagnosis", "VRP losses in 27 crisis origins;\n22 Oct 2008: extreme input and a\nslope set by one observation", "agent analyses", FIND)
box(1, 29, W, H, "6  Targeted experiments", "Capped input, Huber, rolling window;\nthen robust drift with no factor:\nVRP adds nothing beyond it", "Zhi Li approves each test", FIND)
# row 3
box(1, 6, W, H, "7  Model choice", "F1-21: best factor rule, one data\nsource; no stable gain over drift\nstated as the main limitation", "Zhi Li adopts", ZHI)
box(35, 6, W, H, "8  Checks", "Hash-locked runs, separate\nrecomputation, October rehearsal", "Claude Code, Ci Bao, Shujun Zhou\nLoli Kalaitzi, Zhi Li", MEM)
box(69, 6, W, H, "9  Formal forecast", "Claude Code runs and recomputes.\nClose and cover checks.\nZhi Li approves and freezes.", "Ci Bao, Shujun Zhou, Loli Kalaitzi\nZhi Li", "#ffffff")
arr(31.6, 60, 34.4, 60); arr(65.6, 60, 68.4, 60); arr(84, 51.4, 84, 45.6)
arr(68.4, 37, 65.6, 37); arr(34.4, 37, 31.6, 37); arr(16, 28.4, 16, 22.6)
arr(31.6, 14, 34.4, 14); arr(65.6, 14, 68.4, 14)
# correction note
ax.add_patch(FancyBboxPatch((3, 47.0), 77, 3.0, boxstyle="round,pad=0.25,rounding_size=0.8", fc="#ffffff", ec="#C00000", lw=0.6, ls="--"))
ax.text(4, 48.5, "Correction before testing: weekly 7-trading-day outcomes overlap by 2-4 days; inference rebuilt (HAC, phases)", fontsize=5.7, color="#8B0000", va="center")
for fc, lab, x in ((ZHI, "decision by Zhi Li", 1), (AI, "work by the agent", 22), (FIND, "finding that shaped the next step", 41), (MEM, "Human checks", 72)):
    ax.add_patch(FancyBboxPatch((x, 71.0), 2.2, 1.6, boxstyle="round,pad=0.1", fc=fc, ec=INK2, lw=0.5))
    ax.text(x + 3.2, 71.8, lab, fontsize=6.3, va="center", color=INK)
fig.savefig(f"{OUT}/fig3_research_workflow.png", bbox_inches="tight", facecolor="white")
print("ok")
