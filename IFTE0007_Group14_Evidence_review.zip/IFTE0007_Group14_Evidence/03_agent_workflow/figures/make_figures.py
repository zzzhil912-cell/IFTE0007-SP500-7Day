import csv, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import sys
P = sys.argv[1]; OUT = sys.argv[2]
INK, INK2, GRID, BLUE, ORANGE = "#1b1b1b", "#4a4a4a", "#e2e4e8", "#1F3864", "#2A7F8E"
plt.rcParams.update({"font.family": "Arial", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2})

# Report Figure 1 (file fig2_f121_vs_b17_intervals.png). The former mean-APE bar chart and the v1.3 workflow chart were removed;
# the report's workflow figure is drawn by make_workflow_fig_final.py.
# Figure 2: F1-21 minus B1-7 paired APE difference intervals
c = [r for r in csv.DictReader(open(f"{P}/01_research/results/first_round/comparisons.csv")) if r["A"] == "F1-21" and r["B"] == "B1-7" and r["metric"] == "APE_pp"][0]
ph = [r for r in csv.DictReader(open(f"{P}/01_research/results/first_round/phases.csv")) if r["A"] == "F1-21" and r["B"] == "B1-7" and r["metric"] == "APE_pp"]
m = float(c["mean"])
items = [("HAC 90 %", c["hac_90_lo"], c["hac_90_hi"], m), ("HAC 95 %", c["hac_95_lo"], c["hac_95_hi"], m),
         ("Block bootstrap 90 %", c["boot_90_lo"], c["boot_90_hi"], m), ("Block bootstrap 95 %", c["boot_95_lo"], c["boot_95_hi"], m)]
fig, ax = plt.subplots(figsize=(6.3, 2.9), dpi=200)
for i, (lab, lo, hi, mm) in enumerate(items):
    ax.plot([float(lo), float(hi)], [i, i], color=BLUE, lw=2, solid_capstyle="round"); ax.plot(mm, i, "o", color=BLUE, ms=6, mec="white", mew=1.5)
    ax.text(float(hi) + 0.0006, i, f"[{float(lo):+.4f}, {float(hi):+.4f}]", va="center", fontsize=7.5, color=INK2)
for j, r in enumerate(ph):
    y = len(items) + j
    ax.plot(float(r["mean"]), y, "D", color=ORANGE, ms=5.5, mec="white", mew=1.2)
    mv = float(r["mean"]); ax.text(mv + (0.0012 if mv > 0 else -0.0012), y, f"{mv:+.4f} (descriptive)", va="center", ha="left" if mv > 0 else "right", fontsize=7.5, color=INK2)
labels = [x[0] for x in items] + [f"Phase {r['phase']} mean (n = {r['n']})" for r in ph]
ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels); ax.invert_yaxis()
ax.axvline(0, color=INK, lw=1); ax.text(0.0003, -0.75, "zero = no difference", fontsize=7, color=INK)
ax.set_xlabel("F1-21 minus B1-7, mean paired APE difference (pp; negative = F1-21 better)")
ax.set_xlim(-0.016, 0.022); ax.grid(axis="x", color=GRID, lw=0.6); ax.set_axisbelow(True)
for s in ("top", "right"): ax.spines[s].set_visible(False)
fig.tight_layout(rect=(0, 0.06, 1, 1)); fig.text(0.01, 0.01, f"Full-sample mean {m:+.5f} pp (dot), n = 944. HAC: Newey-West lag 1. Bootstrap: moving block 4, B = 2,000, seed 20261111.", fontsize=7, color=INK2)
fig.savefig(f"{OUT}/fig2_f121_vs_b17_intervals.png"); plt.close(fig)
