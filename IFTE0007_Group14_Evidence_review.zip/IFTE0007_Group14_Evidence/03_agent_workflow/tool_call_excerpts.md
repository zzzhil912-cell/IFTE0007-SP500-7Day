# Instructions, tool calls and short transcripts (excerpts, English)

The table records significant instructions from Zhi Li to Claude Code. Quoted text is translated from the Chinese
project thread, and unquoted text summarises an instruction. Times are in UTC. Run-log excerpts omit some path details.

## 1. Instructions (Zhi → Claude), translated
| Time (UTC) | Excerpt (translation) | Effect |
|---|---|---|
| 2026-11-05 18:50 | "This round is authorised for brief checking, original-source investigation, limited read-only data probes and candidate screening. Stop at the review point after delivery. Only after I review the candidates and approve a test protocol may you fit models, run back-tests or make an adoption decision. The formal forecast needs a separate authorisation." | sets the staged review and authorisation rules |
| 2026-11-05 20:59:40 | Approves freezing the 17 files in the round-6 hash list and running the first 7-day back-test. | D27 |
| 2026-11-05 23:36 | Defer the macro count and SKEW; write "local feasibility check done, historical publication-time coverage did not meet back-test admission", not "back-test invalid". | D37 |
| 2026-11-05 23:59:57 | Adopt F1-21; prepare production, rehearsal on 2026-10-21, adverse scenarios and the data plan; the formal forecast is authorised separately. | D38 |
| 2026-11-06 00:56:26 | "I approve freezing the 9 files in round 20's SHA256_to_freeze_production_v2.txt. Please register the freeze record; the formal forecast waits for my separate authorisation." | D41 |
| 2026-11-12 18:39:45 | "I approve Q33; please run it formally now. Use the second verified Yahoo snapshot yahoo_GSPC_1988_to_now_20261112T175704Z.json … run F1-21 formally with the D41 frozen scripts and the v3 main route, using the real system time … the base is the 11 November close of 7,619.38; no override is needed." | Q33: formal run |
| 2026-11-12 19:35:38 | "I confirm that the members' verification is complete and agree to freeze 7,632.87 index points as Group 14's formal forecast. Please register P11 at the actual time of this message …" | P11: freeze of the formal record |

## 2. Tool calls (excerpts from logs)
First back-test, after Zhi's approval (archive `07_round7_first_backtest/logs/`):
```
OK  inputs/yahoo_GSPC_1988_to_now.json  a2d671c5…  … (17 files)
files: 17 all match: True
freeze record written 2026-11-05T20:59:58+00:00 | guard verify ok
### command: cd 06_round6_code_revision/code && python -I main_run.py
### start 2026-11-05T21:00:03Z
done {'per_origin_forecasts.csv': 'da5b0674…'}
### exit 0 at 2026-11-05T21:00:04Z
### command: … python -I independent_check.py
{"rows_in_file": 6608, "unique_keys": 6608, "n_failures": 0, "passed": true}
```
Rehearsal, first attempt failed (archive `18_round18_production_prep/logs/rehearsal_production_2026-10-21_run1_FAILED_json_bool.txt`):
```
### command: python -I code/f1_21_production.py --yahoo inputs/yahoo_GSPC_1988_to_now.json --base 2026-10-21 …
Traceback … json.dumps(rec …)  →  TypeError: Object of type bool_ is not JSON serializable
```
→ fixed by casting numpy booleans to Python bool; rerun passed (archive `18_round18_production_prep/logs/rehearsal_final_2026-10-21.txt`).

Production freeze (archive `20_round20_prefreeze_closeout/logs/freeze_production_hash_verify.txt`):
```
files: 9 all match: True
freeze record written 2026-11-06T00:56:35+00:00
FREEZE_RECORD_production.json sha256 806ebe00…
```

Formal run (archive `07_formal_run/logs/run_20261112T183957Z.log`; also `../04_formal_run/formal_record/run_log_20261112T183957Z.txt`):
```
python3 -I code/f1_21_production.py --formal --yahoo …/yahoo_GSPC_1988_to_now_20261112T175704Z.json --retrieved-utc 2026-11-12T17:57:04Z --base 2026-11-11 --out …/20261112T183957Z --compare-snapshot inputs/yahoo_GSPC_1988_to_now.json
{"route": "main", "base_date": "2026-11-11", "base_close_used": "7619.38", "n_train": 1206, … "forecast_2dp": "7632.87"}
production exit 0
python3 -I code/f1_21_independent.py --record …/forecast_record.json --out …
passed: True
independent exit 0
```

## 3. Two real corrections, as short transcripts
**C1 (citation retracted).** In round 1 Claude cited a DOI for Johnson (2017) as the source of a VIX term-structure
factor. Claude's own check on the publisher page in round 2 showed that the DOI belongs to Carr and Wu (2017). The citation
was retracted, the correct DOI recorded, and the factor was not tested (decision D15).

**C2/C7 (label overlap).** The draft said weekly 7-day labels were "essentially non-overlapping". After review points raised
by Zhi, Claude's script showed adjacent Wednesday labels share 2 trading days; the alternate-origin phases were then
rebuilt so that each phase (472 origins) has no overlap, and phase results are reported as descriptive only.

## 4. Claude trial runs vs member acceptance
| Run | Done by | Status |
|---|---|---|
| Self-tests on synthetic data (48/48 round 6; extension and Huber self-tests) | Claude | trial runs (AI) |
| Frozen back-tests and independent key checks (rounds 7, 12, 14) | Claude, after Zhi's approval | AI-executed; approved by Zhi |
| Rehearsal 2026-10-21 and 25/25 pre-freeze tests | Claude | AI-executed |
| Clean-directory reproduction from the v1.3 ZIP (synthetic and exact routes) | Claude | AI trial run; log kept in the group archive |
| Calculator check of x21 (M1), comparison check (M2), MOP abstract (M3) | Zhi | **member confirmation** |
| October rehearsal rerun in her own environment | Ci Bao | saved outputs, including the separate script's 18/18 checks |
| Synthetic and October rehearsal reruns, plus a reported manual spot check of the 21-day return | Shujun Zhou | AI-assisted reruns in her own environment. The manual check is recorded in her statement. |
| Joint rehearsal reproduction check and report review | Loli Kalaitzi and Zhi Li | confirmed by Zhi Li on 8 November. See `member_confirmations.md`. |
