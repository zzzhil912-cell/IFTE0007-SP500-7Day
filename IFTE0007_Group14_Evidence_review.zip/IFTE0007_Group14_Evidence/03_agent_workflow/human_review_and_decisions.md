# Human Review and Decisions

Claude Code proposed experiments and ran the code. Zhi Li set the scope, reviewed decisions and gave the approvals
recorded in the project thread. Times are in UTC. The original decision log is in the group archive.

## Key decisions
| # | Time (UTC) | Decision | Propose | Execute | Review | Verify | Approve |
|---|---|---|---|---|---|---|---|
| D5 | 2026-11-05 19:23 | Keep base 2026-11-11 and a 7-trading-day horizon (target 2026-11-20) | Zhi (group plan); Claude raised the 11-12 alternative as question Q1 | — | Zhi | Claude checked the NYSE calendar (11-12 … 11-20 = 7 days) | Zhi |
| D13 | 2026-11-05 19:37 | Label every evaluation exploratory: part of the evaluation sample had already been examined | Claude (C5 self-correction) | Claude | Zhi | — | Zhi |
| D16 | 2026-11-05 19:49 | Zhi checked the seven rules and the sample design; asked for a pre-freeze v3.1 revising only statistics wording, attribution and run separation | Zhi | Claude (v3.1) | Zhi | — | Zhi |
| D17 | 2026-11-05 19:49 | All 15 paired comparisons exploratory; an interval excluding zero is a diagnostic clue only; adoption also weighs error size, stability across periods, performance vs B1-7 and running cost | Zhi | — | Zhi | — | Zhi |
| D27 | 2026-11-05 20:59:40 | Freeze 17 files and run the first 7-day back-test | Claude (freeze list) | Claude (freeze guard, run, independent key check) | Zhi | independent check script (6,608 rows, 0 failures) | Zhi |
| D37 | 2026-11-05 23:36 | Defer the macro-announcement count and SKEW; wording "local feasibility check done; historical publication-time coverage did not meet back-test admission", not "back-test invalid" | Claude (pilot result) | Claude | Zhi | — | Zhi |
| D38 | 2026-11-05 23:59:57 | Adopt F1-21 as the 7-day main specification; B0, B1-7, Huber-Intercept as benchmarks only; record must state no stable predictive increment over B1-7 | Claude (R10) | Claude (production script, independent recomputation, rehearsal) | Zhi | Later checks on 7 November: Zhi checked the rehearsal input and comparison results (M1–M2 in `member_confirmations.md`). | Zhi |
| D41 | 2026-11-06 00:56:26 | Freeze the 9 production files (code, independent check, frozen inputs, record template, data plan v3, manual checklist, tests 25/25) | Claude (hash list v2) | Claude (freeze record written 00:56:35) | Zhi | hash verification log (9/9 match) | Zhi |

Other approvals of freezes: D32 (stage-1 extension, 18 files, 22:21:13) and D34 (Huber-Intercept, 17 files, 22:37:22).

## Who did what (summary)
- **Claude Code** searched and read sources, drafted protocols and documents, wrote and ran the Python scripts, and ran the self-tests and scripted checks.
- **Zhi Li** set the research question and data boundary, chose the experiments, approved the model and freezes, and performed the calculator, results and literature checks recorded as M1–M3 in `member_confirmations.md`.
- **Ci Bao** reviewed the factor choice and checked sources with Shujun Zhou. She reproduced the October rehearsal in her own environment.
- **Shujun Zhou** worked on economic interpretation and source checks, ran the synthetic and historical rehearsal routes with AI assistance, and reported a manual spot check of the 21-day return.
- **Loli Kalaitzi** reviewed the English, figures, citations and format, checked a rehearsal reproduction with Zhi Li, and prepared the presentation slides.

## Verifier assignments (set by Zhi Li, 2026-11-07)
Ci Bao was assigned the official source and screenshot check. Shujun Zhou was assigned to check the base close used
against the screenshot and review the result. Loli Kalaitzi was assigned the comparison with the report cover. Zhi Li was
responsible for final approval. For what each member confirmed on 12 November, see [the formal run summary](../04_formal_run/README_formal_run.md#member-verification--relayed-by-zhi-li).

## Formal run decisions
Q33: Zhi Li authorised the formal run on 2026-11-12 18:39:45 UTC; the run took place 18:39:57–18:39:58 UTC.
P11: the formal record was approved and frozen by Zhi Li on 2026-11-12 19:35:38 UTC.
