# Key numbers ↔ evidence

Every research number used in the report and the file it comes from (paths relative to this package unless marked
"archive" = the group's internal project archive).

| Number | Value | Source file (column / field) |
|---|---|---|
| Evaluation origins | 944 Wednesdays, 2008-09-24 to 2026-10-21 | `01_research/results/first_round/levels.csv` (n) |
| Mean APE B0 / B1-7 / F1-5 / F1-21 / F2 | 2.0833 / 2.0615 / 2.0679 / 2.0613 / 2.1224 pp | `01_research/results/first_round/levels.csv` (mean_ape_pp) |
| Mean APE Huber-Intercept (descriptive) | 2.0382 pp | `01_research/results/huber_intercept/levels.csv` |
| Mean MAE B0 / B1-7 / F1-5 / F1-21 / F2 / Huber-Intercept | 207.6 / 205.2 / 205.8 / 205.2 / 212.1 / 202.5 bp | the `levels.csv` files (mean_mae_bp) |
| Δ vs B1-7 and share of origins better | B0 +0.0218, 42.5%; F1-5 +0.0064, 50.8%; F1-21 −0.0002, 52.5%; F2 +0.0609, 47.4%; Huber-Intercept −0.0233, 57.1% | `01_research/results/adoption/factor_rule_summary_table.csv` (mean_d_vs_base, share_better_than_base) |
| Mean paired APE difference, F1-21 minus B1-7 | −0.00023 pp (−0.000229) | `01_research/results/first_round/comparisons.csv`, id P1, APE_pp, mean |
| HAC standard error of that difference | 0.00666 pp, about 29 × the absolute mean difference | same row, hac_se (0.006662673684962538) |
| HAC 90% / 95% interval | [−0.0112, 0.0107] / [−0.0133, 0.0128] | same row, hac_90_lo/hi, hac_95_lo/hi |
| Block-bootstrap 90% / 95% interval | [−0.0106, 0.0095] / [−0.0123, 0.0120] | same row, boot_90_lo/hi, boot_95_lo/hi |
| Alternating-week phases (472 origins each) | +0.0052 / −0.0057 pp | `01_research/results/first_round/phases.csv`, P1 APE_pp |
| Sub-periods and stress windows, F1-21 − B1-7 | 2010–14 −0.015; 2015–19 −0.005; 2008–09 +0.042; 2020–26 +0.006; GFC +0.17; COVID +0.12; 2022 +0.009 | `01_research/results/adoption/stability_by_subperiod.csv` |
| Huber-Intercept − B1-7 | −0.0233 pp; HAC 90% [−0.0339, −0.0126]; better in 4 of 4 sub-periods | `01_research/results/huber_intercept/comparisons.csv` (H1); `factor_rule_summary_table.csv` |
| Factor specifications tested | 8 (F1-5, F1-21, F2, F1-5+F2, F1-21+F2, F2-clip, F2-Huber, F2-R156) | `01_research/results/adoption/factor_rule_summary_table.csv` |
| F1-21 slope positive / 5-day slope sign changes | 99.7% of origins, 1 sign change / 14 sign changes | `01_research/results/first_round/coefficient_stability.csv` |
| Rehearsal base close 2026-10-21; lookback close 2026-09-22 | 7,757.17; 7,764.64 | `02_reproduce/expected/exact_expected.json`; archive `20_round20_prefreeze_closeout/tests/outputs/T1_main/forecast_record.json` |
| Rehearsal x21 | −0.000963 | same record (x21) |
| Rehearsal training labels | 1,203 (2003-09-24 to 2026-10-07; last label ends 2026-10-16) | same record |
| Rehearsal intercept at zero momentum â | 0.002034 (+0.2034%) | same record (coef_intercept) |
| Rehearsal slope b̂ and momentum term b̂·x | 0.007882; 0.007882 × −0.000963 = −0.0008% | same record (coef_x21) |
| Rehearsal ŷ | +0.2027% | same record (yhat_log_return) |
| Rehearsal decomposition within the F1-21 forecast | intercept P×(exp(â) − 1) = +15.80 points; momentum P×[exp(â + b̂x) − exp(â)] = −0.06 points; total +15.74 | computed from the same record |
| Rehearsal point forecast (target 2026-10-30) | **7,772.91** (historical rehearsal, not the forecast) | same record (forecast_2dp); reproduced by route 2 |
| Sensitivity of the rehearsal forecast to x | 21-day log return −0.20 → about −16 bp | slope × −0.20 |
| 7-day distribution since 2003-09-24 (every trading day, n = 5,809) | 5% quantile: index −4.01%, log −4.10%; 1% quantile: index −8.28%, log −8.64% | archive `18_round18_production_prep/scenarios/scenarios_output.txt` |
| Worst 7-day window | 2008-10-01 to 2008-10-10: −22.6%; APE 29.4 with the rehearsal ŷ | archive `18_round18_production_prep/scenarios/worst_7d.csv` |
| Frozen production files | 9; approved 2026-11-06T00:56:26Z (D41) | `02_reproduce/freeze/FREEZE_RECORD_production.json` |
| Pre-freeze tests (archived evidence) | 25/25 on 2026-11-06 | `02_reproduce/test_record/prefreeze_tests_25of25_EN.md` |
| Formal point forecast and formal inputs | see "Formal forecast" below | `04_formal_run/` |

## Formal forecast
| Number | Value | In the report | Source file (field) |
|---|---|---|---|
| Final point forecast | **7,632.87** (7632.872005745523) | cover, Exec. summary, §6, Table 3 | `04_formal_run/formal_record/forecast_record.json` (forecast_2dp, forecast_full) |
| Base close used (2026-11-11) | 7,619.38 | §6, Table 3 | same (base_close_used); official screenshot `04_formal_run/official_close/` |
| Formal x21 | −0.024127 (−0.02412720609566343) | Table 3 | same (x21) |
| Formal intercept â (labels) | 0.0019593 (+0.1959%) (1,206) | Table 3 | same (coef_intercept, n_train) |
| Formal slope and momentum term | 0.007880 × −0.024127 = −0.0190% | Table 3 | same (coef_x21 × x21) |
| Formal ŷ | +0.1769% (0.001769182578364456); forecast 0.1771% above base | Table 3, Table 4 text | same (yhat_log_return) |
| Formal decomposition | intercept +14.94 points; momentum −1.45 points | — | computed from the same record |
| Retrieval | 2026-11-12 17:57:04 UTC; SHA-256 5dc23f3a…a979 | §1 | same (retrieval) |
| Run times | 18:39:57–18:39:58 UTC, 12 November | §6 | same (run_started_utc, run_finished_utc) |
| Independent recomputation | 17 of 17 checks passed | §6 | `04_formal_run/formal_record/independent_check.json` |
| Table 4 (formal) | points at 7,619: −631 / −306 / +38 / +310 / +499 / −1,718; APE 9.22 / 4.37 / 0.32 / 3.74 / 5.98 / 29.35; score 3.90 / 28.17 / 48.42 / 31.30 / 20.09 / 0 | Table 4 | 5,809 windows from the frozen snapshot (≤ 2026-11-04), unrounded ŷ; method of archive `18_round18_production_prep/scenarios/adverse_scenarios_7d.py` |
| Body word count | Approximately 2,367 (limit 2,400) | declarations | Estimate from the original Word count and the net change in Section 6 |
