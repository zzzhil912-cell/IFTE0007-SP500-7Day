# IFTE0007 — S&P 500 seven-trading-day forecast: Evidence package (Group 14)

UCL IFTE0007 group project, Group 14 (Zhi Li, Ci Bao, Shujun Zhou, Loli Kalaitzi). This package holds the code and
supporting evidence for the report; the slides are separate.

| Item | Value |
|---|---|
| Market and unit | S&P 500 **price** index (not total return, futures or ETF), index points |
| Target | S&P Dow Jones Indices official close on **Friday 20 November 2026, 16:00 New York (EST), 21:00 London (21:00 UTC)** |
| Base close | final close of Wednesday **11 November 2026: 7,619.38** (equal to the S&P DJI official value; no override) |
| Information cutoff | **13 November 2026, 12:00 London** |
| Model | **F1-21** (decision D38): 21-trading-day past log return, expanding OLS with intercept, predicting the 7-trading-day log return |
| **Formal forecast** | **7,632.87 index points** (`04_formal_run/formal_record/forecast_record.json`, `forecast_2dp`) |
| Formal run | 2026-11-12 18:39:57–18:39:58 UTC, system clock, main route; independent recomputation passed 17/17 |
| Verification records | See the [formal run summary](04_formal_run/README_formal_run.md) for the close, cover and freeze checks. |

The October rehearsal value **7,772.91** (base 2026-10-21, target 2026-10-30) is a historical test of the procedure, **not
the forecast**.

## 1. Set up with Python 3.11
```
unzip IFTE0007_Group14_Evidence_review.zip
cd IFTE0007_Group14_Evidence
python3 -m venv .venv && source .venv/bin/activate          # Windows: .venv\Scripts\activate
python3 -m pip install -r 02_reproduce/requirements.txt     # numpy, pandas, python-dateutil
cd 02_reproduce
```
Recorded runs used Python 3.11.4 with numpy 1.24.3, pandas 1.5.3 and python-dateutil 2.8.2 (`SOFTWARE_VERSIONS.md`).
The three routes run offline after installation. Run the commands below from `02_reproduce/`.

## 2. Three routes — what each needs and how to tell it worked
| Route | Purpose | Input needed | Command | Success looks like |
|---|---|---|---|---|
| **1. Synthetic sample** | tests the **workflow**: the unmodified frozen scripts run end to end and the independent recomputation agrees. Synthetic random walk on the real NYSE calendar; **numbers have no economic meaning** | this ZIP only (`sample_inputs/SYNTHETIC_GSPC_sample.json`) | `python3 -I run_rehearsal.py --route sample` | every field shows `OK`; last line `RESULT: PASS`; exit code 0; synthetic "forecast" 4953.99 |
| **2. Historical rehearsal** | a separate route: the frozen procedure at base 2026-10-21 (target 2026-10-30), checked against the frozen first-round result | two archived files in `inputs/`: `yahoo_GSPC_1988_to_now.json` (SHA-256 a2d671c5…931a) and `first_round_frozen_per_origin_forecasts.csv` (da5b0674…bdb) | `python3 -I run_rehearsal.py --route exact` | `RESULT: PASS`; 1,203 labels; forecast 7772.91 |
| **3. Formal forecast** | recomputes the submitted forecast **7,632.87** from the formal record, without the clock-dependent formal mode | the archived formal input in `inputs/` (below); optionally the snapshot `yahoo_GSPC_1988_to_now.json` for the historical comparison | `python3 -I formal_recheck.py` | every check line `[PASS]` (24 with the snapshot, 23 without); last line `formal forecast 7632.87 for 2026-11-20 16:00 New York; recheck PASSED`; exit code 0 |

**Route 3 needs the frozen JSON used in the formal run.** This ZIP alone verifies the workflow (route 1) but cannot
reproduce 7,632.87 exactly. The required file is:

| File name (place in `02_reproduce/inputs/`) | SHA-256 |
|---|---|
| `yahoo_GSPC_1988_to_now_20261112T175704Z.json` | `5dc23f3a0ff0d641ea3c6d90b8209d4f3e1ee57cc5fd5eb3c0f536f55d9da979` |

It is Yahoo Finance ^GSPC daily data retrieved on 2026-11-12 at 17:57:04 UTC and is kept unchanged in the group's project
archive. It is **not** included here: the group has no permission from the data provider to redistribute it (Yahoo's Terms
of Service, section 2(h), read on 2026-11-12, require explicit written permission to distribute content). A fresh download
has a different hash and cannot replace it; `formal_recheck.py` reports a hash mismatch and returns a failure. Without the file the
script prints `[FAIL] missing restricted input …` and exits 1.

Acceptance tests on 2026-11-12 (Python 3.11.4, macOS, from a clean unzip of this package):
- route 1, ZIP only: **PASS**;
- route 3, ZIP only: stops with "missing restricted input", as designed;
- route 3 after adding the archived formal JSON (and, separately, also the snapshot): **passed after adding the archived file** (7632.87);
- route 2 after adding the two archived inputs: **passed after adding the archived files** (7772.91).

**Formal mode (`--formal`) is not a reviewer route**: it refuses to compute at or after the course cutoff by design.
The individual commands behind each route, and the expected values field by field, are in `02_reproduce/README.md`.

## 3. Layout
| Folder / file | Content |
|---|---|
| `01_research/` | 7-day experiments: results of each frozen back-test (benchmarks B0, B1-7 and Huber-Intercept), diagnostics, negative results, new-factor checks, protocol summary, source register, corrections and failures, frozen research code |
| `02_reproduce/` | frozen D41 production and independent scripts, freeze record, route 1–2 wrapper `run_rehearsal.py`, route 3 `formal_recheck.py`, synthetic input, expected results, the 25/25 pre-freeze test record |
| `03_agent_workflow/` | workflow figure, human review and decisions, member checks and approval, AI use, instruction and tool-call excerpts |
| `04_formal_run/` | formal record, independent check (17/17), freeze record (English excerpt), run log, data-retrieval log and hashes, official-close screenshot, completed verification checklist (English translation) |
| `MANIFEST.csv` | every file with size and SHA-256 |
| `SOFTWARE_VERSIONS.md`, `KEY_NUMBERS.md` | software versions; every key number and the file it comes from |

## 4. Who did what

- **Zhi Li** directed the research, checked the rehearsal input and the comparison of 944 historical forecasts, and approved the protocols, model choice and formal forecast.
- **Ci Bao** reviewed the factor choice, reproduced the October rehearsal in her own environment, and captured the official S&P DJI closing-level screenshot.
- **Shujun Zhou** ran the synthetic and October rehearsal routes in her own environment with AI assistance, reported a manual spot check of the 21-day return, and matched the base close used in the formal run to the official screenshot.
- **Loli Kalaitzi** reviewed the report’s English, figures, citations and formatting, prepared the presentation slides, and checked the forecast value and target date and time on the draft report cover against the formal record.

Claude Code researched sources, drafted the report and evidence, and wrote and ran the research and forecast scripts.
See the [member confirmations](03_agent_workflow/member_confirmations.md) for the checks and their sources.

## 5. What stays in the group archive
| Category | Files |
|---|---|
| Yahoo-derived data (no redistribution permission) | the formal input above, the frozen snapshot, the first-round per-origin results, and the formal run's `training_set.csv` / `closes_used.csv` (SHA-256 in `04_formal_run/formal_record/SHA256_formal_outputs.txt`) |
| Chinese originals | decision log, run logs, the completed verification checklist and the original freeze record (English translations or excerpts here, each naming its archive source) |
| Third-party documents | copyrighted papers and web snapshots |

No credentials are included. Repository: https://github.com/zzzhil912-cell/IFTE0007-SP500-7Day
