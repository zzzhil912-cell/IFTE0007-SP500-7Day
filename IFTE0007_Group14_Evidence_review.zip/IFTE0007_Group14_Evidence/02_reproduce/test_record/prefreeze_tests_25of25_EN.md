# Pre-freeze test record (archived evidence, English translation)

Translation of the frozen result table `tests/test_results.md` (SHA-256
c28936a6479bd2c54668e85d5557ba10ca8ca371ddc0ad5abf7730a8b650f266, Chinese original kept in the internal archive with the
test script `tests/run_prefreeze_tests.py`, SHA-256 c14ebe29e7699fe9758ad212a88f365768cc0f6166b862ec55a44651ec54b392).
Run by Claude on 2026-11-06 before the D41 freeze, with the real frozen inputs: **25 of 25 steps as expected.**

**This is archived evidence, not a reviewer entry point.** T9c is the one test whose outcome depends on the date it is
run: it uses `--formal` with the system clock (T13–T15 use a simulated clock and are unaffected). After the course cutoff (2026-11-13 12:00 London), a formal-mode start stops
at the clock check ("overdue start", exit 3) before the data check that T9c was written to exercise, so rerunning the suite
after the cutoff gives a different stop branch for T9c. The reviewer entry point, `../run_rehearsal.py`, uses rehearsal
mode, which never reads the clock.

| Test | Step | Expected exit | Expected output contains | Actual exit | Result |
|---|---|---|---|---|---|
| T1 main route, frozen snapshot | production equals the frozen row | 0 | all_pass: True | 0 | pass |
| T1 main route | independent check | 0 | passed: True | 0 | pass |
| T2 backup route (snapshot to 10-14 + supplement) | production equals the frozen row | 0 | all_pass: True | 0 | pass |
| T2 backup route | independent check | 0 | passed: True | 0 | pass |
| T3 official base close +0.01 (7757.17 → 7757.18) | production runs; frozen comparison must fail | 4 | "base_close": false | 4 | pass |
| T3 override | independent check reproduces the override computation | 0 | passed: True | 0 | pass |
| T3 override | forecast changes (7772.91 → 7772.92); history and coefficients unchanged | 0 | | 0 | pass |
| T4 data file missing ordinary day 2026-10-15 | production stops | 3 | missing ['2026-10-15'] | 3 | pass |
| T5 supplement missing 2026-10-19 | production stops | 3 | supplement missing trading days | 3 | pass |
| T6 supplement duplicate (date, source) | production stops | 3 | supplement duplicate row | 3 | pass |
| T7 supplement source conflict on 2026-10-20 | production stops | 3 | source conflict | 3 | pass |
| T8 supplement overlaps the snapshot (2026-10-14) | production stops | 3 | overlaps the data file | 3 | pass |
| T9a --formal with a non-formal base | stop | 3 | requires base 2026-11-11 | 3 | pass |
| T9b --formal without retrieval time | stop | 3 | requires --retrieved-utc | 3 | pass |
| T9c --formal passes its own guards, then the data check stops it (snapshot has no 2026-11-11 close) | stop at data check, no forecast | 3 | no final close for base date 2026-11-11 | 3 | pass (run before the cutoff; system clock) |
| T10 override without source | stop | 3 | requires --override-source | 3 | pass |
| T11 record forecast altered by 0.01 | independent check fails | 1 | "forecast_2dp": false | 1 | pass |
| T12 supplement hash in record does not match archived file | independent check fails | 1 | "supplement_sha256": false | 1 | pass |
| T13 simulated clock: start at 2026-11-13 12:00:00 UTC | stop before computing | 3 | overdue start | 3 | pass |
| T13 | no output folder, record or temporary folder | 0 | | 0 | pass |
| T14 simulated clock: start 11:59:30, writing reached at 12:00:01 UTC | stop before writing | 5 | no forecast record written | 5 | pass |
| T14 | no output folder, record or temporary folder | 0 | | 0 | pass |
| T15 positive control: simulated start and finish before cutoff (synthetic data) | record written | 0 | | 0 | pass |
| T15 | record labelled SIMULATED CLOCK - NOT VALID | 0 | | 0 | pass |
| T15 | independent check fails a formal record made under a simulated clock | 1 | "formal_record_uses_system_clock": false | 1 | pass |

Note on T9a/T9b: they stop on argument checks that come before the clock check in the frozen code, so they are not
affected by the date on which they are run.
