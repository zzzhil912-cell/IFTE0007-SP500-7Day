"""Independent recomputation for the F1-21 production record, v3 (round 20: also fails FORMAL records made under a simulated clock
or finished at/after the course cutoff). Does NOT import f1_21_production.py.
Re-derives everything from the ARCHIVED inputs named in the record (data file, supplement CSV, override value/source) and checks:
  - archived input hashes equal the record
  - the trading-day calendar with an independent NYSE calendar (pandas holiday rules + dateutil Easter + listed closures)
  - backup route: supplement covers exactly the expected days after the data file, no overlap, no duplicate, no conflict
  - official override: base close used == override value; history untouched
  - training set, coefficients (2x2 normal equations), yhat, forecast (full and 2 dp), target date
Usage: python -I f1_21_independent.py --record <forecast_record.json> --out <dir> [--frozen <frozen results CSV>]
Exit 0 pass, 1 mismatch.
"""
import argparse, csv, hashlib, json, math, sys
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import numpy as np
import pandas as pd
from dateutil.easter import easter
from pandas.tseries.holiday import (AbstractHolidayCalendar, Holiday, nearest_workday, USMartinLutherKingJr, USPresidentsDay,
                                    USMemorialDay, USLaborDay, USThanksgivingDay)

CLOSURES = ["2004-06-11", "2007-01-02", "2012-10-29", "2012-10-30", "2018-12-05", "2025-01-09"]


class NYSE(AbstractHolidayCalendar):
    rules = [Holiday("July4", month=7, day=4, observance=nearest_workday), Holiday("Xmas", month=12, day=25, observance=nearest_workday),
             Holiday("Juneteenth", month=6, day=19, start_date="2022-01-01", observance=nearest_workday),
             USMartinLutherKingJr, USPresidentsDay, USMemorialDay, USLaborDay, USThanksgivingDay]


def nyse_days(a, b):
    hol = set(NYSE().holidays(a - pd.Timedelta(days=10), b + pd.Timedelta(days=10)))
    for y in range(a.year, b.year + 1):
        hol.add(pd.Timestamp(easter(y)) - pd.Timedelta(days=2))
        nd = pd.Timestamp(y, 1, 1)
        if nd.weekday() == 6: hol.add(nd + pd.Timedelta(days=1))
        elif nd.weekday() < 5: hol.add(nd)                     # Saturday New Year: no Friday holiday on NYSE
    hol |= {pd.Timestamp(x) for x in CLOSURES}
    return [d for d in pd.bdate_range(a, b) if d not in hol]


def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def r2(x): return float(Decimal(repr(float(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--record", required=True); ap.add_argument("--out", required=True); ap.add_argument("--frozen")
    a = ap.parse_args(); rec = json.loads(Path(a.record).read_text()); rt = rec["retrieval"]; base = pd.Timestamp(rec["base_date"])
    chk = {"data_file_sha256": h(rt["data_file"]) == rt["data_file_sha256"]}
    if rec.get("mode", "").startswith("FORMAL"):                        # round 20: a formal record must come from the system clock
        chk["formal_record_uses_system_clock"] = rec.get("clock") == "system"
        chk["formal_record_finished_before_cutoff"] = rec.get("run_finished_utc", "9999") < "2026-11-13T12:00:00+00:00"
    j = json.loads(Path(rt["data_file"]).read_text())["chart"]["result"][0]
    ix = pd.to_datetime(j["timestamp"], unit="s", utc=True).tz_convert("America/New_York")
    rmt = pd.Timestamp(j["meta"]["regularMarketTime"], unit="s", tz="UTC").tz_convert("America/New_York")
    s = pd.Series(j["indicators"]["quote"][0]["close"], index=ix.normalize().tz_localize(None)).astype(float)
    if rmt.hour < 16 and s.index[-1] == rmt.normalize().tz_localize(None): s = s.iloc[:-1]
    s = s[s.index <= base].map(r2)
    if rt["supplement_file"]:
        chk["supplement_sha256"] = h(rt["supplement_file"]) == rt["supplement_sha256"]
        sp = pd.read_csv(rt["supplement_file"], dtype=str)
        sp["date"] = pd.to_datetime(sp["date"].str.strip()); sp["close"] = sp["close"].astype(float).map(r2)
        chk["supplement_no_duplicate_date_source"] = not sp.duplicated(["date", "source"]).any()
        chk["supplement_no_conflict"] = bool((sp.groupby("date")["close"].nunique() == 1).all())
        exp = nyse_days(s.index[-1] + pd.Timedelta(days=1), base)
        chk["supplement_covers_exact_days"] = sorted(sp["date"].unique()) == list(exp)
        s = pd.concat([s, sp.groupby("date")["close"].first()]).sort_index()
    chk["calendar_2003-08_to_base"] = list(s[s.index >= pd.Timestamp("2003-08-01")].index) == nyse_days(pd.Timestamp("2003-08-01"), base)
    chk["base_close_in_data"] = f"{s.loc[base]:.2f}" == rec["base_close_in_data"]
    if rec["base_close_override_source"]:
        s.loc[base] = r2(rec["base_close_used"]); chk["override_has_source"] = True
    chk["base_close_used"] = f"{s.loc[base]:.2f}" == rec["base_close_used"]
    P = s.to_numpy(); n = len(P); pos = pd.Series(np.arange(n), index=s.index); ib = pos[base]
    k = s.index.searchsorted(pd.date_range(pd.Timestamp("2003-09-24"), base, freq="7D"), side="right") - 1
    org = pd.Index(s.index[k]).unique(); p = pos[org].to_numpy(); keep = (p - 21 >= 0) & (p + 7 <= ib); p, o = p[keep], org[keep]
    x = np.log(P[p] / P[p - 21]); y = np.log(P[p + 7] / P[p])
    b = np.linalg.solve(np.array([[len(x), x.sum()], [x.sum(), (x * x).sum()]]), np.array([y.sum(), (x * y).sum()]))
    xt = math.log(P[ib] / P[ib - 21]); yhat = b[0] + b[1] * xt; F = P[ib] * math.exp(yhat); F2 = r2(F)
    tgt = nyse_days(base + pd.Timedelta(days=1), base + pd.Timedelta(days=20))[6]
    chk.update({"n_train": rec["n_train"] == len(p), "first_train_origin": rec["first_train_origin"] == str(o[0].date()),
                "last_train_origin": rec["last_train_origin"] == str(o[-1].date()), "last_train_label_end": rec["last_train_label_end"] == str(s.index[p[-1] + 7].date()),
                "x21": abs(float(rec["x21"]) - xt) <= 1e-12, "coef_intercept": abs(float(rec["coef_intercept"]) - b[0]) <= 1e-10,
                "coef_x21": abs(float(rec["coef_x21"]) - b[1]) <= 1e-10, "yhat": abs(float(rec["yhat_log_return"]) - yhat) <= 1e-10,
                "forecast_full": abs(float(rec["forecast_full"]) - F) <= 1e-6, "forecast_2dp": rec["forecast_2dp"] == f"{F2:.2f}",
                "target_date": rec["target"]["target_date"] == str(tgt.date())})
    if a.frozen:
        f = {r["origin"]: r for r in csv.DictReader(open(a.frozen)) if r["rule"] == "F1-21"}.get(rec["base_date"])
        if f: chk.update({"frozen_yhat": abs(float(f["yhat"]) - yhat) <= 1e-10, "frozen_forecast_2dp": f["forecast_2dp"] == f"{F2:.2f}", "frozen_n_train": int(f["n_train"]) == len(p)})
    rep = {"record": a.record, "route": rec["route"], "independent": {"n_train": int(len(p)), "a": repr(float(b[0])), "b": repr(float(b[1])), "yhat": repr(float(yhat)),
           "forecast_2dp": f"{F2:.2f}", "base_close_used": f"{P[ib]:.2f}", "target_date": str(tgt.date())},
           "checks": {k_: bool(v) for k_, v in chk.items()}, "passed": bool(all(chk.values()))}
    Path(a.out).mkdir(parents=True, exist_ok=True); (Path(a.out) / "independent_check.json").write_text(json.dumps(rep, indent=1))
    print(json.dumps(rep["checks"])); print("passed:", rep["passed"]); sys.exit(0 if rep["passed"] else 1)


if __name__ == "__main__":
    main()
