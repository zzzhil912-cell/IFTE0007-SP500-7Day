"""F1-21 production script, pre-freeze revision v2 (round 19; adopted rule D38). PRICE-ONLY single-origin forecast.

Rule (identical to frozen first-round F1-21): x_t = ln(P_t/P_{t-21}); y_s = ln(P_{s+7}/P_s); training origins every Wednesday
from 2003-09-24 (Wednesday holiday -> previous trading day), matured labels idx(s)+7 <= idx(t), >= 260; OLS with intercept
(numpy lstsq); F = P_t * exp(yhat), 2 dp ROUND_HALF_UP. Closes normalised to 2 dp (ROUND_HALF_UP).

ROUTES
  main    : --yahoo <fresh Yahoo chart JSON> [--compare-snapshot <frozen snapshot>]
  backup  : --yahoo <frozen snapshot> --supplement <CSV: date,close,source,retrieved_utc,evidence>
            the supplement must cover EXACTLY the expected NYSE trading days after the snapshot's last complete close up to the
            base date: a missing day, an extra day, a date overlapping the snapshot, a duplicated (date, source) row, or two sources
            giving different closes for one date -> STOP. Several sources agreeing on the same close are allowed (corroboration).
  official base close: --base-close-override <value> --override-source <text>  (either route; replaces P_t only)
CALENDAR CHECK (both routes): the set of S&P trading dates from 2003-08-01 to the base date must equal the expected NYSE
trading-day set (rule-based full-day holidays + documented special closures). A missing ordinary trading day, an extra day
or a duplicate -> STOP.
FORMAL MODE (--formal): base must be 2026-11-11; --retrieved-utc required; the clock is read at START and again just before
WRITING. If the start is at/after the course information cutoff 2026-11-13 12:00 London (= 12:00 UTC) -> STOP (exit 3) before
reading data; if the run reaches the cutoff before writing -> STOP (exit 5) and NO forecast record or output file is left
(outputs are first written to a temporary folder and only moved into place after the final clock check).
CLOCK: system UTC clock. For tests only, env F121_SIMULATED_NOW="ISO1[,ISO2,...]" supplies successive clock readings; any
record produced under a simulated clock is labelled 'SIMULATED CLOCK - NOT A VALID FORMAL RECORD' and the independent check
fails it in formal mode.
Writes the forecast record with target, both information boundaries, retrieval times and source evidence.
Exit codes: 0 ok; 3 data/integrity stop or overdue start; 4 rehearsal mismatch with the frozen row; 5 cutoff reached before writing.
Round 20 revision: clock checks at start and before writing, atomic output, simulated clock for tests.
"""
import argparse, csv, hashlib, json, math, os, shutil, sys
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np

NY = ZoneInfo("America/New_York")
H, L, MIN_TRAIN = 7, 21, 260
TRAIN_FIRST_WED = date(2003, 9, 24)
CAL_START = date(2003, 8, 1)
FORMAL_BASE = date(2026, 11, 11)
COURSE_CUTOFF_UTC = datetime(2026, 11, 13, 12, 0, tzinfo=timezone.utc)      # 12:00 London (GMT)
SPECIAL_CLOSURES = {date(2004, 6, 11), date(2007, 1, 2), date(2012, 10, 29), date(2012, 10, 30), date(2018, 12, 5), date(2025, 1, 9)}


def stop(msg, code=3): print(f"STOP: {msg}", file=sys.stderr); raise SystemExit(code)


_SIM = [datetime.fromisoformat(x.strip().replace("Z", "+00:00")) for x in os.environ.get("F121_SIMULATED_NOW", "").split(",") if x.strip()]
CLOCK_LABEL = "system" if not _SIM else "SIMULATED CLOCK - NOT A VALID FORMAL RECORD: " + os.environ["F121_SIMULATED_NOW"]


def now_utc():
    """System clock, or the next simulated reading (last one repeats) when F121_SIMULATED_NOW is set (tests only)."""
    if not _SIM: return datetime.now(timezone.utc)
    return _SIM.pop(0) if len(_SIM) > 1 else _SIM[0]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def r2(x): return float(Decimal(repr(float(x))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def _easter(y):
    a, b, c = y % 19, y // 100, y % 100; d, e = b // 4, b % 4; f = (b + 8) // 25; g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30; i, k = c // 4, c % 4; l = (32 + 2 * e + 2 * i - h - k) % 7; m = (a + 11 * h + 22 * l) // 451
    return date(y, (h + l - 7 * m + 114) // 31, (h + l - 7 * m + 114) % 31 + 1)


def _nth(y, m, wd, n):
    x = date(y, m, 1)
    while x.weekday() != wd: x += timedelta(days=1)
    return x + timedelta(days=7 * (n - 1))


def _last(y, m, wd):
    x = (date(y, m + 1, 1) if m < 12 else date(y + 1, 1, 1)) - timedelta(days=1)
    while x.weekday() != wd: x -= timedelta(days=1)
    return x


def _obs(x): return x - timedelta(days=1) if x.weekday() == 5 else (x + timedelta(days=1) if x.weekday() == 6 else x)


def nyse_holidays(y):
    hs = set()
    if date(y, 1, 1).weekday() != 5: hs.add(_obs(date(y, 1, 1)))
    hs |= {_nth(y, 1, 0, 3), _nth(y, 2, 0, 3), _easter(y) - timedelta(days=2), _last(y, 5, 0), _obs(date(y, 7, 4)), _nth(y, 9, 0, 1),
           _nth(y, 11, 3, 4), _obs(date(y, 12, 25))}
    if y >= 2022: hs.add(_obs(date(y, 6, 19)))
    return hs


def expected_trading_days(a, b):
    hol = set().union(*(nyse_holidays(y) for y in range(a.year, b.year + 1))) | SPECIAL_CLOSURES
    out, x = [], a
    while x <= b:
        if x.weekday() < 5 and x not in hol: out.append(x)
        x += timedelta(days=1)
    return out


def read_yahoo(path):
    j = json.loads(Path(path).read_text()); res = j["chart"]["result"][0]; meta = res["meta"]
    if meta.get("dataGranularity") != "1d": stop("granularity is not 1d")
    rmt = datetime.fromtimestamp(meta["regularMarketTime"], timezone.utc).astimezone(NY)
    rows = []
    for t, c in zip(res["timestamp"], res["indicators"]["quote"][0]["close"]):
        dt = datetime.fromtimestamp(t, timezone.utc).astimezone(NY)
        if dt.strftime("%H:%M") != "09:30": stop(f"unexpected bar time {dt}")
        rows.append((dt.date(), c))
    log = []
    if rows and rows[-1][0] == rmt.date() and (rmt.hour, rmt.minute) < (16, 0):
        log.append(f"dropped intraday bar {rows[-1][0]} (regularMarketTime {rmt.isoformat()})"); rows = rows[:-1]
    ds = [d for d, _ in rows]
    if len(set(ds)) != len(ds): stop("duplicate dates in data file")
    if any(a >= b for a, b in zip(ds, ds[1:])): stop("dates not strictly increasing")
    if any(c is None for _, c in rows): stop("null close in data file")
    return rows, rmt, log


def read_supplement(path):
    raw = list(csv.DictReader(open(path)))
    need = {"date", "close", "source", "retrieved_utc"}
    if not raw or not need <= set(raw[0].keys()): stop(f"supplement CSV must have columns {sorted(need)} (+ evidence)")
    seen, by = set(), {}
    for r in raw:
        d = date.fromisoformat(r["date"].strip()); src = r["source"].strip()
        if not src: stop(f"supplement row {d} has no source")
        if (d, src) in seen: stop(f"supplement duplicate row for {d} from source {src!r}")
        seen.add((d, src)); by.setdefault(d, []).append((r2(r["close"]), src, r["retrieved_utc"].strip(), r.get("evidence", "").strip()))
    for d, v in by.items():
        if len({c for c, *_ in v}) > 1: stop(f"supplement source conflict on {d}: {[(c, s) for c, s, *_ in v]}")
    return by


def build_closes(yahoo, base, supplement=None):
    rows, rmt, log = read_yahoo(yahoo)
    after = [d for d, _ in rows if d > base]
    if after: log.append(f"dropped {len(after)} rows dated after base {base} (information boundary)")
    rows = [(d, c) for d, c in rows if d <= base]
    sup_info = None
    if supplement:
        by = read_supplement(supplement)
        last = rows[-1][0]
        overlap = sorted(d for d in by if d <= last)
        if overlap: stop(f"supplement overlaps the data file: {overlap[:5]}")
        beyond = sorted(d for d in by if d > base)
        if beyond: stop(f"supplement has dates after the base date: {beyond[:5]}")
        exp = expected_trading_days(last + timedelta(days=1), base)
        miss = [str(d) for d in exp if d not in by]; extra = [str(d) for d in by if d not in exp]
        if miss: stop(f"supplement missing trading days: {miss}")
        if extra: stop(f"supplement has non-trading or unexpected days: {extra}")
        for d in exp: rows.append((d, by[d][0][0]))
        sup_info = {d.isoformat(): [{"close": f"{c:.2f}", "source": s, "retrieved_utc": t, "evidence": e} for c, s, t, e in v] for d, v in sorted(by.items())}
        log.append(f"supplement: {len(exp)} trading days {exp[0]}..{exp[-1]} from {supplement}")
    if not rows or rows[-1][0] != base: stop(f"no final close for base date {base}")
    dates = [d for d, _ in rows]
    exp_all = expected_trading_days(CAL_START, base); got = [d for d in dates if d >= CAL_START]
    if got != exp_all:
        miss = [str(d) for d in sorted(set(exp_all) - set(got))]; extra = [str(d) for d in sorted(set(got) - set(exp_all))]
        stop(f"trading-day set differs from the NYSE calendar: missing {miss[:10]}, extra {extra[:10]}")
    raw = [c for _, c in rows]; close = [r2(c) for c in raw]
    if max(abs(a - b) for a, b in zip(raw, close)) >= 0.0051: stop("2-dp normalisation changed a close too much")
    log.append(f"closes used: {len(dates)} ({dates[0]} .. {dates[-1]}); calendar check {CAL_START}..{base} passed ({len(exp_all)} trading days)")
    return dates, close, log, rmt, sup_info


def run(a):
    base = date.fromisoformat(a.base); out = Path(a.out)
    started = now_utc()
    if a.formal:
        if base != FORMAL_BASE: stop(f"--formal requires base {FORMAL_BASE}")
        if not a.retrieved_utc: stop("--formal requires --retrieved-utc of the data file")
        if started >= COURSE_CUTOFF_UTC: stop(f"overdue start: clock {started.isoformat()} is at/after the course information cutoff 2026-11-13 12:00 London; nothing computed")
    tmp = out.parent / (out.name + ".tmp_incomplete")
    if tmp.exists(): shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    import atexit; atexit.register(lambda: shutil.rmtree(tmp, ignore_errors=True))   # no partial output survives any stop
    dates, close, log, rmt, sup = build_closes(a.yahoo, base, a.supplement)
    idx = {d: i for i, d in enumerate(dates)}
    if a.compare_snapshot:
        srows, _, _ = read_yahoo(a.compare_snapshot); ref = {d: r2(c) for d, c in srows}
        common = [d for d in dates if d in ref]
        diff = [(str(d), close[idx[d]], ref[d]) for d in common if abs(close[idx[d]] - ref[d]) > 1e-9]
        log.append(f"historical closes compared with frozen snapshot: {len(common)} dates, {len(diff)} differences {diff[:5]}")
        if diff: stop(f"historical closes differ from frozen snapshot: {diff[:5]}")
    ib = idx[base]; file_close = close[ib]
    if a.base_close_override is not None:
        if not a.override_source: stop("--base-close-override requires --override-source")
        close[ib] = r2(a.base_close_override)
        log.append(f"base close override: data {file_close:.2f} -> {close[ib]:.2f} (source: {a.override_source}); history unchanged")
    sched, w = [], TRAIN_FIRST_WED
    while w <= base:
        t = w
        while t not in idx and t > dates[0]: t -= timedelta(days=1)
        if t in idx and (not sched or sched[-1] != t): sched.append(t)
        w += timedelta(days=7)
    train = [s for s in sched if idx[s] - L >= 0 and idx[s] + H <= ib]
    if len(train) < MIN_TRAIN: stop(f"only {len(train)} matured training labels")
    X = np.array([[1.0, math.log(close[idx[s]] / close[idx[s] - L])] for s in train])
    y = np.array([math.log(close[idx[s] + H] / close[idx[s]]) for s in train])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    x_t = math.log(close[ib] / close[ib - L]); yhat = float(beta[0] + beta[1] * x_t); F = close[ib] * math.exp(yhat)
    target = expected_trading_days(base + timedelta(days=1), base + timedelta(days=20))[H - 1]
    tau = expected_trading_days(base + timedelta(days=1), base + timedelta(days=10))[0]
    rec = {"rule": "F1-21 (D38)", "route": ("backup (snapshot + supplement)" if a.supplement else "main"),
           "mode": ("FORMAL" if a.formal else "rehearsal/test") + ("" if CLOCK_LABEL == "system" else " (SIMULATED CLOCK - NOT VALID)"),
           "clock": CLOCK_LABEL,
           "target": {"definition": "S&P 500 price index official closing level (S&P Dow Jones Indices), index points",
                      "target_date": str(target), "target_time": "16:00 New York"},
           "information_boundaries": {
               "model_input_boundary": f"only closes dated <= {base}; inputs must be published before {tau} 09:30 New York (tau)",
               "course_information_cutoff": "2026-11-13 12:00 London (12:00 UTC); all inputs available and the record frozen before it"},
           "base_date": str(base), "base_close_used": f"{close[ib]:.2f}", "base_close_in_data": f"{file_close:.2f}",
           "base_close_override_source": a.override_source or "", "lookback_start_date": str(dates[ib - L]), "lookback_start_close": f"{close[ib - L]:.2f}",
           "x21": repr(x_t), "n_train": len(train), "first_train_origin": str(train[0]), "last_train_origin": str(train[-1]),
           "last_train_label_end": str(dates[idx[train[-1]] + H]), "coef_intercept": repr(float(beta[0])), "coef_x21": repr(float(beta[1])),
           "yhat_log_return": repr(yhat), "forecast_full": repr(F), "forecast_2dp": f"{r2(F):.2f}",
           "retrieval": {"data_file": str(a.yahoo), "data_file_sha256": sha(a.yahoo), "data_file_retrieved_utc": a.retrieved_utc or "",
                         "data_regularMarketTime_NY": rmt.isoformat(), "supplement_file": str(a.supplement or ""),
                         "supplement_sha256": sha(a.supplement) if a.supplement else "", "supplement_rows": sup or {},
                         "compare_snapshot": str(a.compare_snapshot or ""), "compare_snapshot_sha256": sha(a.compare_snapshot) if a.compare_snapshot else ""},
           "run_started_utc": started.isoformat(timespec="seconds"),
           "log": log, "python": sys.version.split()[0], "numpy": np.__version__}
    status = 0
    if a.check_frozen_row:
        f = {r["origin"]: r for r in csv.DictReader(open(a.check_frozen_row)) if r["rule"] == "F1-21"}.get(str(base))
        if f is None: stop(f"no frozen F1-21 row for {base}", 4)
        chk = {"n_train": int(f["n_train"]) == len(train), "first_train_origin": f["first_train_origin"] == str(train[0]),
               "last_train_origin": f["last_train_origin"] == str(train[-1]), "last_train_label_end": f["last_train_label_end"] == rec["last_train_label_end"],
               "base_close": f["base_close"] == rec["base_close_used"], "x21": abs(float(f["x21"]) - x_t) <= 1e-12,
               "coef_intercept": abs(float(f["coef_intercept"]) - beta[0]) <= 1e-12, "coef_x21": abs(float(f["coef_x21"]) - beta[1]) <= 1e-12,
               "yhat": abs(float(f["yhat"]) - yhat) <= 1e-12, "forecast_full": abs(float(f["forecast_full"]) - F) <= 1e-8,
               "forecast_2dp": f["forecast_2dp"] == rec["forecast_2dp"], "target_date": f["target_date"] == str(target)}
        rec["rehearsal_vs_frozen"] = {"checks": {k: bool(v) for k, v in chk.items()}, "all_pass": bool(all(chk.values()))}
        if not all(chk.values()): status = 4
    with open(tmp / "training_set.csv", "w", newline="") as fh:
        wr = csv.writer(fh); wr.writerow(["train_origin", "x21", "label_end", "y_7d_log"])
        for s, xr, yr in zip(train, X[:, 1], y): wr.writerow([s, repr(float(xr)), dates[idx[s] + H], repr(float(yr))])
    with open(tmp / "closes_used.csv", "w", newline="") as fh:
        wr = csv.writer(fh); wr.writerow(["date", "close_2dp"])
        for d_, c_ in zip(dates, close): wr.writerow([d_, f"{c_:.2f}"])
    rec["training_set_sha256"] = sha(tmp / "training_set.csv"); rec["closes_used_sha256"] = sha(tmp / "closes_used.csv")
    finished = now_utc(); rec["run_finished_utc"] = finished.isoformat(timespec="seconds")
    if a.formal and finished >= COURSE_CUTOFF_UTC:
        shutil.rmtree(tmp)
        stop(f"course information cutoff reached before writing (clock {finished.isoformat()}); no forecast record written", 5)
    (tmp / "forecast_record.json").write_text(json.dumps(rec, indent=1, ensure_ascii=False))
    out.mkdir(parents=True, exist_ok=True)
    for f_ in ("training_set.csv", "closes_used.csv", "forecast_record.json"): os.replace(tmp / f_, out / f_)
    shutil.rmtree(tmp)
    print(json.dumps({k: rec[k] for k in ("route", "base_date", "base_close_used", "n_train", "coef_intercept", "coef_x21", "yhat_log_return", "forecast_2dp")}))
    if "rehearsal_vs_frozen" in rec: print("rehearsal vs frozen all_pass:", rec["rehearsal_vs_frozen"]["all_pass"], json.dumps(rec["rehearsal_vs_frozen"]["checks"]))
    raise SystemExit(status)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--yahoo", required=True); ap.add_argument("--base", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--supplement"); ap.add_argument("--compare-snapshot"); ap.add_argument("--check-frozen-row")
    ap.add_argument("--base-close-override"); ap.add_argument("--override-source")
    ap.add_argument("--retrieved-utc"); ap.add_argument("--formal", action="store_true")
    run(ap.parse_args())
