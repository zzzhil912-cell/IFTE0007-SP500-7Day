"""Build the SYNTHETIC sample input used by the "sample run-through" route.

THIS IS NOT MARKET DATA. Prices are a seeded random walk (geometric Brownian motion); only the trading-day calendar is real
(rule-based NYSE full-day holidays plus the documented special closures used by the frozen scripts). The file mimics the
layout of a Yahoo Finance chart JSON (daily bars stamped 09:30 New York, regularMarketTime after the 16:00 close) so that
the frozen, unmodified F1-21 production and independent scripts can be exercised without redistributing licensed data.

Usage (from 02_reproduce/):  python -I sample_inputs/make_synthetic_sample.py
Writes sample_inputs/SYNTHETIC_GSPC_sample.json. The output is deterministic (seed 20261107); its SHA-256 is listed in
expected/sample_expected.json and checked by run_rehearsal.py.
"""
import json
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
from dateutil.easter import easter
from pandas.tseries.holiday import (AbstractHolidayCalendar, Holiday, nearest_workday, USMartinLutherKingJr, USPresidentsDay,
                                    USMemorialDay, USLaborDay, USThanksgivingDay)

NY = ZoneInfo("America/New_York")
START, END = date(1988, 1, 4), date(2026, 10, 21)
CLOSURES = ["2004-06-11", "2007-01-02", "2012-10-29", "2012-10-30", "2018-12-05", "2025-01-09"]
SEED, P0, MU, SIGMA = 20261107, 250.00, 0.0003, 0.011


class NYSE(AbstractHolidayCalendar):
    rules = [Holiday("July4", month=7, day=4, observance=nearest_workday), Holiday("Xmas", month=12, day=25, observance=nearest_workday),
             Holiday("Juneteenth", month=6, day=19, start_date="2022-01-01", observance=nearest_workday),
             USMartinLutherKingJr, USPresidentsDay, USMemorialDay, USLaborDay, USThanksgivingDay]


def trading_days(a, b):
    a, b = pd.Timestamp(a), pd.Timestamp(b)
    hol = set(NYSE().holidays(a - pd.Timedelta(days=10), b + pd.Timedelta(days=10)))
    for y in range(a.year, b.year + 1):
        hol.add(pd.Timestamp(easter(y)) - pd.Timedelta(days=2))
        nd = pd.Timestamp(y, 1, 1)
        if nd.weekday() == 6: hol.add(nd + pd.Timedelta(days=1))
        elif nd.weekday() < 5: hol.add(nd)
    hol |= {pd.Timestamp(x) for x in CLOSURES}
    return [d.date() for d in pd.bdate_range(a, b) if d not in hol]


def main():
    days = trading_days(START, END)
    rng = np.random.default_rng(SEED)
    r = rng.normal(MU - 0.5 * SIGMA ** 2, SIGMA, len(days)); r[0] = 0.0
    px = [round(float(P0 * np.exp(c)), 2) for c in np.cumsum(r)]
    ts = [int(datetime.combine(d, time(9, 30), NY).timestamp()) for d in days]
    rmt = int(datetime.combine(END, time(16, 30), NY).timestamp())
    j = {"chart": {"result": [{"meta": {"symbol": "SYNTHETIC", "dataGranularity": "1d", "regularMarketTime": rmt,
                                        "note": "SYNTHETIC SAMPLE - NOT MARKET DATA. Seeded random walk on the NYSE trading calendar; "
                                                f"seed {SEED}, start {P0}, daily mu {MU}, sigma {SIGMA}."},
                               "timestamp": ts, "indicators": {"quote": [{"close": px}]}}], "error": None}}
    out = Path(__file__).resolve().parent / "SYNTHETIC_GSPC_sample.json"
    out.write_text(json.dumps(j, separators=(",", ":")))
    print(f"wrote {out.name}: {len(days)} synthetic closes {days[0]} .. {days[-1]}")


if __name__ == "__main__":
    main()
