"""Wrapper for the 2026-10-21 historical rehearsal of the frozen F1-21 rule (D38). Offline. No formal forecast.

It never edits the frozen files: it checks their SHA-256 against the unchanged freeze record freeze/FREEZE_RECORD_production.json
(decision D41), then calls the unmodified scripts in code/ with paths relative to this folder (02_reproduce/), and compares the results with expected/.

  python -I run_rehearsal.py --route sample   # synthetic sample input shipped in this package (always available)
  python -I run_rehearsal.py --route exact    # real frozen inputs; needs inputs/ filled (see inputs/README_restricted_inputs.md)

Outputs: outputs/<route>/forecast_record.json, training_set.csv, closes_used.csv, independent_check.json, run_log.json.
Exit 0 = every check matched; 1 = a mismatch or a missing input; the frozen scripts' own exit codes are logged.
"""
import argparse, hashlib, json, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY = sys.executable
SNAP, FROZEN = "inputs/yahoo_GSPC_1988_to_now.json", "inputs/first_round_frozen_per_origin_forecasts.csv"
SAMPLE = "sample_inputs/SYNTHETIC_GSPC_sample.json"
KEYS = ("base_date", "base_close_used", "lookback_start_date", "n_train", "first_train_origin", "last_train_origin",
        "last_train_label_end", "coef_intercept", "coef_x21", "yhat_log_return", "forecast_2dp")


def sha(p): return hashlib.sha256((HERE / p).read_bytes()).hexdigest()


def run(cmd):
    p = subprocess.run([PY, "-I", *cmd], cwd=str(HERE), capture_output=True, text=True)
    return {"command": "python -I " + " ".join(cmd), "exit_code": p.returncode, "stdout": p.stdout.strip()[-3000:], "stderr": p.stderr.strip()[-3000:]}


SHIPPED = ("code/f1_21_production.py", "code/f1_21_independent.py")          # frozen D41 files distributed in this package
ARCHIVED = ("docs/forecast_record_template_v2.md", "docs/formal_data_and_backup_plan_v3.md", "docs/manual_verification_checklist.md",
            "tests/run_prefreeze_tests.py", "tests/test_results.md")      # frozen D41 files kept in the internal archive (Chinese originals)


def freeze_check(route):
    """Hashes come from the unchanged D41 freeze record. Shipped code must match; restricted inputs are checked only on the
    exact route; archived documents are listed, not checked (English versions: ../04_formal_run/, test_record/)."""
    frozen = json.loads((HERE / "freeze/FREEZE_RECORD_production.json").read_text())["sha256"]
    res = {}
    for rel, h in sorted(frozen.items()):
        if rel in ARCHIVED: res[rel] = "kept in the internal archive (not shipped; not needed to run)"; continue
        if rel.startswith("inputs/") and route != "exact": res[rel] = "not shipped (restricted input; only needed for --route exact)"; continue
        if not (HERE / rel).exists(): res[rel] = "MISSING"; continue
        res[rel] = "match" if sha(rel) == h else "HASH MISMATCH"
    return res


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--route", choices=["sample", "exact"], required=True); a = ap.parse_args()
    out = f"outputs/{a.route}"; log = {"route": a.route, "started_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                                       "python": sys.version.split()[0], "platform": platform.platform(), "steps": []}
    try:
        import numpy, pandas, dateutil
        log["packages"] = {"numpy": numpy.__version__, "pandas": pandas.__version__, "python-dateutil": dateutil.__version__}
    except ImportError as e:
        print(f"missing dependency: {e}; see requirements.txt"); sys.exit(1)
    fc = freeze_check(a.route); log["frozen_file_hashes"] = fc
    bad = {k: v for k, v in fc.items() if v in ("MISSING", "HASH MISMATCH")}
    nm = sum(v == "match" for v in fc.values())
    print(f"frozen-file hash check (D41 record): {nm} shipped/supplied file(s) match" if not bad else f"frozen-file hash check FAILED: {bad}")
    ok = not bad
    if a.route == "sample":
        exp = json.loads((HERE / "expected/sample_expected.json").read_text())
        if not (HERE / SAMPLE).exists(): log["steps"].append(run(["sample_inputs/make_synthetic_sample.py"]))
        s = sha(SAMPLE); log["sample_sha256"] = s; ok &= s == exp["sample_sha256"]
        print("synthetic sample sha256:", s, "(matches expected)" if s == exp["sample_sha256"] else "(DIFFERS from expected)")
        prod = run(["code/f1_21_production.py", "--yahoo", SAMPLE, "--base", "2026-10-21", "--out", out])
        ind_args = ["code/f1_21_independent.py", "--record", f"{out}/forecast_record.json", "--out", out]
    else:
        exp = json.loads((HERE / "expected/exact_expected.json").read_text())
        if bad or not (HERE / SNAP).exists() or not (HERE / FROZEN).exists():
            print("exact route needs the two restricted inputs in inputs/ with matching SHA-256; see inputs/README_restricted_inputs.md")
            log["result"] = "missing or mismatched restricted inputs"; (HERE / "outputs").mkdir(exist_ok=True)
            (HERE / "outputs/exact_run_log.json").write_text(json.dumps(log, indent=1)); sys.exit(1)
        prod = run(["code/f1_21_production.py", "--yahoo", SNAP, "--base", "2026-10-21", "--out", out,
                    "--compare-snapshot", SNAP, "--check-frozen-row", FROZEN])
        ind_args = ["code/f1_21_independent.py", "--record", f"{out}/forecast_record.json", "--out", out, "--frozen", FROZEN]
    log["steps"].append(prod); print(f"production exit {prod['exit_code']}:", prod["stdout"] or prod["stderr"])
    ok &= prod["exit_code"] == 0
    if prod["exit_code"] == 0:
        ind = run(ind_args); log["steps"].append(ind); print(f"independent exit {ind['exit_code']}:", ind["stdout"].splitlines()[-1] if ind["stdout"] else ind["stderr"])
        ok &= ind["exit_code"] == 0
        rec = json.loads((HERE / out / "forecast_record.json").read_text())
        num = ("coef_intercept", "coef_x21", "yhat_log_return")   # float strings: tolerance 1e-10 (BLAS may differ in last bits)
        cmp = {k: {"expected": exp["record"][k], "actual": rec[k],
                   "match": abs(float(rec[k]) - float(exp["record"][k])) <= 1e-10 if k in num else rec[k] == exp["record"][k]} for k in KEYS}
        log["comparison_with_expected"] = cmp; ok &= all(v["match"] for v in cmp.values())
        if a.route == "exact": ok &= bool(rec.get("rehearsal_vs_frozen", {}).get("all_pass"))
        for k, v in cmp.items(): print(f"  {k:22s} expected {v['expected']!s:24s} actual {v['actual']!s:24s} {'OK' if v['match'] else 'MISMATCH'}")
    log["result"] = "PASS" if ok else "FAIL"; log["finished_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    (HERE / out).mkdir(parents=True, exist_ok=True); (HERE / out / "run_log.json").write_text(json.dumps(log, indent=1))
    print("RESULT:", log["result"]); sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
