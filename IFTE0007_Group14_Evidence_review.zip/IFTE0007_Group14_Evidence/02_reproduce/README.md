# 02_reproduce — verify the calculation offline

Run everything from **this folder** (`02_reproduce/`). All paths are relative and no network access is needed.

**The package ships a synthetic input, so the full calculation flow can be verified offline with the package alone.**
Reproducing the historical rehearsal value 7,772.91 exactly, and checking it against the frozen first-round result, needs
the two real frozen inputs, which are not distributed (see `inputs/README_restricted_inputs.md`).

## Three different runs — do not confuse them
| Run | Mode | Base / target | Clock | Status |
|---|---|---|---|---|
| **Historical rehearsal** | rehearsal (no `--formal`) | 2026-10-21 → 2026-10-30 | never read | route 1 (synthetic input, this package only) checks the calculation flow; route 2 reproduces 7,772.91 only when the two archived inputs are supplied |
| **Formal run** | `--formal` | 2026-11-11 → 2026-11-20 | system clock checked at start and before writing; refuses at or after 2026-11-13 12:00 London | **run 2026-11-12 18:39:57–18:39:58 UTC** (Q33); forecast 7,632.87; record in `../04_formal_run/formal_record/` |
| **Formal-point recomputation (route 3)** | rehearsal mode on the saved formal input, plus the independent check of the saved formal record | 2026-11-11 → 2026-11-20 | never read | `formal_recheck.py`; needs the restricted formal input |

## Files
| Path | What it is | Status |
|---|---|---|
| `code/f1_21_production.py` | Production script (F1-21 forecast, calendar and integrity checks, forecast record) | frozen D41, unchanged; hash checked |
| `code/f1_21_independent.py` | Independent recomputation (no shared code; 2×2 normal equations; own NYSE calendar) | frozen D41, unchanged; hash checked |
| `freeze/FREEZE_RECORD_production.json` | D41 freeze record: approver Zhi Li, 2026-11-06T00:56:26Z, SHA-256 of all 9 frozen files | unchanged |
| `formal_recheck.py` | Route 3: recomputes the formal record from the formal input (see below) | added for route 3 |
| `run_rehearsal.py` | Wrapper: checks hashes against the freeze record, runs both frozen scripts, compares with `expected/` | added for the package |
| `sample_inputs/make_synthetic_sample.py`, `sample_inputs/SYNTHETIC_GSPC_sample.json` | **Synthetic** input: seeded random walk on the real NYSE calendar. **Not market data; results have no economic meaning** | added |
| `expected/exact_expected.json`, `expected/sample_expected.json` | Expected results of routes 2 and 1 | added |
| `test_record/prefreeze_tests_25of25_EN.md` | Archived 25/25 pre-freeze test record (English translation) | archived evidence |
| `inputs/` | Contains the restricted-inputs README. Place the archived inputs here for route 2 (two files) or route 3 (one file, plus the optional snapshot) | — |
| `requirements.txt` | Package versions for the reference reproduction environment | — |

The D41 freeze covers nine files. The two scripts are included here. The freeze record gives the hashes for the two
restricted inputs and the five documents and tests held in the group archive. See the
[English test record](test_record/prefreeze_tests_25of25_EN.md) and the
[formal run summary](../04_formal_run/README_formal_run.md).

## Dependencies
Python 3.11 with numpy, pandas and python-dateutil (`requirements.txt`; recorded runs: Python 3.11.4, numpy 1.24.3,
pandas 1.5.3, python-dateutil 2.8.2). The production script needs numpy only.

## Route 1 — synthetic sample route (package alone; synthetic example, no economic meaning)
```
python -I run_rehearsal.py --route sample
```
Expected: both shipped scripts match the freeze record; synthetic sample SHA-256 `2872ce19…cfe6533`; production exit 0;
independent exit 0 (`passed: True`); all fields equal `expected/sample_expected.json` (1,203 training labels; synthetic
"forecast" 4953.99, a workflow check only). If the JSON is deleted, the wrapper regenerates it deterministically.

## Route 2 — exact historical-rehearsal route (needs the two archived frozen inputs)
1. The two frozen inputs are kept in the group's archive and are not distributed (see `inputs/README_restricted_inputs.md`).
   If they are supplied, place them in `inputs/` under their original names.
2. `python -I run_rehearsal.py --route exact`

Expected: 4 frozen files match (2 scripts, 2 inputs); production exit 0 with `rehearsal vs frozen all_pass: True` (the
result equals the frozen first-round F1-21 row for origin 2026-10-21); independent exit 0; **1,203 labels** (2003-09-24 to
2026-10-07, last label ending 2026-10-16), base close 7757.17, lookback start 2026-09-22 (7764.64), x21 = −0.000963,
intercept 0.002034, slope 0.007882, ŷ = +0.2027 %, **forecast 7772.91 for 2026-10-30 — a historical rehearsal, not the
submitted forecast.**

## Route 3 — formal-forecast recomputation (needs the archived formal input)
1. Place `yahoo_GSPC_1988_to_now_20261112T175704Z.json` (SHA-256 `5dc23f3a0ff0d641ea3c6d90b8209d4f3e1ee57cc5fd5eb3c0f536f55d9da979`)
   in `inputs/`; optionally also the frozen snapshot `yahoo_GSPC_1988_to_now.json` for the historical comparison.
2. `python -I formal_recheck.py`

What it does: checks the two scripts against the freeze record and the input against the formal record's hash; reruns the
frozen production script in rehearsal mode (no clock) and compares every model field with
`../04_formal_run/formal_record/forecast_record.json`; then runs the frozen independent script on a copy of the formal
record whose `data_file` points to the local input (the formal record stores the path on the machine where it ran).
Expected: all checks PASS, `forecast_2dp` 7632.87, `forecast_full` 7632.872005745523, n_train 1,206, x21 −0.02412720609566343,
intercept 0.00195930079762518, slope 0.007879827382702861, ŷ 0.001769182578364456, training_set / closes_used SHA-256
2b43a70a… / 9db42ca1…, independent `passed: True`. With the snapshot present: 9,784 historical closes, 0 differences.
Acceptance on 2026-11-12 (Python 3.11.4, numpy 1.24.3): with this ZIP alone the script stops with "missing restricted input";
after the archived formal JSON was added it passed, with and without the snapshot ("passed after adding the archived file").

Equivalent manual commands (from `02_reproduce/`):
```
python -I code/f1_21_production.py --yahoo inputs/yahoo_GSPC_1988_to_now_20261112T175704Z.json --base 2026-11-11 --out recheck_prod --compare-snapshot inputs/yahoo_GSPC_1988_to_now.json
python -I code/f1_21_independent.py --record <copy of the formal record with retrieval.data_file set to the local input> --out recheck_ind
```

## Exit codes of the frozen scripts
Production: 0 ok; 3 data/integrity stop or overdue start; 4 rehearsal mismatch with the frozen row; 5 course cutoff reached
before writing (formal mode). Independent: 0 pass; 1 mismatch.
