# inputs/ — restricted frozen inputs (not distributed)

The two frozen inputs of the D41 production files and the formal-run input are **not shipped**. Their names, origin and SHA-256 are recorded here
and in `../freeze/FREEZE_RECORD_production.json`.

| File (place here under exactly this name) | SHA-256 (must match) | Content | Why not shipped |
|---|---|---|---|
| `yahoo_GSPC_1988_to_now.json` | `a2d671c5c5595990ae7a6efaa0c22430ec9e34385eaa8e8543bf74434a35931a` | Yahoo Finance chart JSON for ^GSPC, daily, from 1988-01-04; retrieved 2026-11-05T19:26:45Z from `https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?period1=568080000&period2=1793906805&interval=1d&events=history` (HTTP 200, 1,054,431 bytes); last complete close 2026-11-04 (the 2026-11-05 intraday bar is dropped by the script) | S&P 500 index levels; redistribution terms for this download are **not confirmed** |
| `yahoo_GSPC_1988_to_now_20261112T175704Z.json` | `5dc23f3a0ff0d641ea3c6d90b8209d4f3e1ee57cc5fd5eb3c0f536f55d9da979` | **Formal-run input** (route 3). Yahoo Finance chart JSON for ^GSPC, daily, 1988-01-04 to 2026-11-12 (the 11-12 intraday bar is dropped); retrieved 2026-11-12T17:57:04Z from `https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?period1=567993600&period2=1794700800&interval=1d` (HTTP 200); second of two downloads 31 min apart (first: 17:25:48Z, SHA-256 8b4ac826…a34f), identical for all dates ≤ 2026-11-11 | same as above |
| `first_round_frozen_per_origin_forecasts.csv` | `da5b06744f5865c8fe4f9aa4e7b1968542acf63346706f2db369c3ea88c84bdb` | Frozen first-round per-origin results (944 origins × 7 rules); used only to check that the rehearsal equals the frozen F1-21 row for 2026-10-21 | contains index levels from the same download |

**Kept in the group archive and not distributed.** All three files are kept unchanged in the group's internal project archive.
No permission to redistribute them has been obtained: Yahoo's Terms of Service (section 2(h), read 2026-11-12) do not allow
content to be distributed without Yahoo's explicit written permission, and the group holds no such permission. If the files
are supplied, copy them here and run, from `02_reproduce/`:
`python -I run_rehearsal.py --route exact` (route 2: the first and third files) or `python -I formal_recheck.py` (route 3:
the formal-run file; the snapshot is optional). Without them, the synthetic route (`--route sample`) verifies the
calculation flow but reproduces neither 7,772.91 nor 7,632.87.

A fresh download of the Yahoo series will have a **different** hash (new rows, different `regularMarketTime`), so the
exact route needs the archived file, not a new download.
