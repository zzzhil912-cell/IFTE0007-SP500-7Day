"""Route 3: offline recomputation of the submitted formal forecast (7,632.87) from the archived formal record.
Never edits frozen files; never uses --formal (no clock gate). Run from 02_reproduce/:

  python -I formal_recheck.py

Needs (restricted, not shipped; see inputs/README_restricted_inputs.md):
  inputs/yahoo_GSPC_1988_to_now_20261112T175704Z.json   formal input,  SHA-256 5dc23f3a...a979 (required)
  inputs/yahoo_GSPC_1988_to_now.json                    frozen D41 snapshot, SHA-256 a2d671c5...931a (optional: historical comparison)
Steps: (1) frozen scripts match the D41 freeze record; (2) input SHA-256 equals the formal record; (3) the frozen production
script, rerun in rehearsal mode on the same input, reproduces every model field of the formal record; (4) the frozen
independent script recomputes the formal record itself (a copy whose data_file points to the local input) and passes.
Exit 0 = all checks pass; 1 = a mismatch or a missing input.
"""
import hashlib, json, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent; PY = sys.executable
REC = HERE.parent / "04_formal_run/formal_record/forecast_record.json"
FORMAL_IN = "inputs/yahoo_GSPC_1988_to_now_20261112T175704Z.json"; SNAP = "inputs/yahoo_GSPC_1988_to_now.json"
KEYS = ("route", "base_date", "base_close_used", "base_close_in_data", "lookback_start_date", "lookback_start_close", "x21", "n_train",
        "first_train_origin", "last_train_origin", "last_train_label_end", "coef_intercept", "coef_x21", "yhat_log_return",
        "forecast_full", "forecast_2dp", "training_set_sha256", "closes_used_sha256")
sha = lambda p: hashlib.sha256((HERE / p).read_bytes()).hexdigest()
def run(cmd):
    p = subprocess.run([PY, "-I", *cmd], cwd=str(HERE), capture_output=True, text=True)
    print(f"$ python -I {' '.join(cmd)}\n  exit {p.returncode}: {(p.stdout or p.stderr).strip()[-600:]}"); return p.returncode
ok = True
def check(name, cond): global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
frz = json.loads((HERE / "freeze/FREEZE_RECORD_production.json").read_text())["sha256"]
for f in ("code/f1_21_production.py", "code/f1_21_independent.py"): check(f"{f} equals D41 freeze record", sha(f) == frz[f])
rec = json.loads(REC.read_text())
if not (HERE / FORMAL_IN).exists(): print(f"[FAIL] missing restricted input {FORMAL_IN}"); sys.exit(1)
check("formal input SHA-256 equals forecast_record.retrieval.data_file_sha256", sha(FORMAL_IN) == rec["retrieval"]["data_file_sha256"])
out = HERE / "outputs/formal_recheck"; (out / "independent").mkdir(parents=True, exist_ok=True)
cmd = ["code/f1_21_production.py", "--yahoo", FORMAL_IN, "--base", "2026-11-11", "--out", "outputs/formal_recheck/production"]
if (HERE / SNAP).exists():
    check("frozen snapshot SHA-256 equals D41 freeze record", sha(SNAP) == frz["inputs/yahoo_GSPC_1988_to_now.json"]); cmd += ["--compare-snapshot", SNAP]
else: print("[info] frozen snapshot not present: historical comparison with the D41 snapshot skipped")
check("production rerun (rehearsal mode) exit 0", run(cmd) == 0)
new = json.loads((out / "production/forecast_record.json").read_text())
for k in KEYS: check(f"{k}: {new.get(k)} == formal record", new.get(k) == rec.get(k))
loc = dict(rec); loc["retrieval"] = dict(rec["retrieval"], data_file=FORMAL_IN)
(out / "forecast_record_localpath.json").write_text(json.dumps(loc, indent=1))
check("independent recomputation of the formal record passes", run(["code/f1_21_independent.py", "--record", "outputs/formal_recheck/forecast_record_localpath.json", "--out", "outputs/formal_recheck/independent"]) == 0)
print(f"\nformal forecast {rec['forecast_2dp']} for {rec['target']['target_date']} 16:00 New York; recheck {'PASSED' if ok else 'FAILED'}")
sys.exit(0 if ok else 1)
